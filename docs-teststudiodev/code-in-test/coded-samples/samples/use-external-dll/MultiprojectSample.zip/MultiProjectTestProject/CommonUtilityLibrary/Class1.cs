﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using ArtOfTest.WebAii.Core;
using ArtOfTest.WebAii.Controls.HtmlControls;

namespace CommonUtilityLibrary
{
    public class UtilityClass1
    {
        private Manager myManager;

        // Constructor
        public UtilityClass1(Manager activeBrowser)
        {
            this.myManager = activeBrowser;
        }

        // Enters data in 6 fiels on the currently loaded form
        public void enterForm1Data()
        {
            myManager.ActiveBrowser.Find.ByExpression<HtmlInputText>("id=oTxt1").Text = "This is field 1";
            myManager.ActiveBrowser.Find.ByExpression<HtmlInputText>("id=oTxt2").Text = "This is field 2";
            myManager.ActiveBrowser.Find.ByExpression<HtmlInputText>("id=oTxt3").Text = "This is field 3";
            myManager.ActiveBrowser.Find.ByExpression<HtmlInputText>("id=oTxt4").Text = "This is field 4";
            myManager.ActiveBrowser.Find.ByExpression<HtmlInputText>("id=oTxt5").Text = "This is field 5";
            myManager.ActiveBrowser.Find.ByExpression<HtmlInputText>("id=oTxt6").Text = "This is field 6";
        }

        // Sets a checkbox
        public void setCheck(bool check, HtmlInputCheckBox cbox)
        {
            cbox.Check(check, true);
        }

        // Selects an item from a dropdown
        public void selectDropDownItem(string item, HtmlSelect dropdown)
        {
            dropdown.SelectByText(item, true);
        }
    }
}
