#!/bin/bash

PID=app.pid
LOG=${4:-/dev/null}
ERROR=app-error.log
PORT=${2:-8084}
MESSAGETIMEOUT=20000
CLIENTCONNECTIONTIMEOUT=20000
VERBOSITY=${3:-false}

CMD='./node node_modules/server/server.js'
USR=`id -un`

status() {
    echo
    echo "Status: "

    if [ -f $PID ]
    then
        echo
        echo "Pid file: $( cat $PID ) [$PID]"
        echo
        ps -ef | grep -v grep | grep $( cat $PID )
		PORT_STATUS=`ps -ef | grep -v grep | grep $( cat $PID ) | awk '{print $10}'`
		echo 
		echo "Message Server listening on port $PORT_STATUS"
		echo
    else
        echo
        echo "No Pid file"
    fi
}

start() {
    if [ -f $PID ]
    then
        echo
        echo "Already started. PID: [$( cat $PID )]"        
    else
		re='^[0-9]+$'
		if ! [[ $PORT =~ $re ]] ; then
		   echo "error: Port is not a number" >&2; exit 1
		fi

		if [ "$PORT" -le 0 -o "$PORT" -ge 65535 ]; then 
			echo "error: Port is not a range 1-65535" >&2; exit 1
		fi
		
		COMMAND="$CMD $PORT $MESSAGETIMEOUT $CLIENTCONNECTIONTIMEOUT $VERBOSITY disable"
        echo "Starting..."
        touch $PID
        if nohup $COMMAND >>$LOG 2>&1 &
        then echo $! >$PID
             sleep 1
             pd=`ps -eo pid | grep "^[[:space:]]*$![[:space:]]*$" | grep -v grep`
             if [ -z $pd ]; then				
                echo "Error... "
				$COMMAND
                /bin/rm $PID
             else
                 echo "Done."
                 echo ""
                 echo "Message Server listening on port $PORT"
                 echo "$(date '+%Y-%m-%d %X'): START" >>$LOG
             fi             
        else echo "Error... "
		     $COMMAND
             /bin/rm $PID
        fi
    fi
}

kill_cmd() {
    SIGNAL=""; MSG="Killing "
    while true
    do
        LIST=`ps -ef | grep -v grep | grep $CMD | grep -w $USR | awk '{print $2}'`
        if [ "$LIST" ]
        then
            echo; echo "$MSG $LIST" ; echo
            echo $LIST | xargs kill $SIGNAL
            sleep 2
            SIGNAL="-9" ; MSG="Killing $SIGNAL"
            if [ -f $PID ]
            then
                /bin/rm $PID
            fi
        else
           echo; echo "All killed..." ; echo
           break
        fi
    done
}

stop() {
    echo "Stopping..."

    if [ -f $PID ]
    then
        if kill $( cat $PID )
        then echo "Done."
             echo "$(date '+%Y-%m-%d %X'): STOP" >>$LOG
        fi
        /bin/rm $PID
        kill_cmd
    else
        echo "No pid file. Already stopped?"
    fi
}

restart(){
	if [ -f $PID ]
    then
        PORT=`ps -ef | grep -v grep | grep $( cat $PID ) | awk '{print $10}'`
		stop ; echo "Sleeping..."; sleep 1 ;
		start
    else
        echo
        echo "No Pid file."
		echo
		start
    fi
}

case "$1" in
    
    'start')
            start
            ;;
    'stop')
            stop
            ;;
    'restart')
            restart
            ;;
    'status')
            status
            ;;
    *)
            echo
            echo "Usage: $0 { start [OPTION] | stop | restart | status }"
            echo "start options: <port> <verbous> <log_file>"
            echo "      port: 1024-65535 default: 8084"
            echo "      verbous - true/false default: false" 
            echo "      log location - path to log file default: no logging"
            exit 1
            ;;
esac

exit 0