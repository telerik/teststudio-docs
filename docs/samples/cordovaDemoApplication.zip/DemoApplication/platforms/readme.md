Add platforms with the Cordova command line tool.
