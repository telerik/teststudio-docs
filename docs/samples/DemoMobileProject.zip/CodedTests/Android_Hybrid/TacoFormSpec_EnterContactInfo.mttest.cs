using System;
using Telerik.MobileTesting.Data;
using Telerik.MobileTesting.Runtime;
using Telerik.MobileTesting.Framework;

namespace DemoMobileProject.CodedTests.Hybrid
{
	// It is mandatory for each test class to inherit HybridAndroidTestBase class as shown below (this is set by default).
    public partial class TacoFormSpec_EnterContactInfo: HybridAndroidTestBase
    {				
		public void EnterNameInput()
		{
			this.ActiveDevice.Web.ScrollToElement(Helper.ContactInfo_Name);
			this.ActiveDevice.Web.SetValue(Helper.ContactInfo_Name,"John Dow");
			Assert.IsTrue(this.ActiveDevice.Web.GetValue(Helper.ContactInfo_Name) == "John Dow",this.ActiveDevice.Web.GetValue(Helper.ContactInfo_Name));
		}
		
		public void EnterPhoneInput()
		{
			this.ActiveDevice.Web.SetValue(Helper.ContactInfo_Phone,"1234567890");
			Assert.IsTrue(this.ActiveDevice.Web.GetValue(Helper.ContactInfo_Phone) == "1234567890",this.ActiveDevice.Web.GetValue(Helper.ContactInfo_Phone));
		}
		
		public void EnterEmailInput()
		{
			this.ActiveDevice.Web.SetValue(Helper.ContactInfo_Email,"johndoe@telerik.com");
			Assert.IsTrue(this.ActiveDevice.Web.GetValue(Helper.ContactInfo_Email) == "johndoe@telerik.com",this.ActiveDevice.Web.GetValue(Helper.ContactInfo_Email));
		}
		
		public void UncheckNewsletterCheckbox()
		{
			this.ActiveDevice.Web.SetChecked(Helper.ContactInfo_Newsletter,false);
			Assert.IsFalse(this.ActiveDevice.Web.GetChecked(Helper.ContactInfo_Newsletter),this.ActiveDevice.Web.GetChecked(Helper.ContactInfo_Newsletter).ToString());
		}
	}
}