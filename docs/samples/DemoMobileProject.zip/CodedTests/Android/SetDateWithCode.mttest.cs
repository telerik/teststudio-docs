using System;
using Telerik.MobileTesting.Data;
using Telerik.MobileTesting.Runtime;
using Telerik.MobileTesting.Framework;
using DemoMobileProject.CodedTests;

namespace DemoMobileProject.CodedTests.Android
{
	
	// It is mandatory for each test class to inherit AndroidTestBase class as shown below (this is set by default).
    public partial class SetDateWithCode: AndroidTestBase
    {				
		
				public void NavigateToDateControls()
				{
					// This will Tap on the Date control button in the demo app main menu
					this.ActiveDevice.Android.Tap(Elements.DemoAppMainMenu.GoToDateControlButton);
					
				}
				
				// This will set the date to 12/24/2016 using the Date constant from the helper class
				public void SetDate()
				{
					this.ActiveDevice.Android.SetDate(Elements.DateControl.DatePicker, new DateTime(2016, 12, 24));
				}
				
				public void VerifySetDateDayAndYear()
				{
					// The DatePicker control is different depending on the Android version 
					// this is handled in the IF/Else below so thath the same test method can be reused between different versions of android
					
					// Log the Androdi version of the device executing the test
					Log.WriteLine(this.ActiveDevice.SystemVersion);
					
					if (this.ActiveDevice.SystemVersion.StartsWith("5") || this.ActiveDevice.SystemVersion.StartsWith("6"))
					{
						// Verify the day property of the Date control using a constant from the helper class
						Assert.Equals(this.ActiveDevice.Android.GetPropertyValue(Elements.DateControl.android5MonthView, "mSelectedDay").ToString(), Constants.day);
						// Verify the year proeprty of the Date control using a constant from the helper class
						Assert.Equals(this.ActiveDevice.Android.GetPropertyValue(Elements.DateControl.android5MonthView, "mYear").ToString(), Constants.year);
					}
					else
					{
						// Verify the day property of the Date control using a constant from the helper class
						Assert.Equals(this.ActiveDevice.Android.GetPropertyValue(Elements.DateControl.DatePicker, "mDay").ToString(), Constants.day);
						// Verify the year proeprty of the Date control using a constant from the helper class
						Assert.Equals(this.ActiveDevice.Android.GetPropertyValue(Elements.DateControl.DatePicker, "mYear").ToString(), Constants.year);
					}
				}
	}
}