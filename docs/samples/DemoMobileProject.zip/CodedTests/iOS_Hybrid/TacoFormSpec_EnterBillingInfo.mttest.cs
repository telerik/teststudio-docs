using System;
using Telerik.MobileTesting.Data;
using Telerik.MobileTesting.Runtime;
using Telerik.MobileTesting.Framework;

namespace DemoMobileProject.CodedTests.Hybrid
{
	// It is mandatory for each test class to inherit HybridIOSTestBase class as shown below (this is set by default).
    public partial class TacoFormSpec_EnterBillingInfo_IOS: HybridIOSTestBase
    {				
		public void SetCreditCardRadio()
		{
			this.ActiveDevice.Web.ScrollToElement(Helper.BillingInfo_CardNum);
			this.ActiveDevice.Web.SetChecked(Helper.CheddaCard,true);
			Assert.IsTrue(this.ActiveDevice.Web.GetChecked(Helper.CheddaCard),this.ActiveDevice.Web.GetChecked(Helper.CheddaCard).ToString());
		}
		
		public void EnterCardNumber()
		{
			this.ActiveDevice.Web.SetValue(Helper.BillingInfo_CardNum,"1234-5678-9101-1121");
			Assert.IsTrue(this.ActiveDevice.Web.GetValue(Helper.BillingInfo_CardNum) == "1234-5678-9101-1121",this.ActiveDevice.Web.GetValue(Helper.BillingInfo_CardNum));
		}
		
		public void SelectExpirationMonth()
		{
			this.ActiveDevice.Web.SetSelectedValue(Helper.BillingInfo_ExpiryMonth,"03");
			Assert.IsTrue(this.ActiveDevice.Web.GetSelectedValue(Helper.BillingInfo_ExpiryMonth).Length == 1 ,this.ActiveDevice.Web.GetSelectedValue(Helper.BillingInfo_ExpiryMonth).Length.ToString());
			Assert.IsTrue(this.ActiveDevice.Web.GetSelectedValue(Helper.BillingInfo_ExpiryMonth)[0] == "03",this.ActiveDevice.Web.GetSelectedValue(Helper.BillingInfo_ExpiryMonth)[0]);
			
		}
		
		public void SelectExpirationYear()
		{
			this.ActiveDevice.Web.SetSelectedValue(Helper.BillingInfo_ExpiryYear,"2016");
			Assert.IsTrue(this.ActiveDevice.Web.GetSelectedValue(Helper.BillingInfo_ExpiryYear).Length == 1 ,this.ActiveDevice.Web.GetSelectedValue(Helper.BillingInfo_ExpiryYear).Length.ToString());
			Assert.IsTrue(this.ActiveDevice.Web.GetSelectedValue(Helper.BillingInfo_ExpiryYear)[0] == "2016",this.ActiveDevice.Web.GetSelectedValue(Helper.BillingInfo_ExpiryYear)[0]);
		}
	}
}