using System;
using Telerik.MobileTesting.Data;
using Telerik.MobileTesting.Runtime;
using Telerik.MobileTesting.Framework;

namespace DemoMobileProject
{
    public static class SharedElements
    {
			public static IOSQuery  UIStepperControl = new IOSQuery() { Class = "UIStepper", Index = 1};	
	}
	public static class Constants
	{
		public const string day = "24";
		public const string year = "2016";
		public const string expectedStepperValue = "6.0";
	}
	public static class Helper
	{
		public static WebQuery BillingInfo_CardType
		{
			get
			{
				WebQuery wq = new WebQuery();
				wq.ClassName = "cardType";
				return wq;
			}
		}
		
		public static WebQuery[] CheddaCard
		{
			get
			{
				WebQuery wq = BillingInfo_CardType;
				
				WebQuery wq1 = new WebQuery();
				wq1.TagName = "input";
				wq1.Index = 2;
				
				return new WebQuery[]{ wq, wq1};
			}
		}
		public static WebQuery BillingInfo_CardNum
		{
			get
			{
				WebQuery wq = new WebQuery();
				wq.Name = "cardNum";
				return wq;
			}
		}
		public static WebQuery BillingInfo_ExpiryMonth
		{
			get
			{
				WebQuery wq = new WebQuery();
				wq.Name = "expiryMonth";
				return wq;
			}
		}
		public static WebQuery BillingInfo_ExpiryYear
		{
			get
			{
				WebQuery wq = new WebQuery();
				wq.Name = "expiryYear";
				return wq;
			}
		}
		public static WebQuery ContactInfo_Name
		{
			get
			{
				WebQuery wq = new WebQuery();
				wq.Name = "name";
				return wq;
			}
		}
		public static WebQuery ContactInfo_Phone
		{
			get
			{
				WebQuery wq = new WebQuery();
				wq.Name = "phone";
				return wq;
			}
		}
		
		public static WebQuery ContactInfo_Email
		{
			get
			{
				WebQuery wq = new WebQuery();
				wq.Name = "email";
				return wq;
			}
		}
		
		public static WebQuery ContactInfo_Newsletter
		{
			get
			{
				WebQuery wq = new WebQuery();
				wq.Name = "newsletterSubscribe";
				return wq;
			}
		}
		
	}
}