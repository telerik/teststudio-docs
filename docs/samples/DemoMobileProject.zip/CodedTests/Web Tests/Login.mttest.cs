using System;
using Telerik.MobileTesting.Data;
using Telerik.MobileTesting.Runtime;
using Telerik.MobileTesting.Framework;

namespace DemoMobileProject.Web_Tests
{
	// It is mandatory for each test class to inherit WebTestBase class as shown below (this is set by default).
    public partial class Login: WebTestBase
    {			
		
		
		public void VerifySuccessfulLogin()
		{
			string expectedLoginInfo = "Welcome, Telerik user";
			string loginInfo = this.ActiveDevice.Web.GetTextContent(Elements.SampleApp.LogInInfo);
			Assert.Equals(expectedLoginInfo,loginInfo);
		}
	}
}