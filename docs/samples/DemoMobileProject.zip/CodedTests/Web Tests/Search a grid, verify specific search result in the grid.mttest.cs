using System;
using Telerik.MobileTesting.Data;
using Telerik.MobileTesting.Runtime;
using Telerik.MobileTesting.Framework;

namespace DemoMobileProject.Web_Tests
{
	// It is mandatory for each test class to inherit WebTestBase class as shown below (this is set by default).
    public partial class Search_a_grid__verify_specific_search_result_in_the_grid: WebTestBase
    {				
		public void VerifyRowCount()
		{
			uint expectedRowCount = 3;
			uint rowCount = this.ActiveDevice.Web.GetRowCount(Elements.SampleApp.InboxTable);
			Assert.Equals(rowCount, expectedRowCount);
		}
		
		public void VerifyFilteredName() 
		{
			string expectedName = "Jim Holmes";
			string RecipientName = this.ActiveDevice.Web.GetTextContent(Elements.SampleApp.FirstRowSecondColumn);
			Assert.Equals(RecipientName, expectedName);
		}
	}
	

}