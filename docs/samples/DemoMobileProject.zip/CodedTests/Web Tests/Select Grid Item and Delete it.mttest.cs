using System;
using Telerik.MobileTesting.Data;
using Telerik.MobileTesting.Runtime;
using Telerik.MobileTesting.Framework;

namespace DemoMobileProject.Web_Tests
{
	// It is mandatory for each test class to inherit WebTestBase class as shown below (this is set by default).
    public partial class Select_Grid_Item_and_Delete_it: WebTestBase
    {				
		public void VerifyNumberOfRowsAndContent()
		{
			uint expectedRowNumber = 2;
			uint rowsNumber = this.ActiveDevice.Web.GetRowCount(Elements.SampleApp.TrashTable);
			Assert.Equals(expectedRowNumber, rowsNumber);
			
			// Verify the contents of the first row
			
			string expectedName = "Jim Holmes";
			string deletedEntry = this.ActiveDevice.Web.GetTextContent(Elements.SampleApp.TrashTableEntry);
			Assert.Equals(expectedName, deletedEntry);
			
		}
		
	}
}