using System;
using Telerik.MobileTesting.Data;
using Telerik.MobileTesting.Runtime;
using Telerik.MobileTesting.Framework;
using DemoMobileProject.CodedTests;

namespace DemoMobileProject.CodedTests.IOS
{
	// It is mandatory for each test class to inherit IOSTestBase class as shown below (this is set by default).
    public partial class UIStepperSetValueInCode: IOSTestBase
    {				
				public void NavigateToUIStepper()
				{
					this.ActiveDevice.IOS.SelectRow(Elements.DemoAppMainMenu.MenuUITable, 3, 0);
				}
				
				public void SetValueToUIStepper()
				{
					// This will set the value of the second UIStepper to 6 and will use an element query set in the HelperClass
					this.ActiveDevice.IOS.SetValue(SharedElements.UIStepperControl, 6.0);
				}
				public void VerifySetValue() 
				{
					// This will get the value of the stepper (element query is still set in the helperClass) and save it as string
					string stepperValue = this.ActiveDevice.IOS.GetPropertyValue(SharedElements.UIStepperControl, "value");
					// In this statment will will assert thath the current value of the UIStepper matches the expected one set as constant in the helperClass
					Assert.Equals(stepperValue, Constants.expectedStepperValue);
				}

	}
}