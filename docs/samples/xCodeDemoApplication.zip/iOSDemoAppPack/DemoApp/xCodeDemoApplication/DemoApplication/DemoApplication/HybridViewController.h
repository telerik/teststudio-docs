//
//  HybridViewController.h
//  DemoApplication
//
//  Created by Bulent Karaahmed on 8/26/16.
//  Copyright 2016 Telerik. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HybridViewController : UIViewController <UIWebViewDelegate>

@property (retain, nonatomic) IBOutlet UIWebView *ctlUIWebView;


@end
