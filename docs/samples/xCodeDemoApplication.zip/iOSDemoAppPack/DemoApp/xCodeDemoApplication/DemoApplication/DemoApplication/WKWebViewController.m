//
//  WKWebViewController.m
//  DemoApplication
//
//  Created by Robert Shoemate on 10/1/15.
//  Copyright © 2015 Telerik. All rights reserved.
//

#import "WKWebViewController.h"
@import WebKit;

@interface WKWebViewController ()

@property (nonatomic, retain) WKWebView *webView;

@end

@implementation WKWebViewController

- (void)dealloc {
    [self->_webView release];
    [super dealloc];
}

- (void)loadView{
    self.webView = [[[WKWebView alloc] init] autorelease];
    self.view = self.webView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSURL *url = [[NSURL alloc] initWithString:@"http://demos.telerik.com/mobile-testing/tacos/"];
    [self.webView loadRequest:[NSURLRequest requestWithURL:url]];
    [url release];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.title = @"WKWebView";
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - SupportedOS Implementation
- (BOOL)doesCurrentDeviceOSSupportController {
    if ([[[UIDevice currentDevice] systemVersion] compare:@"8.0" options:NSNumericSearch] != NSOrderedAscending)
        return YES;
    return NO;
}

+ (BOOL)shouldLoadNib {
    return NO;
}

@end
