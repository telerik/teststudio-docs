//
//  WKHybridViewController.h
//  DemoApplication
//
//  Created by Bulent Karaahmed on 15/12/16.
//  Copyright 2016 Telerik. All rights reserved.
//

#import <WebKit/WebKit.h>
#import <UIKit/UIKit.h>
#import "SupportedOS.h"

@interface WKHybridViewController : UIViewController <WKNavigationDelegate, SupportedOS>

@property (retain, nonatomic) IBOutlet UIView *containerView; 
@property (strong, nonatomic) WKWebView *webView;

@end
