var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Storage;
        (function (Storage) {
            var StateInfo = (function () {
                function StateInfo() {
                }
                return StateInfo;
            }());
            Storage.StateInfo = StateInfo;
        })(Storage = MobileTesting.Storage || (MobileTesting.Storage = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Storage;
        (function (Storage) {
            var HybridStorageHandler = (function () {
                function HybridStorageHandler() {
                    this.storageReady = false;
                    this.callbacks = new Array();
                }
                Object.defineProperty(HybridStorageHandler.prototype, "CachedInfo", {
                    get: function () {
                        return this.cachedInfo;
                    },
                    enumerable: true,
                    configurable: true
                });
                HybridStorageHandler.prototype.getStateInfo = function (callback) {
                    this.callbacks.push(callback);
                };
                HybridStorageHandler.prototype.addValueToState = function (key, value) {
                };
                HybridStorageHandler.prototype.setState = function (state) {
                    this.cachedInfo = state;
                    this.callbacks.forEach(function (cb) {
                        cb(state);
                    });
                };
                return HybridStorageHandler;
            }());
            Storage.HybridStorageHandler = HybridStorageHandler;
        })(Storage = MobileTesting.Storage || (MobileTesting.Storage = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Common;
        (function (Common) {
            var EventEmitter = (function () {
                function EventEmitter() {
                    this.handlers = [];
                }
                EventEmitter.prototype.on = function (handler) {
                    this.handlers.push(handler);
                };
                EventEmitter.prototype.off = function (handler) {
                    var remove = this.handlers.indexOf(handler);
                    this.handlers.splice(remove, 1);
                };
                EventEmitter.prototype.trigger = function (data) {
                    this.handlers.forEach(function (h) { return h(data); });
                };
                EventEmitter.prototype.triggerWrap = function (eventName, data) {
                    var msgData = {
                        eventName: eventName,
                        data: data
                    };
                    this.trigger(msgData);
                };
                EventEmitter.prototype.clear = function () {
                    this.handlers = [];
                };
                return EventEmitter;
            }());
            Common.EventEmitter = EventEmitter;
        })(Common = MobileTesting.Common || (MobileTesting.Common = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Communication;
        (function (Communication) {
            var MessageFactory = (function () {
                function MessageFactory() {
                }
                MessageFactory.prototype.getFromMessageData = function (msgData) {
                    var msgObject = JSON.parse(msgData);
                    if (msgObject == undefined || msgObject.data == undefined)
                        return undefined;
                    var msg;
                    if (msgObject.data.handshake != undefined) {
                        msg = new Communication.Message(Communication.MessageTypes.Handshake);
                    }
                    else if (msgObject.data.error != undefined) {
                        msg = new Communication.Message(Communication.MessageTypes.Error);
                    }
                    else if (msgObject.data.cmd != undefined && msgObject.data.cmd == MobileTesting.Commands.WebApiProtocol.ControlGetElements) {
                        msg = new Communication.Message(Communication.MessageTypes.GetElements);
                    }
                    else if (msgObject.data.cmd != undefined && msgObject.data.cmd == MobileTesting.Commands.WebApiProtocol.ControlSubscribe) {
                        msg = new Communication.Message(Communication.MessageTypes.Subscribe);
                    }
                    else if (msgObject.data.cmd != undefined && msgObject.data.cmd == MobileTesting.Commands.WebApiProtocol.ControlUnsubscribe) {
                        msg = new Communication.Message(Communication.MessageTypes.Unsubscribe);
                    }
                    else if (msgObject.data.cmd != undefined && msgObject.data.cmd == MobileTesting.Commands.WebApiProtocol.ExecuteCommand) {
                        msg = new Communication.ExecCommandMessage(msgObject.data);
                    }
                    else if (msgObject.data.cmd != undefined && msgObject.data.cmd == MobileTesting.Commands.WebApiProtocol.DialogsCommand) {
                        msg = new Communication.DialogCommandMessage(msgObject.data);
                    }
                    if (msg == null) {
                        console.warn("Unknow message: " + msgData);
                        return;
                    }
                    msg.data = msgObject.data;
                    msg.Id = msgObject.id;
                    msg.FromId = msgObject.fromId;
                    msg.ToId = msgObject.toId;
                    return msg;
                };
                return MessageFactory;
            }());
            Communication.MessageFactory = MessageFactory;
        })(Communication = MobileTesting.Communication || (MobileTesting.Communication = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Communication;
        (function (Communication) {
            (function (MessageTypes) {
                MessageTypes[MessageTypes["NotSet"] = 0] = "NotSet";
                MessageTypes[MessageTypes["Error"] = 1] = "Error";
                MessageTypes[MessageTypes["Handshake"] = 2] = "Handshake";
                MessageTypes[MessageTypes["Command"] = 3] = "Command";
                MessageTypes[MessageTypes["DialogCommand"] = 4] = "DialogCommand";
                MessageTypes[MessageTypes["Subscribe"] = 5] = "Subscribe";
                MessageTypes[MessageTypes["Unsubscribe"] = 6] = "Unsubscribe";
                MessageTypes[MessageTypes["GetElements"] = 7] = "GetElements";
            })(Communication.MessageTypes || (Communication.MessageTypes = {}));
            var MessageTypes = Communication.MessageTypes;
            var Message = (function () {
                function Message(msgType) {
                    this.msgType = msgType;
                }
                Object.defineProperty(Message.prototype, "Id", {
                    get: function () {
                        return this.id;
                    },
                    set: function (value) {
                        this.id = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Message.prototype, "ToId", {
                    get: function () {
                        return this.toId;
                    },
                    set: function (value) {
                        this.toId = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Message.prototype, "FromId", {
                    get: function () {
                        return this.fromId;
                    },
                    set: function (value) {
                        this.fromId = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Message.prototype, "MsgType", {
                    get: function () {
                        return this.msgType;
                    },
                    enumerable: true,
                    configurable: true
                });
                return Message;
            }());
            Communication.Message = Message;
            var ExecCommandMessage = (function (_super) {
                __extends(ExecCommandMessage, _super);
                function ExecCommandMessage(data) {
                    _super.call(this, MessageTypes.Command);
                    this.data = data;
                }
                Object.defineProperty(ExecCommandMessage.prototype, "Action", {
                    get: function () {
                        return this.data["params"]["action"];
                    },
                    enumerable: true,
                    configurable: true
                });
                ExecCommandMessage.prototype.getActionParam = function (key) {
                    return this.data["params"]["params"][key];
                };
                ExecCommandMessage.prototype.getWebQuery = function () {
                    return this.data["params"]["query"];
                };
                return ExecCommandMessage;
            }(Message));
            Communication.ExecCommandMessage = ExecCommandMessage;
            var DialogCommandMessage = (function (_super) {
                __extends(DialogCommandMessage, _super);
                function DialogCommandMessage(data) {
                    _super.call(this, MessageTypes.DialogCommand);
                }
                Object.defineProperty(DialogCommandMessage.prototype, "Action", {
                    get: function () {
                        return this.data["params"]["action"];
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DialogCommandMessage.prototype, "Key", {
                    get: function () {
                        return this.getActionParam("key");
                    },
                    enumerable: true,
                    configurable: true
                });
                DialogCommandMessage.prototype.getActionParam = function (key) {
                    return this.data["params"]["params"][key];
                };
                DialogCommandMessage.prototype.getWebQuery = function () {
                    return undefined;
                };
                return DialogCommandMessage;
            }(Message));
            Communication.DialogCommandMessage = DialogCommandMessage;
        })(Communication = MobileTesting.Communication || (MobileTesting.Communication = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Communication;
        (function (Communication) {
            var MessageEventArgs = (function () {
                function MessageEventArgs(evName, msg) {
                    this.eventName = evName;
                    this.data = msg;
                }
                return MessageEventArgs;
            }());
            Communication.MessageEventArgs = MessageEventArgs;
        })(Communication = MobileTesting.Communication || (MobileTesting.Communication = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Communication;
        (function (Communication) {
            var HybridBridgeClient = (function () {
                function HybridBridgeClient() {
                    this.onMessageSend = new MobileTesting.Common.EventEmitter();
                    this.onMessageReceived = new MobileTesting.Common.EventEmitter();
                    this.messageFactory = new Communication.MessageFactory();
                }
                Object.defineProperty(HybridBridgeClient.prototype, "MessageReceived", {
                    get: function () {
                        return this.onMessageReceived;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(HybridBridgeClient.prototype, "MessageSend", {
                    get: function () {
                        return this.onMessageSend;
                    },
                    enumerable: true,
                    configurable: true
                });
                HybridBridgeClient.prototype.start = function (wsUrl) {
                };
                HybridBridgeClient.prototype.send = function (msg) {
                    var res = {
                        data: msg.response,
                        responseToMessageId: msg.Id,
                        toId: msg.FromId,
                        fromId: msg.ToId,
                        id: msg.Id
                    };
                    this.onMessageSend.triggerWrap("SendMessage", JSON.stringify(res));
                };
                HybridBridgeClient.prototype.handleMessage = function (msgData) {
                    var msg = this.messageFactory.getFromMessageData(msgData);
                    if (msg === undefined)
                        return;
                    var msgEventArgs = {
                        eventName: "Message",
                        data: msg
                    };
                    this.onMessageReceived.trigger(msgEventArgs);
                };
                return HybridBridgeClient;
            }());
            Communication.HybridBridgeClient = HybridBridgeClient;
        })(Communication = MobileTesting.Communication || (MobileTesting.Communication = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        (function (ManagerStates) {
            ManagerStates[ManagerStates["Ready"] = 0] = "Ready";
            ManagerStates[ManagerStates["Disconnected"] = 1] = "Disconnected";
        })(MobileTesting.ManagerStates || (MobileTesting.ManagerStates = {}));
        var ManagerStates = MobileTesting.ManagerStates;
        var Manager = (function () {
            function Manager(sc, st) {
                var _this = this;
                this.stateChangedEvent = "stateChanged";
                this.state = ManagerStates.Disconnected;
                this.executionHandler = new MobileTesting.Execution.ExecutionHandler();
                this.recorderHandler = new MobileTesting.Recording.RecordingHandler();
                this.onStateChanged = new MobileTesting.Common.EventEmitter();
                this.onError = new MobileTesting.Common.EventEmitter();
                this.socketClient = sc;
                this.storage = st;
                this.socketClient.MessageReceived.on(function (args) {
                    if (args.eventName == "Message") {
                        _this.handleMessage(args.data);
                    }
                    else if (args.eventName == "Disconnect") {
                        _this.handleDisconnect();
                    }
                });
                this.executionHandler.ActionExecuted.on(function (e) { return _this.onActionExecuted(e.data); });
            }
            Object.defineProperty(Manager.prototype, "Error", {
                get: function () {
                    return this.onError;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Manager.prototype, "StateChanged", {
                get: function () {
                    return this.onStateChanged;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Manager.prototype, "State", {
                get: function () {
                    return this.state;
                },
                enumerable: true,
                configurable: true
            });
            Manager.prototype.start = function (host) {
                this.socketClient.start(host);
            };
            Manager.prototype.handleMessage = function (msg) {
                switch (msg.MsgType) {
                    case MobileTesting.Communication.MessageTypes.Handshake: {
                        this.handleHandshakeCommands(msg);
                        break;
                    }
                    case MobileTesting.Communication.MessageTypes.Error: {
                        this.handleServerError(msg);
                        break;
                    }
                    case MobileTesting.Communication.MessageTypes.GetElements: {
                        this.handleGetElements(msg);
                        break;
                    }
                    case MobileTesting.Communication.MessageTypes.Subscribe: {
                        this.handleSubscribe(msg);
                        break;
                    }
                    case MobileTesting.Communication.MessageTypes.Unsubscribe: {
                        this.handleUnsubscribe(msg);
                        break;
                    }
                    case MobileTesting.Communication.MessageTypes.Command: {
                        this.handleExecuteCommands(msg);
                        break;
                    }
                    case MobileTesting.Communication.MessageTypes.DialogCommand: {
                        this.handleDailogCommand(msg);
                        break;
                    }
                }
            };
            Manager.prototype.handleHandshakeCommands = function (msg) {
                if (msg.data.handshake == MobileTesting.Communication.TsAutomationProtocol.Messages.HandShakeGetClientInfo) {
                    var bi = MobileTesting.Utils.Browser.getClientInfo();
                    var cap = MobileTesting.Communication.TsAutomationProtocol.Capabilities;
                    bi.capabilities = [MobileTesting.Communication.TsAutomationProtocol.Capabilities.AUTOMATION_EXECUTION_AGENT];
                    bi.identity = { "sharedKey": MobileTesting.Communication.TsAutomationProtocol.Identity.sharedKey, "resumeId": this.storage.CachedInfo.resumeId };
                    msg.response = bi;
                    this.socketClient.send(msg);
                }
                else if (msg.data.handshake == MobileTesting.Communication.TsAutomationProtocol.Messages.HandShakeAccepted) {
                    this.storage.addValueToState("resumeId", msg.data.id);
                    this.state = ManagerStates.Ready;
                    this.onStateChanged.triggerWrap("StateChanged", this.state);
                    console.log("HandShakeAccepted: " + msg.data.id);
                    this.setRecordMode();
                }
            };
            Manager.prototype.handleDisconnect = function () {
                console.warn("Disconnecting");
                this.state = ManagerStates.Disconnected;
                this.onStateChanged.triggerWrap("StateChanged", this.state);
                if (this.storage.CachedInfo.autoReconnect)
                    this.autoReconnect();
            };
            Manager.prototype.handleServerError = function (msg) {
                if (msg.data.error && msg.data.error.code == MobileTesting.Communication.TsAutomationProtocol.Errors.RecipientNotFoundCode) {
                    this.removeSubscriber(msg.data.params.recipient);
                }
                this.onError.triggerWrap("Error", msg.data.error);
            };
            Manager.prototype.handleExecuteCommands = function (msg) {
                this.executionHandler.handleExecCommand(msg);
            };
            Manager.prototype.handleDailogCommand = function (msg) {
                this.executionHandler.handleDialogCommand(msg);
            };
            Manager.prototype.handleGetElements = function (msg) {
                var elements = Telerik.MobileTesting.Elements.DomTree.buildDomTree();
                var result = {};
                result.Result = {
                    Code: MobileTesting.Communication.TsAutomationProtocol.ResultCodes.Success,
                    Reason: ""
                };
                result.Params = { elements: elements, navHash: MobileTesting.Elements.NavHashInfo.getNavHash() };
                msg.response = result;
                this.socketClient.send(msg);
            };
            Manager.prototype.handleSubscribe = function (msg) {
                var _this = this;
                this.storage.getStateInfo(function (stateInfo) {
                    if (stateInfo.subscribers == undefined)
                        stateInfo.subscribers = new Array();
                    stateInfo.subscribers.push(msg.FromId);
                    _this.storage.addValueToState("subscribers", stateInfo.subscribers);
                    _this.setRecordMode();
                    var result = {};
                    result.Result = {
                        Code: MobileTesting.Communication.TsAutomationProtocol.ResultCodes.Success,
                        Reason: ""
                    };
                    result.Params = { "scriptResult": true };
                    msg.response = result;
                    _this.socketClient.send(msg);
                });
            };
            Manager.prototype.handleUnsubscribe = function (msg) {
                var _this = this;
                this.storage.getStateInfo(function (stateInfo) {
                    if (stateInfo.subscribers == undefined)
                        return;
                    _this.removeSubscriber(msg.FromId);
                    var result = {};
                    result.Result = {
                        Code: MobileTesting.Communication.TsAutomationProtocol.ResultCodes.Success,
                        Reason: ""
                    };
                    result.Params = { "scriptResult": true };
                    msg.response = result;
                    _this.socketClient.send(msg);
                });
            };
            Manager.prototype.onActionExecuted = function (msg) {
                this.socketClient.send(msg);
            };
            Manager.prototype.onActionRecorded = function (msg) {
                for (var i = 0; i < this.storage.CachedInfo.subscribers.length; i++) {
                    var subscriber = this.storage.CachedInfo.subscribers[i];
                    msg.FromId = subscriber;
                    msg.Id = this.storage.CachedInfo.resumeId;
                    msg.ToId = this.storage.CachedInfo.resumeId;
                    this.socketClient.send(msg);
                }
            };
            Manager.prototype.setRecordMode = function () {
                var _this = this;
                if (this.storage.CachedInfo.subscribers != undefined && this.storage.CachedInfo.subscribers.length > 0 && !this.recorderHandler.IsRecording) {
                    this.recorderHandler.start();
                    this.recorderHandler.ActionRecorded.on(function (arg) { return _this.onActionRecorded(arg.data); });
                }
            };
            Manager.prototype.removeSubscriber = function (id) {
                var index = this.storage.CachedInfo.subscribers.indexOf(id);
                if (index != -1) {
                    this.storage.CachedInfo.subscribers.splice(index, 1);
                    this.storage.addValueToState("subscribers", this.storage.CachedInfo.subscribers);
                }
                if (this.storage.CachedInfo.subscribers.length == 0)
                    this.recorderHandler.stop();
            };
            Manager.prototype.autoReconnect = function () {
                var _this = this;
                var interval = setInterval(function () {
                    if (_this.state == ManagerStates.Disconnected) {
                        _this.start(_this.storage.CachedInfo.wsUrl);
                    }
                    else {
                        clearInterval(interval);
                    }
                }, 3000);
            };
            return Manager;
        }());
        MobileTesting.Manager = Manager;
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Agent = (function () {
            function Agent() {
                this.bridgeClient = new MobileTesting.Communication.HybridBridgeClient();
                this.storage = new MobileTesting.Storage.HybridStorageHandler();
                this.started = false;
            }
            Object.defineProperty(Agent.prototype, "Storage", {
                get: function () {
                    return this.storage;
                },
                enumerable: true,
                configurable: true
            });
            Agent.prototype.start = function () {
                var _this = this;
                console.log("## Telerik.MobileTesting.Agent - Start ##");
                this.storage.getStateInfo(function (si) {
                    if (!_this.started) {
                        _this.started = true;
                        _this.bridgeClient.MessageSend.on(function (e) {
                            _this.sendMessage(e.data);
                        });
                    }
                    var manager = new MobileTesting.Manager(_this.bridgeClient, _this.storage);
                    manager.start(si.wsUrl);
                });
            };
            Agent.prototype.handleMessage = function (msg) {
                this.bridgeClient.handleMessage(msg);
            };
            Agent.prototype.sendMessage = function (response) {
                for (var i = 0; i < this.storage.CachedInfo.subscribers.length; i++) {
                    var subscriber = this.storage.CachedInfo.subscribers[i];
                    if (subscriber == "internal") {
                        _tsRecCallbacks.rawValue(response, window["__telerikMobileStateInfo"].nativeQuery);
                    }
                }
                return response;
            };
            return Agent;
        }());
        MobileTesting.Agent = Agent;
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var _tsRecCallbacks;
var agent = new Telerik.MobileTesting.Agent();
agent.start();
var iOSBridge = "The first line of iOS bridge ";
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Collections;
        (function (Collections) {
            var Dictionary = (function () {
                function Dictionary() {
                    this.tList = new Array();
                }
                Dictionary.prototype.add = function (key, value) {
                    var t = { key: key, value: value };
                    for (var i = 0; i < this.tList.length; i++) {
                        var item = this.tList[i];
                        if (item.key == key) {
                            this.tList.splice(i, 1);
                            break;
                        }
                    }
                    this.tList.push(t);
                };
                Dictionary.prototype.remove = function (key) {
                    for (var i = 0; i < this.tList.length; i++) {
                        var item = this.tList[i];
                        if (item.key == key) {
                            this.tList.splice(i, 1);
                            break;
                        }
                    }
                };
                Dictionary.prototype.getValue = function (key) {
                    for (var _i = 0, _a = this.tList; _i < _a.length; _i++) {
                        var item = _a[_i];
                        if (item.key == key)
                            return item.value;
                    }
                    return undefined;
                };
                return Dictionary;
            }());
            Collections.Dictionary = Dictionary;
        })(Collections = MobileTesting.Collections || (MobileTesting.Collections = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Commands = (function () {
                function Commands() {
                }
                Commands.IsReady = "isReady";
                Commands.Navigate = "navigate";
                Commands.Tap = "tap";
                Commands.Hover = "hover";
                Commands.Click = "click";
                Commands.DoubleClick = "doubleClick";
                Commands.PressKey = "pressKey";
                Commands.ExecuteScript = "executeScript";
                Commands.Scroll = "scroll";
                Commands.Swipe = "swipe";
                Commands.Drag = "drag";
                Commands.DragToPoint = "dragToPoint";
                Commands.Pinch = "pinch";
                Commands.Html = "html";
                Commands.GetCount = "getCount";
                Commands.Attribute = "attribute";
                Commands.Style = "style";
                Commands.Value = "value";
                Commands.SelectedValue = "selectedValue";
                Commands.SelectedText = "selectedText";
                Commands.SelectedIndex = "selectedIndex";
                Commands.Checked = "checked";
                Commands.TextContent = "textContent";
                Commands.Paused = "paused";
                Commands.TwoFingerRotate = "twoFingerRotate";
                Commands.GetInError = "getInError";
                return Commands;
            }());
            Execution.Commands = Commands;
            var DialogCommands = (function () {
                function DialogCommands() {
                }
                DialogCommands.Prepare = "prepare";
                DialogCommands.GetState = "getState";
                return DialogCommands;
            }());
            Execution.DialogCommands = DialogCommands;
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik_1) {
    var MobileTesting;
    (function (MobileTesting_1) {
        var Commands;
        (function (Commands_1) {
            var WebApiProtocol = (function () {
                function WebApiProtocol() {
                }
                WebApiProtocol.ControlCommand = "ctrl";
                WebApiProtocol.ControlSubscribe = "ctrl.subscribe";
                WebApiProtocol.ControlUnsubscribe = "ctrl.unsubscribe";
                WebApiProtocol.ControlGetElements = "ctrl.getElements";
                WebApiProtocol.ExecuteCommand = "web.execute";
                WebApiProtocol.RecordCommand = "web.record";
                WebApiProtocol.DialogsCommand = "web.dialogs";
                return WebApiProtocol;
            }());
            Commands_1.WebApiProtocol = WebApiProtocol;
            var Telerik;
            (function (Telerik) {
                var MobileTesting;
                (function (MobileTesting) {
                    var Commands;
                    (function (Commands_2) {
                        var Control;
                        (function (Control) {
                            var Commands = (function () {
                                function Commands() {
                                }
                                Commands.Launch = "launch";
                                Commands.Close = "close";
                                return Commands;
                            }());
                            Control.Commands = Commands;
                        })(Control = Commands_2.Control || (Commands_2.Control = {}));
                    })(Commands = MobileTesting.Commands || (MobileTesting.Commands = {}));
                })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
            })(Telerik || (Telerik = {}));
        })(Commands = MobileTesting_1.Commands || (MobileTesting_1.Commands = {}));
    })(MobileTesting = Telerik_1.MobileTesting || (Telerik_1.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Common;
        (function (Common) {
            var AgentSpecs = (function () {
                function AgentSpecs() {
                }
                AgentSpecs.supportsGestures = function () {
                };
                return AgentSpecs;
            }());
            Common.AgentSpecs = AgentSpecs;
        })(Common = MobileTesting.Common || (MobileTesting.Common = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Common;
        (function (Common) {
            var AnnotationService = (function () {
                function AnnotationService() {
                }
                Object.defineProperty(AnnotationService, "instance", {
                    get: function () {
                        if (AnnotationService._instance == undefined)
                            AnnotationService._instance = new AnnotationService();
                        return AnnotationService._instance;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(AnnotationService.prototype, "IsEnabled", {
                    get: function () {
                        return this._isEnabled;
                    },
                    set: function (v) {
                        this._isEnabled = v;
                        if (!v)
                            this.disable();
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(AnnotationService.prototype, "Canvas", {
                    get: function () {
                        if (this._canvas == null) {
                            var rect = document.body.getBoundingClientRect();
                            this._canvas = document.createElement("canvas");
                            this._canvas.style.top = "0";
                            this._canvas.style.left = "0";
                            this._canvas.style.position = "absolute";
                            this._canvas.style.zIndex = "10000";
                            this._canvas.style.width = rect.width.toString();
                            this._canvas.style.height = rect.height.toString();
                            document.body.appendChild(this._canvas);
                        }
                        return this._canvas;
                    },
                    enumerable: true,
                    configurable: true
                });
                AnnotationService.prototype.drawPoint = function (point) {
                    if (!this.IsEnabled)
                        return;
                    var context = this.getContext();
                    this.draw(context, point);
                };
                AnnotationService.prototype.drawPoints = function (points) {
                    var _this = this;
                    if (!this.IsEnabled)
                        return;
                    setTimeout(function () {
                        var context = _this.getContext();
                        for (var i = 0; i < points.length; i++) {
                            _this.draw(context, points[i]);
                        }
                    }, 50);
                };
                AnnotationService.prototype.disable = function () {
                    if (this._canvas == undefined)
                        return;
                    document.body.removeChild(this._canvas);
                    this._canvas = undefined;
                };
                AnnotationService.prototype.getContext = function () {
                    var rect = this.Canvas.getBoundingClientRect();
                    var context = this.Canvas.getContext("2d");
                    context.fillStyle = "yellow";
                    context.clearRect(0, 0, rect.width, rect.height);
                    return context;
                };
                AnnotationService.prototype.draw = function (context, point) {
                    context.beginPath();
                    context.arc(Math.floor(point.x), Math.floor(point.y), 10, 0, 2 * Math.PI, false);
                    context.stroke();
                    context.fill();
                };
                return AnnotationService;
            }());
            Common.AnnotationService = AnnotationService;
        })(Common = MobileTesting.Common || (MobileTesting.Common = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Communication;
        (function (Communication) {
            var TsAutomationProtocol = (function () {
                function TsAutomationProtocol() {
                }
                TsAutomationProtocol.Name = "ts-automation-protocol";
                TsAutomationProtocol.Version = 3;
                return TsAutomationProtocol;
            }());
            Communication.TsAutomationProtocol = TsAutomationProtocol;
        })(Communication = MobileTesting.Communication || (MobileTesting.Communication = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Communication;
        (function (Communication) {
            var TsAutomationProtocol;
            (function (TsAutomationProtocol) {
                var Messages = (function () {
                    function Messages() {
                    }
                    Messages.HandShakeAccepted = "hs_accepted";
                    Messages.HandShakeGetClientInfo = "hs_get_client_info";
                    return Messages;
                }());
                TsAutomationProtocol.Messages = Messages;
            })(TsAutomationProtocol = Communication.TsAutomationProtocol || (Communication.TsAutomationProtocol = {}));
        })(Communication = MobileTesting.Communication || (MobileTesting.Communication = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Communication;
        (function (Communication) {
            var TsAutomationProtocol;
            (function (TsAutomationProtocol) {
                var Errors = (function () {
                    function Errors() {
                    }
                    Errors.RecipientNotFoundCode = 120;
                    return Errors;
                }());
                TsAutomationProtocol.Errors = Errors;
            })(TsAutomationProtocol = Communication.TsAutomationProtocol || (Communication.TsAutomationProtocol = {}));
        })(Communication = MobileTesting.Communication || (MobileTesting.Communication = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Communication;
        (function (Communication) {
            var TsAutomationProtocol;
            (function (TsAutomationProtocol) {
                var Capabilities = (function () {
                    function Capabilities() {
                    }
                    Capabilities.AUTOMATION_EXECUTION_AGENT = "automation_execution_agent";
                    return Capabilities;
                }());
                TsAutomationProtocol.Capabilities = Capabilities;
            })(TsAutomationProtocol = Communication.TsAutomationProtocol || (Communication.TsAutomationProtocol = {}));
        })(Communication = MobileTesting.Communication || (MobileTesting.Communication = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Communication;
        (function (Communication) {
            var TsAutomationProtocol;
            (function (TsAutomationProtocol) {
                var Identity = (function () {
                    function Identity() {
                    }
                    Identity.sharedKey = "5e2e79fa-a3b3-9b65-a9ee-dafa1d83fc68";
                    return Identity;
                }());
                TsAutomationProtocol.Identity = Identity;
            })(TsAutomationProtocol = Communication.TsAutomationProtocol || (Communication.TsAutomationProtocol = {}));
        })(Communication = MobileTesting.Communication || (MobileTesting.Communication = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Communication;
        (function (Communication) {
            var TsAutomationProtocol;
            (function (TsAutomationProtocol) {
                var ResultCodes = (function () {
                    function ResultCodes() {
                    }
                    ResultCodes.Success = 100;
                    ResultCodes.Error = 200;
                    return ResultCodes;
                }());
                TsAutomationProtocol.ResultCodes = ResultCodes;
            })(TsAutomationProtocol = Communication.TsAutomationProtocol || (Communication.TsAutomationProtocol = {}));
        })(Communication = MobileTesting.Communication || (MobileTesting.Communication = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Elements;
        (function (Elements) {
            var DomElement = (function () {
                function DomElement(target) {
                    this.platformKey = Elements.Constants.PlatformKey;
                    this.properties = {};
                    this.type = target.tagName;
                    this.typeChain = target.tagName;
                }
                Object.defineProperty(DomElement.prototype, "Identifier", {
                    get: function () {
                        return this.identifier;
                    },
                    set: function (value) {
                        this.identifier = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DomElement.prototype, "Type", {
                    get: function () {
                        return this.type;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DomElement.prototype, "Children", {
                    get: function () {
                        return this.children;
                    },
                    set: function (value) {
                        this.children = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DomElement.prototype, "Properties", {
                    get: function () {
                        return this.properties;
                    },
                    enumerable: true,
                    configurable: true
                });
                return DomElement;
            }());
            Elements.DomElement = DomElement;
        })(Elements = MobileTesting.Elements || (MobileTesting.Elements = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Elements;
        (function (Elements) {
            var DomTree = (function () {
                function DomTree() {
                }
                DomTree.buildDomTree = function () {
                    DomTree.counter = 0;
                    var domElements = new Array();
                    try {
                        domElements = DomTree.buildDomRecursive(window.document.documentElement.childNodes);
                    }
                    catch (err) {
                        console.error(err);
                    }
                    return domElements;
                };
                DomTree.buildDomRecursive = function (nodes) {
                    var domElements = new Array();
                    var count = nodes.length;
                    for (var i = 0; i < count; i++) {
                        var node = nodes[i];
                        var de = DomTree.buildDomElement(node);
                        if (node.childNodes.length > 0) {
                            de.Children = DomTree.buildDomRecursive(node.childNodes);
                        }
                        if (de.Type != undefined && de.Type != "") {
                            de.Identifier = DomTree.counter;
                            domElements.push(de);
                            DomTree.counter++;
                        }
                    }
                    return domElements;
                };
                DomTree.buildDomElement = function (target) {
                    var de = new Elements.DomElement(target);
                    if (target.attributes !== undefined) {
                        for (var i = 0; i < target.attributes.length; i++) {
                            var attr = target.attributes[i];
                            if (typeof attr.value !== 'undefined')
                                de.Properties[attr.name] = attr.value;
                        }
                    }
                    var tagName = target.tagName ? target.tagName : "";
                    var tag = tagName.toLowerCase();
                    switch (tag) {
                        case "div":
                        case "b":
                        case "td":
                            de.Properties["textContent"] = target.textContent;
                            break;
                        case "input":
                        case "textarea":
                            de.Properties["value"] = target["value"];
                            de.Properties["textContent"] = target.textContent;
                            break;
                        case "select":
                            de.Properties['selectedValue'] = target["selectedValue"];
                            de.Properties['selectedIndex'] = target["selectedIndex"];
                            break;
                        case "option":
                            de.Properties["selected"] = target["selected"];
                            break;
                    }
                    return de;
                };
                return DomTree;
            }());
            Elements.DomTree = DomTree;
        })(Elements = MobileTesting.Elements || (MobileTesting.Elements = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var ActionBase = (function () {
                function ActionBase() {
                }
                Object.defineProperty(ActionBase.prototype, "Action", {
                    get: function () {
                        return "";
                    },
                    enumerable: true,
                    configurable: true
                });
                ActionBase.prototype.getSuccessResult = function (reason) {
                    var opResult = {
                        Code: MobileTesting.Communication.TsAutomationProtocol.ResultCodes.Success,
                        Reason: reason
                    };
                    return opResult;
                };
                ActionBase.prototype.getErrorResult = function (reason) {
                    var opResult = {
                        Code: MobileTesting.Communication.TsAutomationProtocol.ResultCodes.Error,
                        Reason: reason
                    };
                    return opResult;
                };
                ActionBase.prototype.getWebQuery = function (data) {
                    var qa = new Array();
                    var qData = data.getWebQuery();
                    if (qData == undefined)
                        return undefined;
                    for (var dwqIndex in qData) {
                        var q = new MobileTesting.Find.WebQuery();
                        var dwq = qData[dwqIndex];
                        if (dwq["id"])
                            q.id = dwq["id"];
                        if (dwq["className"])
                            q.className = dwq["className"];
                        if (dwq["name"])
                            q.name = dwq["name"];
                        if (dwq["tagName"])
                            q.tagName = dwq["tagName"];
                        if (dwq["querySelector"])
                            q.querySelector = dwq["querySelector"];
                        if (dwq["xpath"])
                            q.xpath = dwq["xpath"];
                        q.index = dwq["index"];
                        qa.push(q);
                    }
                    return qa;
                };
                ActionBase.prototype.getElement = function (data, throwErr) {
                    if (throwErr === void 0) { throwErr = true; }
                    var query = this.getWebQuery(data);
                    return this.getElementFromQuery(query, throwErr);
                };
                ActionBase.prototype.getElementFromQuery = function (query, throwErr) {
                    if (throwErr === void 0) { throwErr = true; }
                    var target = MobileTesting.Find.Finder.find(query);
                    if (target == undefined && throwErr)
                        throw "Element not found!";
                    return target;
                };
                return ActionBase;
            }());
            Execution.ActionBase = ActionBase;
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var ActionResult = (function () {
                function ActionResult() {
                }
                Object.defineProperty(ActionResult.prototype, "Result", {
                    get: function () {
                        return this.result;
                    },
                    set: function (value) {
                        this.result = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ActionResult.prototype, "Error", {
                    get: function () {
                        return this.error;
                    },
                    set: function (value) {
                        this.error = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ActionResult.prototype, "Params", {
                    get: function () {
                        return this.params;
                    },
                    set: function (value) {
                        this.params = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                return ActionResult;
            }());
            Execution.ActionResult = ActionResult;
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var ExecutionHandler = (function () {
                function ExecutionHandler() {
                    this.actions = new MobileTesting.Collections.Dictionary();
                    this.onActionExecuted = new MobileTesting.Common.EventEmitter();
                    this.loadActions();
                }
                Object.defineProperty(ExecutionHandler.prototype, "ActionExecuted", {
                    get: function () {
                        return this.onActionExecuted;
                    },
                    enumerable: true,
                    configurable: true
                });
                ExecutionHandler.prototype.handleExecCommand = function (msg) {
                    var _this = this;
                    var action = this.actions.getValue(msg.Action);
                    if (action == undefined)
                        return;
                    try {
                        action.handleAsync(msg, function (r) {
                            msg.response = r;
                            _this.onActionExecuted.triggerWrap("ActionExecuted", msg);
                        });
                    }
                    catch (err) {
                        msg.response = this.getErrorActionResult(err);
                        this.onActionExecuted.triggerWrap("ActionExecuted", msg);
                    }
                };
                ExecutionHandler.prototype.handleDialogCommand = function (msg) {
                    var _this = this;
                    var action;
                    switch (msg.Action) {
                        case Execution.DialogCommands.Prepare:
                            action = new Execution.Dialogs.Prepare();
                            break;
                        case Execution.DialogCommands.GetState:
                            action = new Execution.Dialogs.GetState();
                            break;
                    }
                    if (action == undefined)
                        return;
                    try {
                        action.handleAsync(msg, function (r) {
                            msg.response = r;
                            _this.onActionExecuted.triggerWrap("ActionExecuted", msg);
                        });
                    }
                    catch (err) {
                        msg.response = this.getErrorActionResult(err);
                        this.onActionExecuted.triggerWrap("ActionExecuted", msg);
                    }
                };
                ExecutionHandler.prototype.getErrorActionResult = function (error) {
                    var opError = {
                        Code: MobileTesting.Communication.TsAutomationProtocol.ResultCodes.Error,
                        Description: error.toString()
                    };
                    var result = new Execution.ActionResult();
                    result.Error = opError;
                    result.Params = { "scriptResult": true };
                    return result;
                };
                ExecutionHandler.prototype.loadActions = function () {
                    var actionFuncs = Object.getOwnPropertyNames(Execution.Actions);
                    for (var i = 0; i < actionFuncs.length; i++) {
                        var key = actionFuncs[i];
                        var aFunc = Execution.Actions[key];
                        if (!Execution.ActionBase.prototype.isPrototypeOf(aFunc.prototype))
                            continue;
                        var action = (new aFunc());
                        if (action.Action != undefined || action.Action != "") {
                            this.actions.add(action.Action, action);
                        }
                    }
                };
                return ExecutionHandler;
            }());
            Execution.ExecutionHandler = ExecutionHandler;
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var P;
(function (P) {
    function defer() {
        return new DeferredI();
    }
    P.defer = defer;
    function resolve(v) {
        return defer().resolve(v).promise();
    }
    P.resolve = resolve;
    function reject(err) {
        return defer().reject(err).promise();
    }
    P.reject = reject;
    function unfold(unspool, seed) {
        var d = defer();
        var elements = new Array();
        unfoldCore(elements, d, unspool, seed);
        return d.promise();
    }
    P.unfold = unfold;
    function unfoldCore(elements, deferred, unspool, seed) {
        var result = unspool(seed);
        if (!result) {
            deferred.resolve(elements);
            return;
        }
        while (result.next && result.promise.status == P.Status.Resolved) {
            elements.push(result.promise.result);
            result = unspool(result.next);
            if (!result) {
                deferred.resolve(elements);
                return;
            }
        }
        result.promise
            .done(function (v) {
            elements.push(v);
            if (!result.next)
                deferred.resolve(elements);
            else
                unfoldCore(elements, deferred, unspool, result.next);
        })
            .fail(function (e) {
            deferred.reject(e);
        });
    }
    (function (Status) {
        Status[Status["Unfulfilled"] = 0] = "Unfulfilled";
        Status[Status["Rejected"] = 1] = "Rejected";
        Status[Status["Resolved"] = 2] = "Resolved";
    })(P.Status || (P.Status = {}));
    var Status = P.Status;
    function when() {
        var promises = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            promises[_i - 0] = arguments[_i];
        }
        var allDone = defer();
        if (!promises.length) {
            allDone.resolve([]);
            return allDone.promise();
        }
        var resolved = 0;
        var results = [];
        promises.forEach(function (p, i) {
            p
                .done(function (v) {
                results[i] = v;
                ++resolved;
                if (resolved === promises.length && allDone.status !== Status.Rejected)
                    allDone.resolve(results);
            })
                .fail(function (e) {
                if (allDone.status !== Status.Rejected)
                    allDone.reject(new Error("when: one or more promises were rejected"));
            });
        });
        return allDone.promise();
    }
    P.when = when;
    var PromiseI = (function () {
        function PromiseI(deferred) {
            this.deferred = deferred;
        }
        Object.defineProperty(PromiseI.prototype, "status", {
            get: function () { return this.deferred.status; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PromiseI.prototype, "result", {
            get: function () { return this.deferred.result; },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(PromiseI.prototype, "error", {
            get: function () { return this.deferred.error; },
            enumerable: true,
            configurable: true
        });
        PromiseI.prototype.done = function (f) {
            this.deferred.done(f);
            return this;
        };
        PromiseI.prototype.fail = function (f) {
            this.deferred.fail(f);
            return this;
        };
        PromiseI.prototype.always = function (f) {
            this.deferred.always(f);
            return this;
        };
        PromiseI.prototype.then = function (f) {
            return this.deferred.then(f);
        };
        return PromiseI;
    }());
    var DeferredI = (function () {
        function DeferredI() {
            this._resolved = function (_) { };
            this._rejected = function (_) { };
            this._status = Status.Unfulfilled;
            this._error = { message: "" };
            this._promise = new PromiseI(this);
        }
        DeferredI.prototype.promise = function () {
            return this._promise;
        };
        Object.defineProperty(DeferredI.prototype, "status", {
            get: function () {
                return this._status;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DeferredI.prototype, "result", {
            get: function () {
                if (this._status != Status.Resolved)
                    throw new Error("Promise: result not available");
                return this._result;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DeferredI.prototype, "error", {
            get: function () {
                if (this._status != Status.Rejected)
                    throw new Error("Promise: rejection reason not available");
                return this._error;
            },
            enumerable: true,
            configurable: true
        });
        DeferredI.prototype.then = function (f) {
            var d = defer();
            this
                .done(function (v) {
                var promiseOrValue = f(v);
                if (promiseOrValue instanceof PromiseI) {
                    var p = promiseOrValue;
                    p.done(function (v2) { return d.resolve(v2); })
                        .fail(function (err) { return d.reject(err); });
                    return p;
                }
                d.resolve(promiseOrValue);
            })
                .fail(function (err) { return d.reject(err); });
            return d.promise();
        };
        DeferredI.prototype.done = function (f) {
            if (this.status === Status.Resolved) {
                f(this._result);
                return this;
            }
            if (this.status !== Status.Unfulfilled)
                return this;
            var prev = this._resolved;
            this._resolved = function (v) { prev(v); f(v); };
            return this;
        };
        DeferredI.prototype.fail = function (f) {
            if (this.status === Status.Rejected) {
                f(this._error);
                return this;
            }
            if (this.status !== Status.Unfulfilled)
                return this;
            var prev = this._rejected;
            this._rejected = function (e) { prev(e); f(e); };
            return this;
        };
        DeferredI.prototype.always = function (f) {
            this
                .done(function (v) { return f(v); })
                .fail(function (err) { return f(null, err); });
            return this;
        };
        DeferredI.prototype.resolve = function (result) {
            if (this._status !== Status.Unfulfilled)
                throw new Error("tried to resolve a fulfilled promise");
            this._result = result;
            this._status = Status.Resolved;
            this._resolved(result);
            this.detach();
            return this;
        };
        DeferredI.prototype.reject = function (err) {
            if (this._status !== Status.Unfulfilled)
                throw new Error("tried to reject a fulfilled promise");
            this._error = err;
            this._status = Status.Rejected;
            this._rejected(err);
            this.detach();
            return this;
        };
        DeferredI.prototype.detach = function () {
            this._resolved = function (_) { };
            this._rejected = function (_) { };
        };
        return DeferredI;
    }());
    function generator(g) {
        return function () { return iterator(g()); };
    }
    P.generator = generator;
    ;
    function iterator(f) {
        return new IteratorI(f);
    }
    P.iterator = iterator;
    var IteratorI = (function () {
        function IteratorI(f) {
            this.f = f;
            this.current = undefined;
        }
        IteratorI.prototype.advance = function () {
            var _this = this;
            var res = this.f();
            return res.then(function (value) {
                if (isUndefined(value))
                    return false;
                _this.current = value;
                return true;
            });
        };
        return IteratorI;
    }());
    function each(gen, f) {
        var d = defer();
        eachCore(d, gen(), f);
        return d.promise();
    }
    P.each = each;
    function eachCore(fin, it, f) {
        it.advance()
            .done(function (hasValue) {
            if (!hasValue) {
                fin.resolve({});
                return;
            }
            f(it.current);
            eachCore(fin, it, f);
        })
            .fail(function (err) { return fin.reject(err); });
    }
    function isUndefined(v) {
        return typeof v === 'undefined';
    }
    P.isUndefined = isUndefined;
})(P || (P = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Find;
        (function (Find) {
            var Finder = (function () {
                function Finder() {
                }
                Finder.find = function (query) {
                    var element = undefined;
                    var root = document;
                    for (var i in query) {
                        var q = query[i];
                        element = Finder.findSingleElement(q, root, document);
                        root = element;
                    }
                    return element;
                };
                Finder.findSingleElement = function (query, root, doc) {
                    if (!query || !root || !doc)
                        return undefined;
                    var targetElement = undefined;
                    var index = query.index ? query.index : 0;
                    var matchingElements = undefined;
                    if (query.xpath != undefined) {
                        if (!doc.evaluate)
                            throw new Error("This browser does not support xPath queries.");
                        var elements = doc.evaluate(query.xpath, root, null, 0, null);
                        if (elements == undefined)
                            return undefined;
                        targetElement = elements.iterateNext();
                    }
                    else if (query.querySelector) {
                        if (!doc.querySelector)
                            throw new Error('This browser does not support querySelector queries.');
                        targetElement = root.querySelector(query.querySelector);
                    }
                    else if (query.id !== undefined && query.id !== "") {
                        targetElement = doc.getElementById(query.id);
                    }
                    else if (query.name !== undefined) {
                        matchingElements = Array.prototype.slice.call(doc.getElementsByName(query.name));
                        if (matchingElements != undefined)
                            targetElement = matchingElements[index];
                    }
                    else {
                        var tagElements = Array.prototype.slice.call(root.getElementsByTagName(query.tagName));
                        var classElements = Array.prototype.slice.call(root.getElementsByClassName(query.className));
                        if (query.tagName && query.className) {
                            matchingElements = Finder.intersectArray(tagElements, classElements);
                        }
                        else if (classElements.length == 0 && query.tagName) {
                            matchingElements = tagElements;
                        }
                        else if (tagElements.length == 0 && query.className) {
                            matchingElements = classElements;
                        }
                        if (matchingElements != undefined)
                            targetElement = matchingElements[index];
                    }
                    return targetElement;
                };
                Finder.intersectArray = function (a, b) {
                    var results = new Array();
                    for (var i in a) {
                        if (b.indexOf(a[i]) !== -1) {
                            results.push(a[i]);
                        }
                    }
                    return results;
                };
                return Finder;
            }());
            Find.Finder = Finder;
        })(Find = MobileTesting.Find || (MobileTesting.Find = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Find;
        (function (Find) {
            var FrameInfo = (function () {
                function FrameInfo() {
                    this.frameId = "";
                    this.frameIndex = -1;
                    this.frameName = "";
                    this.frameSrc = "";
                }
                FrameInfo.getFromElement = function (target) {
                    var fInfo = new FrameInfo();
                    if (target.ownerDocument.defaultView != undefined && target.ownerDocument.defaultView.frameElement != null) {
                        fInfo.frameSrc = target.ownerDocument.URL;
                        fInfo.frameId = target.ownerDocument.defaultView.frameElement.id;
                        fInfo.frameName = target.ownerDocument.defaultView.frameElement["name"];
                        fInfo.frameIndex = FrameInfo.getFrameIndex(target.ownerDocument.defaultView);
                    }
                    return fInfo;
                };
                FrameInfo.getFrameIndex = function (fWnd) {
                    var frames = FrameInfo.enumFrames(window.top);
                    var index = frames.indexOf(fWnd);
                    return index;
                };
                FrameInfo.enumFrames = function (wnd) {
                    var retValue = new Array();
                    if (wnd != undefined && wnd.frames != undefined && wnd.frames.length > 0) {
                        for (var i = 0; i < wnd.frames.length; i++) {
                            var cFrames = FrameInfo.enumFrames(wnd.frames[i]);
                            for (var j = 0; j < cFrames.length; j++) {
                                retValue.push(cFrames[j]);
                            }
                        }
                    }
                    return retValue;
                };
                return FrameInfo;
            }());
            Find.FrameInfo = FrameInfo;
        })(Find = MobileTesting.Find || (MobileTesting.Find = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Find;
        (function (Find) {
            var QueryBuilder = (function () {
                function QueryBuilder() {
                }
                QueryBuilder.buildQuery = function (target) {
                    var wq = new Find.WebQuery();
                    var attribute = "";
                    var elements;
                    wq.tagName = target.tagName;
                    if (target.id != undefined) {
                        wq.id = target.id;
                        return wq;
                    }
                    if (target["name"] != undefined) {
                        attribute = "name";
                        elements = document.getElementsByName(target["name"]);
                    }
                    if (attribute != undefined && target.className && (typeof target.className === "string")) {
                        elements = document.getElementsByClassName(target.className);
                    }
                    if (attribute != undefined && target.tagName) {
                        elements = document.getElementsByTagName(target.tagName);
                    }
                    var length = elements != undefined ? elements.length : 0;
                    for (var i = 0; i < length; i++) {
                        if (target != elements[i])
                            continue;
                        if (attribute != undefined)
                            wq[attribute] = attribute;
                        wq.index = i;
                    }
                    return wq;
                };
                QueryBuilder.buildQueries = function (targets) {
                    var queries = new Array();
                    for (var i = 0; i < targets.length; i++) {
                        queries.push(QueryBuilder.buildQuery(targets[i]));
                    }
                    return queries;
                };
                QueryBuilder.generateFriendlyName = function (target) {
                    var sb = "";
                    if (target.id != undefined) {
                        sb += target.id;
                    }
                    else if (target["name"] != undefined) {
                        sb += target["name"];
                    }
                    else if (target["alt"] != undefined) {
                        sb += QueryBuilder.smartTrim(target["alt"], QueryBuilder.MAX_TEXTCONTENT_FIND);
                    }
                    else if (target["uniqueName"] != undefined) {
                        sb += target["uniqueName"];
                    }
                    else if (target["title"] != undefined) {
                        sb += QueryBuilder.smartTrim(target["title"], QueryBuilder.MAX_TEXTCONTENT_FIND);
                    }
                    else if (target.textContent != undefined && target.textContent != "") {
                        var content = MobileTesting.Utils.ElementOperations.getTextContent(target);
                        if (content.length > this.MAX_TEXTCONTENT_FIND) {
                            content = this.smartTrim(content, this.MAX_TEXTCONTENT_FIND);
                        }
                        sb += content;
                    }
                    else if (target["src"] != undefined && target["src"] == "") {
                        sb += this.tryGetFileNameFromPath(target["src"]);
                    }
                    else if (target["href"] != undefined && target["href"] == "") {
                        sb += this.tryGetFileNameFromPath(target["href"]);
                    }
                    sb += " ";
                    if (MobileTesting.Utils.ElementOperations.isKnownElementType(target)) {
                        var tagNameLower = target.tagName.toLowerCase();
                        switch (tagNameLower) {
                            case "a":
                                sb += "Link";
                                break;
                            case "input":
                                sb += MobileTesting.Utils.ElementOperations.getInputType(target);
                                break;
                            default:
                                sb += MobileTesting.Utils.ElementOperations.getTypeName(target);
                                break;
                        }
                    }
                    else {
                        sb += target.tagName;
                        sb += "Tag";
                    }
                    var aspRegEx = new RegExp("ctl[0-9]+");
                    aspRegEx.ignoreCase = true;
                    while (aspRegEx.test(sb)) {
                        var rtext = aspRegEx.exec(sb)[0];
                        sb = sb.replace(rtext, "");
                    }
                    return this.sanitizeString(sb);
                };
                QueryBuilder.smartTrim = function (value, maxLength) {
                    if (value.length <= maxLength)
                        return value;
                    var splitLocation = 0;
                    var lastValidLocation = 0;
                    while (splitLocation != -1 && splitLocation < maxLength - 1) {
                        lastValidLocation = splitLocation;
                        if (splitLocation == 0) {
                            splitLocation = QueryBuilder.indexOfSpecial(value, 1);
                        }
                        else {
                            splitLocation = QueryBuilder.indexOfSpecial(value, splitLocation + 1);
                        }
                    }
                    if (lastValidLocation > 0 && lastValidLocation < maxLength) {
                        return value.substring(0, lastValidLocation);
                    }
                    else {
                        return value.substr(0, maxLength);
                    }
                };
                QueryBuilder.indexOfSpecial = function (value, startIndex) {
                    for (var i = startIndex; i < value.length; i++) {
                        if (value[i] == " " || value[i] == "_" || value[i] == "." || value[i] == "," ||
                            value[i] == "?" || value[i] == "!" || value[i] == ";" || value[i] == "-" || value[i] == "|") {
                            return i;
                        }
                    }
                    return -1;
                };
                QueryBuilder.tryGetFileNameFromPath = function (path) {
                    try {
                        var fileNameIndex = path.lastIndexOf("/") + 1;
                        var filename = path.substr(fileNameIndex);
                        return filename;
                    }
                    catch (err) {
                        return "";
                    }
                };
                QueryBuilder.sanitizeString = function (value) {
                    var newValue = value.trim();
                    var sb = "";
                    var nextCharShouldBeCaps = true;
                    var firstSpace = -1;
                    var count = newValue.length;
                    for (var i = 0; i < count; i++) {
                        var charLetter = newValue[i];
                        if (charLetter === ' ') {
                            firstSpace = i;
                        }
                        if (!this.containsDigit(charLetter) && !this.containsLetter(charLetter) && !this.containsNonAsciiLetter(charLetter)) {
                            nextCharShouldBeCaps = true;
                            continue;
                        }
                        else {
                            if (nextCharShouldBeCaps) {
                                sb += charLetter.toUpperCase();
                                nextCharShouldBeCaps = false;
                            }
                            else {
                                sb += charLetter;
                            }
                        }
                    }
                    if (sb.length > 0 && parseInt(sb[0]) != NaN) {
                        sb = "x" + sb;
                    }
                    return sb;
                };
                QueryBuilder.containsLetter = function (value) {
                    return /^.*[A-Z].*/i.test(value);
                };
                QueryBuilder.containsDigit = function (value) {
                    return /^.*[0-9].*/i.test(value);
                };
                QueryBuilder.containsNonAsciiLetter = function (value) {
                    return /^.*[^\x00-\x80].*/i.test(value);
                };
                QueryBuilder.MAX_TEXTCONTENT_FIND = 15;
                return QueryBuilder;
            }());
            Find.QueryBuilder = QueryBuilder;
        })(Find = MobileTesting.Find || (MobileTesting.Find = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Find;
        (function (Find) {
            var WebQuery = (function () {
                function WebQuery() {
                }
                return WebQuery;
            }());
            Find.WebQuery = WebQuery;
        })(Find = MobileTesting.Find || (MobileTesting.Find = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Recording;
        (function (Recording) {
            var MtsRecordingService = (function () {
                function MtsRecordingService() {
                    this.actionRecorded = new MobileTesting.Common.EventEmitter();
                }
                Object.defineProperty(MtsRecordingService.prototype, "ActionRecorded", {
                    get: function () {
                        return this.actionRecorded;
                    },
                    enumerable: true,
                    configurable: true
                });
                MtsRecordingService.prototype.start = function () {
                    var _this = this;
                    Recording.TranslatorService.Instnace.TranslatingAction.on(function (ta) { return _this.onTranslatingAction(ta.data); });
                    this.hookDocumentHandlers();
                };
                MtsRecordingService.prototype.stop = function () {
                    var _this = this;
                    Recording.TranslatorService.Instnace.TranslatingAction.off(function (ta) { return _this.onTranslatingAction(ta.data); });
                    this.unhookDocumentHandlers();
                    this.actionRecorded.clear();
                };
                MtsRecordingService.prototype.unhookDocumentHandlers = function () {
                    document.removeEventListener("touchstart", this.touchesHandler, true);
                    document.removeEventListener("touchend", this.touchesHandler, true);
                    document.removeEventListener("mousedown", this.pointerHandler, true);
                    document.removeEventListener("mouseup", this.pointerHandler, true);
                    document.removeEventListener("click", this.pointerHandler, true);
                    document.removeEventListener("keydown", this.keyHandler, true);
                    document.removeEventListener("keyup", this.keyHandler, true);
                    document.removeEventListener("keypress", this.keyHandler, true);
                    document.removeEventListener("change", this.changeEventHandler, true);
                };
                MtsRecordingService.prototype.hookDocumentHandlers = function () {
                    document.addEventListener("touchstart", this.touchesHandler, true);
                    document.addEventListener("touchend", this.touchesHandler, true);
                    document.addEventListener("mousedown", this.pointerHandler, true);
                    document.addEventListener("mouseup", this.pointerHandler, true);
                    document.addEventListener("click", this.pointerHandler, true);
                    document.addEventListener("keydown", this.keyHandler, true);
                    document.addEventListener("keyup", this.keyHandler, true);
                    document.addEventListener("keypress", this.keyHandler, true);
                    document.addEventListener("change", this.changeEventHandler, true);
                };
                MtsRecordingService.prototype.touchesHandler = function (e) {
                    Recording.TranslatorService.Instnace.translateTouchEvent(e);
                };
                MtsRecordingService.prototype.pointerHandler = function (e) {
                    Recording.TranslatorService.Instnace.translatePointerEvent(e);
                };
                MtsRecordingService.prototype.keyHandler = function (e) {
                    Recording.TranslatorService.Instnace.translateKeyEvent(e);
                };
                MtsRecordingService.prototype.changeEventHandler = function (e) {
                    Recording.TranslatorService.Instnace.translateChangeEvent(e);
                };
                MtsRecordingService.prototype.onTranslatingAction = function (ta) {
                    var page = {
                        url: document.URL,
                        title: document.title
                    };
                    var action = {
                        descriptor: ta.descriptor,
                        frameInfo: ta.frameInfo,
                        friendlyName: ta.friendlyName,
                        page: page
                    };
                    this.actionRecorded.triggerWrap("recordAction", action);
                };
                return MtsRecordingService;
            }());
            Recording.MtsRecordingService = MtsRecordingService;
        })(Recording = MobileTesting.Recording || (MobileTesting.Recording = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Recording;
        (function (Recording) {
            var RecordMessage = (function () {
                function RecordMessage(friendlyName, desc, frameInfo, page) {
                    this.tjsr_message = "sendRecorderCommand";
                    this.command = new RecordCommand(friendlyName, desc, frameInfo, page);
                }
                return RecordMessage;
            }());
            Recording.RecordMessage = RecordMessage;
            var Command = (function () {
                function Command() {
                }
                return Command;
            }());
            Recording.Command = Command;
            var RecordCommand = (function (_super) {
                __extends(RecordCommand, _super);
                function RecordCommand(friendlyName, desc, frameInfo, page) {
                    _super.call(this);
                    this.command = "recordAction";
                    this.data = {
                        friendlyName: friendlyName,
                        descriptor: desc,
                        frameInfo: frameInfo,
                        page: page
                    };
                }
                Object.defineProperty(RecordCommand.prototype, "Descriptor", {
                    get: function () {
                        return this.data["descriptor"];
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(RecordCommand.prototype, "Page", {
                    get: function () {
                        return this.data["page"];
                    },
                    enumerable: true,
                    configurable: true
                });
                return RecordCommand;
            }(Command));
            Recording.RecordCommand = RecordCommand;
            var Descriptor = (function () {
                function Descriptor() {
                }
                return Descriptor;
            }());
            Recording.Descriptor = Descriptor;
            var Page = (function () {
                function Page() {
                }
                return Page;
            }());
            Recording.Page = Page;
        })(Recording = MobileTesting.Recording || (MobileTesting.Recording = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Recording;
        (function (Recording) {
            var RecordingHandler = (function () {
                function RecordingHandler() {
                    this.isRecording = false;
                }
                Object.defineProperty(RecordingHandler.prototype, "IsRecording", {
                    get: function () {
                        return this.isRecording;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(RecordingHandler.prototype, "ActionRecorded", {
                    get: function () {
                        return this.onActionRecorded;
                    },
                    enumerable: true,
                    configurable: true
                });
                RecordingHandler.prototype.start = function () {
                    if (this.isRecording)
                        return;
                    console.log("RecordingHandler :: START");
                    this.onActionRecorded = new MobileTesting.Common.EventEmitter();
                    this.recordingService = new Recording.MtsRecordingService();
                    this.recordingService.start();
                    this.recordingService.ActionRecorded.on(this.onActionRecordedHandler.bind(this));
                    this.isRecording = true;
                };
                RecordingHandler.prototype.pause = function () {
                    this.isRecording = false;
                };
                RecordingHandler.prototype.stop = function () {
                    console.log("RecordingHandler :: STOP");
                    this.isRecording = false;
                    if (this.recordingService != null) {
                        this.recordingService.stop();
                        delete this.recordingService;
                        delete this.onActionRecorded;
                    }
                };
                RecordingHandler.prototype.onActionRecordedHandler = function (args) {
                    var msg = new MobileTesting.Communication.Message(MobileTesting.Communication.MessageTypes.NotSet);
                    msg.response = {
                        "cmd": "notify.descriptorRecorded",
                        "params": {
                            "descriptor": args.data.descriptor,
                            "navHash": this.getNavHash()
                        }
                    };
                    this.onActionRecorded.triggerWrap("DescriptorRecorded", msg);
                };
                RecordingHandler.prototype.getNavHash = function () {
                    if (window.location.protocol.substring(0, 4).toLowerCase() == "data") {
                        return "";
                    }
                    return window.location.protocol;
                };
                return RecordingHandler;
            }());
            Recording.RecordingHandler = RecordingHandler;
        })(Recording = MobileTesting.Recording || (MobileTesting.Recording = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Recording;
        (function (Recording) {
            var TranslatorService = (function () {
                function TranslatorService() {
                    this.suppressPointerTranslation = false;
                    this.pointTranslators = new Array();
                    this.keyTranslators = new Array();
                    this.translatingAction = new MobileTesting.Common.EventEmitter();
                }
                Object.defineProperty(TranslatorService, "Instnace", {
                    get: function () {
                        if (TranslatorService.instance == undefined) {
                            TranslatorService.instance = new TranslatorService();
                            TranslatorService.instance.loadTranslators();
                        }
                        return TranslatorService.instance;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TranslatorService.prototype, "TranslatingAction", {
                    get: function () {
                        return this.translatingAction;
                    },
                    enumerable: true,
                    configurable: true
                });
                TranslatorService.prototype.loadTranslators = function () {
                    var translatorFuncs = Object.getOwnPropertyNames(Recording.Translators);
                    for (var i = 0; i < translatorFuncs.length; i++) {
                        var key = translatorFuncs[i];
                        var tFunc = Recording.Translators[key];
                        if (Recording.Translators.PointTranslatorBase.prototype.isPrototypeOf(tFunc.prototype)) {
                            this.pushTranslator(new tFunc(), this.pointTranslators);
                        }
                        else if (Recording.Translators.KeyInputTranslatorBase.prototype.isPrototypeOf(tFunc.prototype)) {
                            this.pushTranslator(new tFunc(), this.keyTranslators);
                        }
                    }
                };
                TranslatorService.prototype.translateTouchEvent = function (event) {
                    if (event.type == "touchstart") {
                        this.currentTarget = event.target;
                        this.findPointMatch(event.type, new Array(event.target));
                    }
                    else if (event.type == "touchend") {
                        this.findPointMatch(event.type, new Array(event.target, this.currentTarget));
                        this.currentTarget = undefined;
                        this.suppressPointerTranslation = true;
                    }
                };
                TranslatorService.prototype.translatePointerEvent = function (event) {
                    if (event.type == "click" && this.suppressPointerTranslation) {
                        this.suppressPointerTranslation = false;
                        return;
                    }
                    this.findPointMatch(event.type, new Array(event.target, this.currentTarget));
                    this.currentTarget = event.target;
                };
                TranslatorService.prototype.translateKeyEvent = function (event) {
                    this.findKeyMatch(event, new Array(event.target, this.currentTarget));
                    this.currentTarget = event.target;
                };
                TranslatorService.prototype.translateChangeEvent = function (event) {
                    this.findPointMatch(event.type, new Array(event.target, this.currentTarget));
                    this.currentTarget = event.target;
                };
                TranslatorService.prototype.findPointMatch = function (action, targets) {
                    for (var i = 0; i < this.pointTranslators.length; i++) {
                        var t = this.pointTranslators[i];
                        if (t.match(action, targets)) {
                            console.log("Matched with: " + t.Action);
                            this.triggerPointTranslatingAction(t, targets);
                            return true;
                        }
                    }
                    return false;
                };
                TranslatorService.prototype.findKeyMatch = function (event, targets) {
                    for (var i = 0; i < this.keyTranslators.length; i++) {
                        var t = this.keyTranslators[i];
                        if (t.match(event.type, targets)) {
                            console.log("Matched with: " + t.Action);
                            this.triggeKeyTranslatingAction(t, targets, event);
                            return true;
                        }
                    }
                    return false;
                };
                TranslatorService.prototype.triggerPointTranslatingAction = function (translator, targets) {
                    var ta = {
                        descriptor: translator.buildDescriptor(targets),
                        action: translator.Action,
                        friendlyName: translator.getFriendlyName(targets),
                        frameInfo: translator.getFrameInfo(targets)
                    };
                    this.translatingAction.triggerWrap("TranslatingAction", ta);
                };
                TranslatorService.prototype.triggeKeyTranslatingAction = function (translator, targets, event) {
                    var ta = {
                        descriptor: translator.buildDescriptor(targets, event),
                        action: translator.Action,
                        friendlyName: translator.getFriendlyName(targets),
                        frameInfo: translator.getFrameInfo(targets)
                    };
                    this.translatingAction.triggerWrap("TranslatingAction", ta);
                };
                TranslatorService.prototype.pushTranslator = function (translator, collection) {
                    var count = collection.length;
                    if (count == 0)
                        collection.push(translator);
                    for (var i = 0; i < count; i++) {
                        var t = collection[i];
                        var t1 = collection[i + 1];
                        if (t.Order > translator.Order) {
                            collection.splice(0, 0, translator);
                        }
                        else if (t.Order < translator.Order && t1 == undefined) {
                            collection.push(translator);
                            return;
                        }
                        else if (t.Order < translator.Order && t1.Order > translator.Order) {
                            collection.splice(i + 1, 0, translator);
                            return;
                        }
                    }
                };
                return TranslatorService;
            }());
            Recording.TranslatorService = TranslatorService;
        })(Recording = MobileTesting.Recording || (MobileTesting.Recording = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Utils;
        (function (Utils) {
            var Browser = (function () {
                function Browser() {
                }
                Browser.getBrowserInfo = function () {
                    var N = navigator.appName, ua = navigator.userAgent, tem;
                    var M = ua.match(/(opera|chrome|safari|firefox|msie)\/?\s*(\.?\d+(\.\d+)*)/i);
                    if (M && (tem = ua.match(/version\/([\.\d]+)/i)) !== null)
                        M[2] = tem[1];
                    M = M ? [M[1], M[2]] : [N, navigator.appVersion, "-?"];
                    var OSName = "Unknown OS";
                    if (navigator.appVersion.indexOf("Win") != -1)
                        OSName = "Windows";
                    if (navigator.appVersion.indexOf("Mac") != -1)
                        OSName = "MacOS";
                    if (navigator.appVersion.indexOf("X11") != -1)
                        OSName = "UNIX";
                    if (navigator.appVersion.indexOf("Linux") != -1)
                        OSName = "Linux";
                    if (navigator.appVersion.indexOf("iPhone OS") != -1)
                        OSName = "iOS";
                    if (navigator.appVersion.indexOf("Android") != -1)
                        OSName = "Android";
                    if (navigator.appVersion.indexOf("Windows Phone") != -1)
                        OSName = "Windows Phone";
                    var info = { name: M[0], version: M[1], os: OSName };
                    return info;
                };
                Browser.getClientInfo = function () {
                    var browserInfo = this.getBrowserInfo();
                    var platformInfo = {
                        platformKey: "web",
                        name: browserInfo.name,
                        platform: navigator.platform,
                        system: browserInfo.os,
                        systemVersion: "",
                        browser: browserInfo
                    };
                    var ci = {
                        version: MobileTesting.Communication.TsAutomationProtocol.Version.toString(),
                        platformInfo: platformInfo,
                        capabilities: null,
                        identity: null
                    };
                    return ci;
                };
                return Browser;
            }());
            Utils.Browser = Browser;
        })(Utils = MobileTesting.Utils || (MobileTesting.Utils = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Utils;
        (function (Utils) {
            var ElementOperations = (function () {
                function ElementOperations() {
                }
                ElementOperations.getTextContent = function (target) {
                    var retStr = "";
                    var appendVal = "";
                    if (target.nodeType === 3)
                        retStr = target.textContent;
                    var count = target.childNodes ? target.childNodes.length : 0;
                    for (var i = 0; i < count; i++) {
                        var child = target.childNodes[i];
                        if (child.nodeType === 3)
                            appendVal += child.textContent.trim();
                    }
                    if (appendVal.length > 0)
                        retStr = appendVal;
                    return retStr;
                };
                ElementOperations.getInputType = function (target) {
                    var type = target.type.toLowerCase();
                    switch (type) {
                        case "button":
                            return "Button";
                        case "checkbox":
                            return "CheckBox";
                        case "file":
                            return "File";
                        case "hidden":
                            return "Hidden";
                        case "image":
                            return "Image";
                        case "password":
                            return "Password";
                        case "radio":
                            return "Radio";
                        case "reset":
                            return "Reset";
                        case "submit":
                            return "Submit";
                        case "text":
                            return "Text";
                        case "email":
                            return "Email";
                        case "url":
                            return "Url";
                        case "number":
                            return "Number";
                        case "range":
                            return "Range";
                        case "search":
                            return "Search";
                        case "tel":
                            return "Telephone";
                    }
                    return "NotSet";
                };
                ElementOperations.getTypeName = function (target) {
                    try {
                        var tagName = target.tagName.toLowerCase();
                        switch (tagName) {
                            case "textarea":
                                return "TextArea";
                            case "script":
                                return "Script";
                            case "div":
                                return "Div";
                            case "table":
                                return "Table";
                            case "style":
                                return "CascadingStyleSheet";
                            case "a":
                                return "Anchor";
                            case "img":
                                return "Image";
                            case "frameset":
                                return "FrameSet";
                            case "frame":
                                return "Frame";
                            case "iframe":
                                return "IFrame";
                            case "map":
                                return "Map";
                            case "select":
                                return "Select";
                            case "input":
                                return "Input";
                            case "link":
                                return "Link";
                            case "th":
                                return "TableHeader";
                            case "td":
                                return "TableCell";
                            case "col":
                                return "TableColumn";
                            case "tr":
                                return "TableRow";
                            case "span":
                                return "Span";
                            case "li":
                                return "ListItem";
                            case "ol":
                                return "OrderedList";
                            case "ul":
                                return "UnorderedList";
                            case "testregion":
                                return "TestRegion";
                            case "video":
                                return "Video";
                            case "audio":
                                return "Audio";
                            case "source":
                                return "Source";
                            default:
                                return "Other";
                        }
                    }
                    catch (err) {
                        return "Other";
                    }
                };
                ElementOperations.isKnownElementType = function (target) {
                    if (!target.tagName)
                        return false;
                    var tagName = target.tagName.toLowerCase();
                    if (tagName == "textarea" ||
                        tagName == "script" ||
                        tagName == "div" ||
                        tagName == "table" ||
                        tagName == "style" ||
                        tagName == "a" ||
                        tagName == "img" ||
                        tagName == "frameset" ||
                        tagName == "frame" ||
                        tagName == "iframe" ||
                        tagName == "map" ||
                        tagName == "select" ||
                        tagName == "input" ||
                        tagName == "link" ||
                        tagName == "th" ||
                        tagName == "td" ||
                        tagName == "col" ||
                        tagName == "tr" ||
                        tagName == "span" ||
                        tagName == "li" ||
                        tagName == "ol" ||
                        tagName == "ul" ||
                        tagName == "testregion" ||
                        tagName == "video" ||
                        tagName == "audio" ||
                        tagName == "source") {
                        return true;
                    }
                    return false;
                };
                return ElementOperations;
            }());
            Utils.ElementOperations = ElementOperations;
        })(Utils = MobileTesting.Utils || (MobileTesting.Utils = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Elements;
        (function (Elements) {
            var Constants = (function () {
                function Constants() {
                }
                Constants.PlatformKey = "hybrid";
                return Constants;
            }());
            Elements.Constants = Constants;
            var NavHashInfo = (function () {
                function NavHashInfo() {
                }
                NavHashInfo.getNavHash = function () {
                    var url = window.location.href;
                    var hash = 5381;
                    if (url.length == 0)
                        return hash;
                    var i = url.length;
                    while (i) {
                        hash = (hash * 33) ^ url.charCodeAt(--i);
                    }
                    return hash >>> 0;
                };
                return NavHashInfo;
            }());
            Elements.NavHashInfo = NavHashInfo;
        })(Elements = MobileTesting.Elements || (MobileTesting.Elements = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var AttributeAction;
                (function (AttributeAction) {
                    AttributeAction[AttributeAction["Get"] = 0] = "Get";
                    AttributeAction[AttributeAction["Set"] = 1] = "Set";
                })(AttributeAction || (AttributeAction = {}));
                var Attribute = (function (_super) {
                    __extends(Attribute, _super);
                    function Attribute() {
                        _super.apply(this, arguments);
                        this.AttAction = "action";
                        this.Name = "name";
                        this.Value = "value";
                    }
                    Object.defineProperty(Attribute.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.Attribute;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Attribute.prototype.handleAsync = function (data, callback) {
                        var target = this.getElement(data);
                        var action = parseInt(data.getActionParam(this.AttAction));
                        var name = data.getActionParam(this.Name);
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        if (action == AttributeAction.Get) {
                            var value = this.getAttributeValue(target, name);
                            result.Params = { "scriptResult": value };
                        }
                        else {
                            var value = data.getActionParam(this.Value);
                            this.setAttributeValue(target, name, value);
                            result.Params = { "scriptResult": "true" };
                        }
                        callback(result);
                    };
                    Attribute.prototype.getAttributeValue = function (target, name) {
                        return target.getAttribute(name);
                    };
                    Attribute.prototype.setAttributeValue = function (target, name, value) {
                        target.setAttribute(name, value);
                    };
                    return Attribute;
                }(Execution.ActionBase));
                Actions.Attribute = Attribute;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                (function (MouseButton) {
                    MouseButton[MouseButton["Left"] = 0] = "Left";
                    MouseButton[MouseButton["Middle"] = 1] = "Middle";
                    MouseButton[MouseButton["Right"] = 2] = "Right";
                })(Actions.MouseButton || (Actions.MouseButton = {}));
                var MouseButton = Actions.MouseButton;
                var PointerActionBase = (function (_super) {
                    __extends(PointerActionBase, _super);
                    function PointerActionBase() {
                        _super.apply(this, arguments);
                    }
                    PointerActionBase.prototype.dispatchPointerEvent = function (target, eventName, button, point, delay) {
                        setTimeout(function () {
                            var event = document.createEvent("MouseEvents");
                            event.initMouseEvent(eventName, true, true, window, 1, 0, 0, point.x, point.y, false, false, false, false, button, null);
                            target.dispatchEvent(event);
                        }, delay);
                    };
                    return PointerActionBase;
                }(Execution.ActionBase));
                Actions.PointerActionBase = PointerActionBase;
                var TouchActionBase = (function (_super) {
                    __extends(TouchActionBase, _super);
                    function TouchActionBase() {
                        _super.apply(this, arguments);
                    }
                    TouchActionBase.prototype.dispatchTouchEvent = function (target, eventName, points, delay) {
                        var _this = this;
                        setTimeout(function () {
                            var touches = new TouchList();
                            for (var pIndex = 0; pIndex < points.length; pIndex++) {
                                var p = points[pIndex];
                                var m = _this.mockTouch(target, pIndex, p.x, p.y);
                                touches.push(m);
                            }
                            ;
                            var event = document.createEvent("UIEvent");
                            event.initUIEvent(eventName, true, true, window, 1);
                            event.changedTouches = touches;
                            event.targetTouches = touches;
                            event.touches = touches;
                            event.target = target;
                            target.dispatchEvent(event);
                        }, delay);
                    };
                    TouchActionBase.prototype.mockTouch = function (target, id, clientX, clientY) {
                        var docRect = document.documentElement.getBoundingClientRect();
                        var pageX = clientX - docRect.left;
                        var pageY = clientY - docRect.top;
                        var mock = {
                            clientX: clientX,
                            clientY: clientY,
                            identifier: id,
                            target: target,
                            pageX: pageX,
                            pageY: pageY,
                            screenX: pageX,
                            screenY: pageY
                        };
                        return mock;
                    };
                    return TouchActionBase;
                }(PointerActionBase));
                Actions.TouchActionBase = TouchActionBase;
                var TouchList = (function (_super) {
                    __extends(TouchList, _super);
                    function TouchList() {
                        _super.apply(this, arguments);
                    }
                    TouchList.prototype.item = function (index) {
                        return this[index];
                    };
                    TouchList.prototype.identifiedTouch = function (id) {
                        return this[id];
                    };
                    return TouchList;
                }(Array));
                Actions.TouchList = TouchList;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var CheckedActions;
                (function (CheckedActions) {
                    CheckedActions[CheckedActions["Get"] = 0] = "Get";
                    CheckedActions[CheckedActions["Set"] = 1] = "Set";
                })(CheckedActions || (CheckedActions = {}));
                var Checked = (function (_super) {
                    __extends(Checked, _super);
                    function Checked() {
                        _super.apply(this, arguments);
                        this.CheckedAction = "action";
                        this.Value = "value";
                    }
                    Object.defineProperty(Checked.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.Checked;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Checked.prototype.handleAsync = function (data, callback) {
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        var target = this.getElement(data);
                        var action = parseInt(data.getActionParam(this.CheckedAction));
                        if (action == CheckedActions.Get) {
                            var value = this.getChecked(target);
                            result.Params = { "scriptResult": value };
                        }
                        else {
                            var value = Boolean(data.getActionParam(this.Value));
                            this.setChecked(target, value);
                            result.Params = { "scriptResult": "true" };
                        }
                        callback(result);
                    };
                    Checked.prototype.getChecked = function (target) {
                        return target["checked"];
                    };
                    Checked.prototype.setChecked = function (target, value) {
                        if (target["checked"] != value) {
                            target["checked"] = value;
                        }
                    };
                    return Checked;
                }(Actions.PointerActionBase));
                Actions.Checked = Checked;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var Click = (function (_super) {
                    __extends(Click, _super);
                    function Click() {
                        _super.apply(this, arguments);
                        this.MouseButton = "mouseButton";
                    }
                    Object.defineProperty(Click.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.Click;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Click.prototype.handleAsync = function (data, callback) {
                        var target = this.getElement(data);
                        var mouseButton = parseInt(data.getActionParam(this.MouseButton));
                        if (mouseButton != Actions.MouseButton.Right)
                            this.click(target, mouseButton);
                        else
                            this.rightClick(target);
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": true };
                        callback(result);
                    };
                    Click.prototype.click = function (target, button) {
                        var rect = target.getBoundingClientRect();
                        var point = {
                            x: rect.left + Math.floor(rect.width),
                            y: rect.top + Math.floor(rect.height)
                        };
                        var delay = 50;
                        this.dispatchPointerEvent(target, "mouseover", button, point, delay);
                        this.dispatchPointerEvent(target, "mousedown", button, point, delay);
                        this.dispatchPointerEvent(target, "mouseup", button, point, delay);
                        this.dispatchPointerEvent(target, "click", button, point, delay);
                    };
                    Click.prototype.rightClick = function (target) {
                        var rect = target.getBoundingClientRect();
                        var point = {
                            x: rect.left + Math.floor(rect.width),
                            y: rect.top + Math.floor(rect.height)
                        };
                        var delay = 50;
                        this.dispatchPointerEvent(target, "mousedown", Actions.MouseButton.Right, point, delay);
                        this.dispatchPointerEvent(target, "mouseup", Actions.MouseButton.Right, point, delay);
                        this.dispatchPointerEvent(target, "contextmenu", Actions.MouseButton.Right, point, delay);
                    };
                    return Click;
                }(Actions.PointerActionBase));
                Actions.Click = Click;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var DoubleClick = (function (_super) {
                    __extends(DoubleClick, _super);
                    function DoubleClick() {
                        _super.apply(this, arguments);
                    }
                    Object.defineProperty(DoubleClick.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.DoubleClick;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    DoubleClick.prototype.handleAsync = function (data, callback) {
                        var target = this.getElement(data);
                        this.click(target, Actions.MouseButton.Left);
                        this.click(target, Actions.MouseButton.Left);
                        var point = {
                            x: 0, y: 0
                        };
                        this.dispatchPointerEvent(target, "dblclick", Actions.MouseButton.Left, point, 50);
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": true };
                        callback(result);
                    };
                    return DoubleClick;
                }(Actions.Click));
                Actions.DoubleClick = DoubleClick;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var DragTypes;
                (function (DragTypes) {
                    DragTypes[DragTypes["ToPoint"] = 0] = "ToPoint";
                    DragTypes[DragTypes["ToElement"] = 1] = "ToElement";
                })(DragTypes || (DragTypes = {}));
                var Drag = (function (_super) {
                    __extends(Drag, _super);
                    function Drag() {
                        _super.apply(this, arguments);
                        this.DragType = "dragType";
                        this.OffsetX = "offsetX";
                        this.OffsetY = "offsetY";
                        this.ToQuery = "toElementQuery";
                    }
                    Object.defineProperty(Drag.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.Drag;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Drag.prototype.handleAsync = function (data, callback) {
                        var dragType = parseInt(data.getActionParam(this.DragType));
                        var target = this.getElement(data);
                        if (dragType == DragTypes.ToPoint) {
                            var offsetX = parseInt(data.getActionParam(this.OffsetX));
                            var offsetY = parseInt(data.getActionParam(this.OffsetY));
                            this.toPoint(target, offsetX, offsetY);
                        }
                        else {
                            var toElementQuery = data.getActionParam(this.ToQuery);
                            var toTarget = this.getElementFromQuery(toElementQuery);
                            this.toElement(target, toTarget);
                        }
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": true };
                        callback(result);
                    };
                    Drag.prototype.toPoint = function (target, offsetX, offsetY) {
                        this.dispatchPointerEvent(target, "mousedown", Actions.MouseButton.Left, { x: 0, y: 0 }, 50);
                        this.dispatchPointerEvent(target, "mousemove", Actions.MouseButton.Left, { x: offsetX, y: offsetY }, 50);
                        this.dispatchPointerEvent(target, "mouseup", Actions.MouseButton.Left, { x: 0, y: 0 }, 50);
                    };
                    Drag.prototype.toElement = function (target, toElement) {
                        var offsetX = toElement.offsetLeft - target.offsetLeft;
                        var offsetY = toElement.offsetTop - target.offsetTop;
                        this.toPoint(target, offsetX, offsetY);
                    };
                    return Drag;
                }(Actions.PointerActionBase));
                Actions.Drag = Drag;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var Pan = (function (_super) {
                    __extends(Pan, _super);
                    function Pan() {
                        _super.apply(this, arguments);
                    }
                    Pan.prototype.pan = function (targetElement, startX, startY, endX, endY, steps, stepDelay) {
                        var delay = 0;
                        var x = startX;
                        var y = startY;
                        var xInc = (endX - x) / steps;
                        var yInc = (endY - y) / steps;
                        this.dispatchTouchEvent(targetElement, "touchstart", [{ x: x, y: y }], delay);
                        delay += stepDelay;
                        for (var i = 0; i < steps; i++) {
                            delay += stepDelay;
                            x += xInc;
                            y += yInc;
                            this.dispatchTouchEvent(targetElement, "touchmove", [{ x: x, y: y }], delay);
                        }
                        this.dispatchTouchEvent(targetElement, "touchend", [{ x: endX, y: endY }], delay);
                    };
                    return Pan;
                }(Actions.TouchActionBase));
                Actions.Pan = Pan;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var DragToPoint = (function (_super) {
                    __extends(DragToPoint, _super);
                    function DragToPoint() {
                        _super.apply(this, arguments);
                        this.FromPointX = "fromPointX";
                        this.FromPointY = "fromPointY";
                        this.ToPointX = "toPointX";
                        this.ToPointY = "toPointY";
                        this.Steps = "steps";
                        this.StepDelay = "stepDelay";
                    }
                    Object.defineProperty(DragToPoint.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.DragToPoint;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    DragToPoint.prototype.handleAsync = function (data, callback) {
                        var target = this.getElement(data);
                        var startPoint = {
                            x: parseInt(data.getActionParam(this.FromPointX)),
                            y: parseInt(data.getActionParam(this.FromPointY))
                        };
                        var endPoint = {
                            x: parseInt(data.getActionParam(this.ToPointX)),
                            y: parseInt(data.getActionParam(this.ToPointY))
                        };
                        var steps = parseInt(data.getActionParam(this.Steps));
                        var stepDelay = parseInt(data.getActionParam(this.StepDelay));
                        this.dragToPoint(target, startPoint, endPoint, steps, stepDelay);
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": true };
                        callback(result);
                    };
                    DragToPoint.prototype.dragToPoint = function (target, startPoint, endPoint, steps, stepDelay) {
                        var rect = target.getBoundingClientRect();
                        var startX = startPoint.x + rect.left;
                        var startY = startPoint.y + rect.top;
                        var endX = endPoint.x + rect.left;
                        var endY = endPoint.y + rect.top;
                        this.pan(target, startX, startY, endX, endY, steps, stepDelay);
                    };
                    return DragToPoint;
                }(Actions.Pan));
                Actions.DragToPoint = DragToPoint;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var ExecuteScript = (function (_super) {
                    __extends(ExecuteScript, _super);
                    function ExecuteScript() {
                        _super.apply(this, arguments);
                        this.Script = "script";
                    }
                    Object.defineProperty(ExecuteScript.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.ExecuteScript;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    ExecuteScript.prototype.handleAsync = function (data, callback) {
                        var query = this.getWebQuery(data);
                        if (query != undefined)
                            this.setTarget(this.getElement(data));
                        var script = data.getActionParam(this.Script);
                        var scriptResult = this.executeScript(script);
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": scriptResult };
                        callback(result);
                    };
                    ExecuteScript.prototype.executeScript = function (script) {
                        try {
                            return eval(script);
                        }
                        catch (err) {
                            return err;
                        }
                    };
                    ExecuteScript.prototype.setTarget = function (target) {
                        var wnd = window;
                        wnd.targetElement = target;
                    };
                    return ExecuteScript;
                }(Execution.ActionBase));
                Actions.ExecuteScript = ExecuteScript;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var CountTypes;
                (function (CountTypes) {
                    CountTypes[CountTypes["Row"] = 0] = "Row";
                    CountTypes[CountTypes["Column"] = 1] = "Column";
                })(CountTypes || (CountTypes = {}));
                var GetCount = (function (_super) {
                    __extends(GetCount, _super);
                    function GetCount() {
                        _super.apply(this, arguments);
                        this.Type = "type";
                        this.RowIndex = "rowIndex";
                    }
                    Object.defineProperty(GetCount.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.GetCount;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    GetCount.prototype.handleAsync = function (data, callback) {
                        var target = this.getElement(data);
                        var type = parseInt(data.getActionParam(this.Type));
                        var count = -1;
                        if (type == CountTypes.Row) {
                            count = this.getRowCount(target);
                        }
                        else if (type == CountTypes.Column) {
                            var index = parseInt(data.getActionParam(this.RowIndex));
                            count = this.getColumnCount(target, index);
                        }
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": count };
                        callback(result);
                    };
                    GetCount.prototype.getRowCount = function (target) {
                        return target["rows"]["length"];
                    };
                    GetCount.prototype.getColumnCount = function (target, rowIndex) {
                        return target["rows"][rowIndex].cells.length;
                    };
                    return GetCount;
                }(Execution.ActionBase));
                Actions.GetCount = GetCount;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var GetInError = (function (_super) {
                    __extends(GetInError, _super);
                    function GetInError() {
                        _super.apply(this, arguments);
                    }
                    Object.defineProperty(GetInError.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.GetInError;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    GetInError.prototype.handleAsync = function (data, callback) {
                        var target = this.getElement(data);
                        var isReady = target["readyState"] == 0;
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": isReady };
                        callback(result);
                    };
                    return GetInError;
                }(Execution.ActionBase));
                Actions.GetInError = GetInError;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var Hover = (function (_super) {
                    __extends(Hover, _super);
                    function Hover() {
                        _super.apply(this, arguments);
                    }
                    Object.defineProperty(Hover.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.Hover;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Hover.prototype.handleAsync = function (data, callback) {
                        var target = this.getElement(data);
                        this.hover(target);
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": true };
                        callback(result);
                    };
                    Hover.prototype.hover = function (target) {
                        var rect = target.getBoundingClientRect();
                        var point = {
                            x: rect.left + Math.floor(rect.width),
                            y: rect.top + Math.floor(rect.height)
                        };
                        var delay = 50;
                        this.dispatchPointerEvent(target, "mouseover", Actions.MouseButton.Left, point, delay);
                    };
                    return Hover;
                }(Actions.PointerActionBase));
                Actions.Hover = Hover;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var HtmlActions;
                (function (HtmlActions) {
                    HtmlActions[HtmlActions["Get"] = 0] = "Get";
                    HtmlActions[HtmlActions["Set"] = 1] = "Set";
                })(HtmlActions || (HtmlActions = {}));
                var Html = (function (_super) {
                    __extends(Html, _super);
                    function Html() {
                        _super.apply(this, arguments);
                        this.HtmlAction = "action";
                        this.Html = "html";
                    }
                    Object.defineProperty(Html.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.Html;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Html.prototype.handleAsync = function (data, callback) {
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        var target = this.getElement(data);
                        var action = parseInt(data.getActionParam(this.HtmlAction));
                        if (action == HtmlActions.Get) {
                            var html = this.getHtml(target);
                            result.Params = { "scriptResult": html };
                        }
                        else {
                            var html = data.getActionParam(this.Html);
                            this.setHtml(target, html);
                            result.Params = { "scriptResult": "true" };
                        }
                        callback(result);
                    };
                    Html.prototype.getHtml = function (target) {
                        return target.innerHTML;
                    };
                    Html.prototype.setHtml = function (target, html) {
                        target.innerHTML = html;
                    };
                    return Html;
                }(Execution.ActionBase));
                Actions.Html = Html;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var IsReady = (function (_super) {
                    __extends(IsReady, _super);
                    function IsReady() {
                        _super.apply(this, arguments);
                    }
                    Object.defineProperty(IsReady.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.IsReady;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    IsReady.prototype.handleAsync = function (data, callback) {
                        var state = document.readyState.toLowerCase();
                        var isReady = state == "complete" || state == "interactive";
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": isReady };
                        callback(result);
                    };
                    return IsReady;
                }(Execution.ActionBase));
                Actions.IsReady = IsReady;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var Navigate = (function (_super) {
                    __extends(Navigate, _super);
                    function Navigate() {
                        _super.apply(this, arguments);
                        this.urlParam = "url";
                    }
                    Object.defineProperty(Navigate.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.Navigate;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Navigate.prototype.handleAsync = function (data, callback) {
                        var url = data.getActionParam(this.urlParam);
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": true };
                        this.trigger(url);
                        callback(result);
                    };
                    Navigate.prototype.trigger = function (url) {
                        window.setTimeout(function () {
                            window.location.href = url;
                        }, 50);
                    };
                    return Navigate;
                }(Execution.ActionBase));
                Actions.Navigate = Navigate;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var PausedActions;
                (function (PausedActions) {
                    PausedActions[PausedActions["Get"] = 0] = "Get";
                    PausedActions[PausedActions["Set"] = 1] = "Set";
                })(PausedActions || (PausedActions = {}));
                var Paused = (function (_super) {
                    __extends(Paused, _super);
                    function Paused() {
                        _super.apply(this, arguments);
                        this.PausedAction = "action";
                        this.Value = "value";
                    }
                    Object.defineProperty(Paused.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.Paused;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Paused.prototype.handleAsync = function (data, callback) {
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        var target = this.getElement(data);
                        var action = parseInt(data.getActionParam(this.PausedAction));
                        if (action == PausedActions.Get) {
                            var value = this.getPaused(target);
                            result.Params = { "scriptResult": value };
                        }
                        else {
                            var value = Boolean(data.getActionParam(this.Value));
                            this.setPaused(target, value);
                            result.Params = { "scriptResult": "true" };
                        }
                        callback(result);
                    };
                    Paused.prototype.getPaused = function (target) {
                        return target.paused;
                    };
                    Paused.prototype.setPaused = function (target, value) {
                        var audio = target;
                        !value ? audio.play() : audio.pause();
                    };
                    return Paused;
                }(Execution.ActionBase));
                Actions.Paused = Paused;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var PinchActions;
                (function (PinchActions) {
                    PinchActions[PinchActions["In"] = 0] = "In";
                    PinchActions[PinchActions["Out"] = 1] = "Out";
                })(PinchActions || (PinchActions = {}));
                var Pinch = (function (_super) {
                    __extends(Pinch, _super);
                    function Pinch() {
                        _super.apply(this, arguments);
                        this.PinchAction = "action";
                        this.X = "x";
                        this.Y = "y";
                        this.Steps = "steps";
                        this.Distance = "distance";
                        this.Offset = 20;
                        this.Delay = 25;
                    }
                    Object.defineProperty(Pinch.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.Pinch;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Pinch.prototype.handleAsync = function (data, callback) {
                        var target = this.getElement(data);
                        var point = this.safePointTransform(target, parseInt(data.getActionParam(this.X)), parseInt(data.getActionParam(this.Y)));
                        var distance = parseInt(data.getActionParam(this.Distance));
                        var steps = parseInt(data.getActionParam(this.Steps));
                        var action = parseInt(data.getActionParam(this.PinchAction));
                        this.currentAction = action;
                        if (action == PinchActions.In) {
                            this.in(target, point, distance, steps);
                        }
                        else {
                            this.out(target, point, distance, steps);
                        }
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": "true" };
                        callback(result);
                    };
                    Pinch.prototype.in = function (target, point, distance, steps) {
                        var rect = target.getBoundingClientRect();
                        var pntr1X = point.x - this.Offset - distance;
                        var pntr2X = point.x + this.Offset + distance;
                        var pointer1 = {
                            x: rect.left + pntr1X,
                            y: rect.top + point.y
                        };
                        var pointer2 = {
                            x: rect.left + pntr2X,
                            y: rect.top + point.y
                        };
                        this.movePointers(target, [pointer1, pointer2], distance, steps);
                    };
                    Pinch.prototype.out = function (target, point, distance, steps) {
                        var rect = target.getBoundingClientRect();
                        var pntr1X = point.x - this.Offset;
                        var pntr2X = point.x + this.Offset;
                        var pointer1 = {
                            x: rect.left + pntr1X,
                            y: rect.top + point.y
                        };
                        var pointer2 = {
                            x: rect.left + pntr2X,
                            y: rect.top + point.y
                        };
                        this.movePointers(target, [pointer1, pointer2], distance, steps);
                    };
                    Pinch.prototype.movePointers = function (target, startPoints, distance, steps) {
                        var currenDelay = 0;
                        var stepSize = distance / steps;
                        if (this.currentAction == PinchActions.Out)
                            stepSize = stepSize * -1;
                        this.dispatchTouchEvent(target, "touchstart", startPoints, currenDelay);
                        for (var i = 1; i <= steps; i++) {
                            currenDelay += this.Delay;
                            startPoints = this.touchPointsGenerator(startPoints, stepSize);
                            this.dispatchTouchEvent(target, "touchmove", startPoints, currenDelay);
                        }
                        this.dispatchTouchEvent(target, "touchend", startPoints, currenDelay + this.Delay);
                    };
                    Pinch.prototype.touchPointsGenerator = function (currentPoins, stepSize) {
                        var lastPointer1 = currentPoins[0];
                        var lastPointer2 = currentPoins[1];
                        var newPointer1 = {
                            x: lastPointer1.x + stepSize,
                            y: lastPointer1.y
                        };
                        var newPointer2 = {
                            x: lastPointer2.x - stepSize,
                            y: lastPointer2.y
                        };
                        return [newPointer1, newPointer2];
                    };
                    Pinch.prototype.safePointTransform = function (target, x, y) {
                        var point;
                        if (x < 0 || y < 0) {
                            var rect = target.getBoundingClientRect();
                            point = {
                                x: rect.left + Math.floor(rect.width),
                                y: rect.top + Math.floor(rect.height)
                            };
                        }
                        else {
                            point = { x: x, y: y };
                        }
                        return point;
                    };
                    return Pinch;
                }(Actions.TouchActionBase));
                Actions.Pinch = Pinch;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var PressKey = (function (_super) {
                    __extends(PressKey, _super);
                    function PressKey() {
                        _super.apply(this, arguments);
                        this.KeyCode = "keyCode";
                        this.AltKey = "altKey";
                        this.CtrlKey = "ctrlKey";
                        this.ShiftKey = "shiftKey";
                    }
                    Object.defineProperty(PressKey.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.PressKey;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    PressKey.prototype.handleAsync = function (data, callback) {
                        var target = this.getElement(data);
                        var code = parseInt(data.getActionParam(this.KeyCode));
                        var alt = Boolean(data.getActionParam(this.AltKey));
                        var ctrl = Boolean(data.getActionParam(this.CtrlKey));
                        var shift = Boolean(data.getActionParam(this.ShiftKey));
                        this.press(target, code, alt, ctrl, shift);
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": true };
                        callback(result);
                    };
                    PressKey.prototype.press = function (target, keyCode, altModifier, ctrlModifier, shiftModifier) {
                        var event = document.createEvent("Events");
                        event.initEvent("keypress", true, true);
                        event.altKey = altModifier;
                        event.shiftKey = shiftModifier;
                        event.ctrlKey = ctrlModifier;
                        event.charCode = keyCode;
                        event.keyCode = keyCode;
                        event.which = keyCode;
                        event.cancelBubble = false;
                        event.detail = 0;
                        target.dispatchEvent(event);
                    };
                    return PressKey;
                }(Execution.ActionBase));
                Actions.PressKey = PressKey;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var ScrollType;
                (function (ScrollType) {
                    ScrollType[ScrollType["Coordinates"] = 0] = "Coordinates";
                    ScrollType[ScrollType["ToElement"] = 1] = "ToElement";
                })(ScrollType || (ScrollType = {}));
                var Scroll = (function (_super) {
                    __extends(Scroll, _super);
                    function Scroll() {
                        _super.apply(this, arguments);
                        this.Type = "type";
                        this.X = "x";
                        this.Y = "y";
                    }
                    Object.defineProperty(Scroll.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.Scroll;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Scroll.prototype.handleAsync = function (data, callback) {
                        var target = this.getElement(data);
                        var type = parseInt(data.getActionParam(this.Type));
                        if (type == ScrollType.Coordinates) {
                            var x = parseInt(data.getActionParam(this.X));
                            var y = parseInt(data.getActionParam(this.Y));
                            this.scrollViaCoordinates(target, x, y);
                        }
                        else {
                            this.scrollToElement(target);
                        }
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": true };
                        callback(result);
                    };
                    Scroll.prototype.scrollViaCoordinates = function (target, x, y) {
                        if (x != 0)
                            target.scrollLeft = x;
                        if (y != 0)
                            target.scrollTop = y;
                    };
                    Scroll.prototype.scrollToElement = function (target) {
                        target.scrollIntoView();
                    };
                    return Scroll;
                }(Execution.ActionBase));
                Actions.Scroll = Scroll;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var IndexActions;
                (function (IndexActions) {
                    IndexActions[IndexActions["Get"] = 0] = "Get";
                    IndexActions[IndexActions["Set"] = 1] = "Set";
                })(IndexActions || (IndexActions = {}));
                var SelectedIndex = (function (_super) {
                    __extends(SelectedIndex, _super);
                    function SelectedIndex() {
                        _super.apply(this, arguments);
                        this.IndexAction = "action";
                        this.Value = "value";
                    }
                    Object.defineProperty(SelectedIndex.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.SelectedIndex;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    SelectedIndex.prototype.handleAsync = function (data, callback) {
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        var target = this.getElement(data);
                        var action = parseInt(data.getActionParam(this.IndexAction));
                        if (action == IndexActions.Get) {
                            var value = this.getSelectedIndex(target);
                            result.Params = { "scriptResult": value };
                        }
                        else {
                            var value = data.getActionParam(this.Value);
                            this.setSelectedIndex(target, value);
                            result.Params = { "scriptResult": "true" };
                        }
                        callback(result);
                    };
                    SelectedIndex.prototype.getSelectedIndex = function (target) {
                        var retValue = new Array();
                        var selectElement = target;
                        for (var i = 0; i < selectElement.options.length; i++) {
                            var option = selectElement.options[i];
                            if (option.selected)
                                retValue.push(i);
                        }
                        return retValue;
                    };
                    SelectedIndex.prototype.setSelectedIndex = function (target, values) {
                        var setCounter = 0;
                        var selectElement = target;
                        if (!selectElement.multiple && values.length > 1)
                            throw new Error('This element allows only one selection at a time.');
                        selectElement.selectedIndex = -1;
                        for (var i = 0; i < selectElement.options.length; i++) {
                            var option = selectElement.options[i];
                            var select = values.indexOf(i) != -1;
                            option.selected = select;
                            if (select)
                                setCounter++;
                        }
                        if (setCounter != values.length)
                            throw new Error('Specified value is not valid.');
                        this.triggerChangeEvent(target);
                    };
                    SelectedIndex.prototype.triggerChangeEvent = function (target) {
                        var event = document.createEvent("HTMLEvents");
                        event.initEvent("change", true, true);
                        target.dispatchEvent(event);
                    };
                    return SelectedIndex;
                }(Execution.ActionBase));
                Actions.SelectedIndex = SelectedIndex;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var TextActions;
                (function (TextActions) {
                    TextActions[TextActions["Get"] = 0] = "Get";
                    TextActions[TextActions["Set"] = 1] = "Set";
                })(TextActions || (TextActions = {}));
                var SelectedText = (function (_super) {
                    __extends(SelectedText, _super);
                    function SelectedText() {
                        _super.apply(this, arguments);
                        this.TextAction = "action";
                        this.Value = "value";
                    }
                    Object.defineProperty(SelectedText.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.SelectedText;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    SelectedText.prototype.handleAsync = function (data, callback) {
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        var target = this.getElement(data);
                        var action = parseInt(data.getActionParam(this.TextAction));
                        if (action == TextActions.Get) {
                            var value = this.getSelectedText(target);
                            result.Params = { "scriptResult": value };
                        }
                        else {
                            var value = data.getActionParam(this.Value);
                            this.setSelectedText(target, value);
                            result.Params = { "scriptResult": "true" };
                        }
                        callback(result);
                    };
                    SelectedText.prototype.getSelectedText = function (target) {
                        var retValue = new Array();
                        var selectElement = target;
                        for (var i = 0; i < selectElement.options.length; i++) {
                            var option = selectElement.options[i];
                            if (option.selected)
                                retValue.push(option.text);
                        }
                        return retValue;
                    };
                    SelectedText.prototype.setSelectedText = function (target, values) {
                        var setCounter = 0;
                        var selectElement = target;
                        if (!selectElement.multiple && values.length > 1)
                            throw new Error('This element allows only one selection at a time.');
                        selectElement.selectedIndex = -1;
                        for (var i = 0; i < selectElement.options.length; i++) {
                            var option = selectElement.options[i];
                            var select = values.indexOf(option.text) != -1;
                            option.selected = select;
                            if (select)
                                setCounter++;
                        }
                        if (setCounter != values.length)
                            throw new Error('Specified value is not valid.');
                        this.triggerChangeEvent(target);
                    };
                    SelectedText.prototype.triggerChangeEvent = function (target) {
                        var event = document.createEvent("HTMLEvents");
                        event.initEvent("change", true, true);
                        target.dispatchEvent(event);
                    };
                    return SelectedText;
                }(Execution.ActionBase));
                Actions.SelectedText = SelectedText;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var ValueActions;
                (function (ValueActions) {
                    ValueActions[ValueActions["Get"] = 0] = "Get";
                    ValueActions[ValueActions["Set"] = 1] = "Set";
                })(ValueActions || (ValueActions = {}));
                var SelectedValue = (function (_super) {
                    __extends(SelectedValue, _super);
                    function SelectedValue() {
                        _super.apply(this, arguments);
                        this.ValueAction = "action";
                        this.Value = "value";
                    }
                    Object.defineProperty(SelectedValue.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.SelectedValue;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    SelectedValue.prototype.handleAsync = function (data, callback) {
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        var target = this.getElement(data);
                        var action = parseInt(data.getActionParam(this.ValueAction));
                        if (action == ValueActions.Get) {
                            var value = this.getSelectedValue(target);
                            result.Params = { "scriptResult": value };
                        }
                        else {
                            var value = data.getActionParam(this.Value);
                            this.setSelectedValue(target, value);
                            result.Params = { "scriptResult": "true" };
                        }
                        callback(result);
                    };
                    SelectedValue.prototype.getSelectedValue = function (target) {
                        var retValue = new Array();
                        var selectElement = target;
                        for (var i = 0; i < selectElement.options.length; i++) {
                            var option = selectElement.options[i];
                            if (option.selected)
                                retValue.push(option.value);
                        }
                        return retValue;
                    };
                    SelectedValue.prototype.setSelectedValue = function (target, values) {
                        var setCounter = 0;
                        var selectElement = target;
                        if (!selectElement.multiple && values.length > 1)
                            throw new Error('This element allows only one selection at a time.');
                        selectElement.selectedIndex = -1;
                        for (var i = 0; i < selectElement.options.length; i++) {
                            var option = selectElement.options[i];
                            var select = values.indexOf(option.value) != -1;
                            option.selected = select;
                            if (select)
                                setCounter++;
                        }
                        if (setCounter != values.length)
                            throw new Error('Specified value is not valid.');
                        this.triggerChangeEvent(target);
                    };
                    SelectedValue.prototype.triggerChangeEvent = function (target) {
                        var event = document.createEvent("HTMLEvents");
                        event.initEvent("change", true, true);
                        target.dispatchEvent(event);
                    };
                    return SelectedValue;
                }(Execution.ActionBase));
                Actions.SelectedValue = SelectedValue;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var StyleActions;
                (function (StyleActions) {
                    StyleActions[StyleActions["Get"] = 0] = "Get";
                    StyleActions[StyleActions["Set"] = 1] = "Set";
                })(StyleActions || (StyleActions = {}));
                var Style = (function (_super) {
                    __extends(Style, _super);
                    function Style() {
                        _super.apply(this, arguments);
                        this.StyleAction = "action";
                        this.Property = "property";
                        this.Value = "value";
                    }
                    Object.defineProperty(Style.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.Style;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Style.prototype.handleAsync = function (data, callback) {
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        var target = this.getElement(data);
                        var action = parseInt(data.getActionParam(this.StyleAction));
                        var property = data.getActionParam(this.Property);
                        if (action == StyleActions.Get) {
                            var value = this.getStyleValue(target, property);
                            result.Params = { "scriptResult": value };
                        }
                        else {
                            var value = data.getActionParam(this.Value);
                            this.setStyleValue(target, property, value);
                            result.Params = { "scriptResult": "true" };
                        }
                        callback(result);
                    };
                    Style.prototype.getStyleValue = function (target, property) {
                        return target.style[property];
                    };
                    Style.prototype.setStyleValue = function (target, property, value) {
                        target.style[property] = value;
                    };
                    return Style;
                }(Execution.ActionBase));
                Actions.Style = Style;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var SwipeDirection;
                (function (SwipeDirection) {
                    SwipeDirection[SwipeDirection["Right"] = 0] = "Right";
                    SwipeDirection[SwipeDirection["Left"] = 1] = "Left";
                    SwipeDirection[SwipeDirection["Up"] = 2] = "Up";
                    SwipeDirection[SwipeDirection["Down"] = 3] = "Down";
                })(SwipeDirection || (SwipeDirection = {}));
                var Swipe = (function (_super) {
                    __extends(Swipe, _super);
                    function Swipe() {
                        _super.apply(this, arguments);
                        this.Direction = "direction";
                        this.Steps = "steps";
                        this.StepDelay = "stepDelay";
                        this.SwipeDistance = "swipeDistance";
                    }
                    Object.defineProperty(Swipe.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.Swipe;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Swipe.prototype.handleAsync = function (data, callback) {
                        var target = this.getElement(data);
                        var direction = parseInt(data.getActionParam(this.Direction));
                        var steps = parseInt(data.getActionParam(this.Steps));
                        var stepDelay = parseInt(data.getActionParam(this.StepDelay));
                        var swipeDistance = parseInt(data.getActionParam(this.SwipeDistance));
                        this.swipe(target, direction, steps, stepDelay, swipeDistance);
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": "true" };
                        callback(result);
                    };
                    Swipe.prototype.swipe = function (target, direction, steps, stepDelay, swipeDistance) {
                        var rect = target.getBoundingClientRect();
                        var startX = rect.left + Math.floor(rect.width / 2);
                        var startY = rect.top + Math.floor(rect.height / 2);
                        var endX = 0;
                        var endY = 0;
                        switch (direction) {
                            case SwipeDirection.Up:
                                endX = startX;
                                endY = startY - swipeDistance;
                                break;
                            case SwipeDirection.Down:
                                endX = startX;
                                endY = startY + swipeDistance;
                                break;
                            case SwipeDirection.Left:
                                endX = startX - swipeDistance;
                                endY = startY;
                                break;
                            case SwipeDirection.Right:
                                endX = startX + swipeDistance;
                                endY = startY;
                                break;
                            default:
                                endX = startX;
                                endY = startY;
                                break;
                        }
                        this.pan(target, startX, startY, endX, endY, steps, stepDelay);
                    };
                    return Swipe;
                }(Actions.Pan));
                Actions.Swipe = Swipe;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var Tap = (function (_super) {
                    __extends(Tap, _super);
                    function Tap() {
                        _super.apply(this, arguments);
                        this.TapType = "tapType";
                        this.TapCount = "tapCount";
                        this.TapDownDelay = "tapDownDelay";
                        this.TapUpDelay = "tapUpDelay";
                        this.TapLocationX = "x";
                        this.TapLocationY = "y";
                    }
                    Object.defineProperty(Tap.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.Tap;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Tap.prototype.handleAsync = function (data, callback) {
                        var target = this.getElement(data);
                        var type = data.getActionParam(this.TapType);
                        var tapDownDelay = parseInt(data.getActionParam(this.TapDownDelay));
                        var tapUpDelay = parseInt(data.getActionParam(this.TapUpDelay));
                        var tapCount = parseInt(data.getActionParam(this.TapCount));
                        switch (type) {
                            case "center":
                                this.tapCenter(target, tapCount, tapDownDelay, tapUpDelay);
                                break;
                            case "centerLeft":
                                this.tapCenterLeft(target, tapCount, tapDownDelay, tapUpDelay);
                                break;
                            case "centerRight":
                                this.tapCenterRight(target, tapCount, tapDownDelay, tapUpDelay);
                                break;
                            case "location":
                                var x = parseInt(data.getActionParam(this.TapLocationX));
                                var y = parseInt(data.getActionParam(this.TapLocationY));
                                this.tap(target, tapCount, tapDownDelay, tapUpDelay, x, y);
                                break;
                        }
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": true };
                        callback(result);
                    };
                    Tap.prototype.tap = function (target, tapCount, tapDownDelay, tapUpDelay, tapLocX, tapLocY) {
                        var points = [{ x: tapLocX, y: tapLocY }];
                        var delay = 0;
                        for (var i = 0; i < tapCount; i++) {
                            this.dispatchTouchEvent(target, "touchstart", points, delay);
                            delay += tapDownDelay;
                            this.dispatchTouchEvent(target, "touchend", points, delay);
                            delay += 50;
                            this.dispatchPointerEvent(target, "mouseover", Actions.MouseButton.Left, points[0], delay);
                            this.dispatchPointerEvent(target, "mousedown", Actions.MouseButton.Left, points[0], delay);
                            this.dispatchPointerEvent(target, "mouseup", Actions.MouseButton.Left, points[0], delay);
                            this.dispatchPointerEvent(target, "click", Actions.MouseButton.Left, points[0], delay);
                            delay += tapUpDelay;
                        }
                    };
                    Tap.prototype.tapCenter = function (target, tapCount, tapDownDelay, tapUpDelay) {
                        var rect = target.getBoundingClientRect();
                        var tapLocX = rect.left + Math.floor(rect.width);
                        var tapLocY = rect.top + Math.floor(rect.height);
                        this.tap(target, tapCount, tapDownDelay, tapUpDelay, tapLocX, tapLocY);
                    };
                    Tap.prototype.tapCenterLeft = function (target, tapCount, tapDownDelay, tapUpDelay) {
                        var rect = target.getBoundingClientRect();
                        var tapLocX = rect.left + Math.floor(rect.width / 5);
                        var tapLocY = rect.top + Math.floor(rect.height / 2);
                        this.tap(target, tapCount, tapDownDelay, tapUpDelay, tapLocX, tapLocY);
                    };
                    Tap.prototype.tapCenterRight = function (target, tapCount, tapDownDelay, tapUpDelay) {
                        var rect = target.getBoundingClientRect();
                        var tapLocX = rect.left + Math.floor(rect.width / 5 * 4);
                        var tapLocY = rect.top + Math.floor(rect.height / 2);
                        this.tap(target, tapCount, tapDownDelay, tapUpDelay, tapLocX, tapLocY);
                    };
                    return Tap;
                }(Actions.TouchActionBase));
                Actions.Tap = Tap;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var TextContentActions;
                (function (TextContentActions) {
                    TextContentActions[TextContentActions["Get"] = 0] = "Get";
                    TextContentActions[TextContentActions["Set"] = 1] = "Set";
                })(TextContentActions || (TextContentActions = {}));
                var TextContent = (function (_super) {
                    __extends(TextContent, _super);
                    function TextContent() {
                        _super.apply(this, arguments);
                        this.ContentAction = "action";
                        this.Value = "value";
                    }
                    Object.defineProperty(TextContent.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.TextContent;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    TextContent.prototype.handleAsync = function (data, callback) {
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        var target = this.getElement(data);
                        var action = parseInt(data.getActionParam(this.ContentAction));
                        if (action == TextContentActions.Get) {
                            var value = this.getContent(target);
                            result.Params = { "scriptResult": value };
                        }
                        else {
                            var value = data.getActionParam(this.Value);
                            this.setContent(target, value);
                            result.Params = { "scriptResult": "true" };
                        }
                        callback(result);
                    };
                    TextContent.prototype.getContent = function (target) {
                        return target.textContent;
                    };
                    TextContent.prototype.setContent = function (target, value) {
                        target.textContent = value;
                    };
                    return TextContent;
                }(Execution.ActionBase));
                Actions.TextContent = TextContent;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var TwoFingerRotate = (function (_super) {
                    __extends(TwoFingerRotate, _super);
                    function TwoFingerRotate() {
                        _super.apply(this, arguments);
                        this.Radius = "radius";
                        this.StepSize = "stepSize";
                        this.StepDelay = "stepDelay";
                        this.Steps = "steps";
                        this.X = "x";
                        this.Y = "y";
                    }
                    Object.defineProperty(TwoFingerRotate.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.TwoFingerRotate;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    TwoFingerRotate.prototype.handleAsync = function (data, callback) {
                        var target = this.getElement(data);
                        var radius = parseInt(data.getActionParam(this.Radius));
                        var stepSize = parseInt(data.getActionParam(this.StepSize));
                        var stepDelay = parseInt(data.getActionParam(this.StepDelay));
                        var steps = parseInt(data.getActionParam(this.Steps));
                        var center = this.safePointTransform(target, parseInt(data.getActionParam(this.X)), parseInt(data.getActionParam(this.Y)));
                        this.rotate(target, center, radius, stepSize, steps, stepDelay);
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": "true" };
                        callback(result);
                    };
                    TwoFingerRotate.prototype.rotate = function (target, center, radius, stepSize, steps, stepDelay) {
                        var rect = target.getBoundingClientRect();
                        var pntr1X = center.x - radius;
                        var pntr2X = center.x + radius;
                        var pointer1 = {
                            x: rect.left + pntr1X,
                            y: rect.top + center.y
                        };
                        var pointer2 = {
                            x: rect.left + pntr2X,
                            y: rect.top + center.y
                        };
                        this.movePointers(target, [pointer1, pointer2], radius, steps, stepSize, stepDelay);
                    };
                    TwoFingerRotate.prototype.movePointers = function (target, startPoints, radius, steps, stepSize, stepDelay) {
                        var currenDelay = 0;
                        var angle = 0;
                        this.dispatchTouchEvent(target, "touchstart", startPoints, currenDelay);
                        for (var i = 1; i <= steps; i++) {
                            currenDelay += stepDelay;
                            startPoints = this.touchPointsGenerator(startPoints, stepSize, radius, angle);
                            angle += stepSize;
                            this.dispatchTouchEvent(target, "touchmove", startPoints, currenDelay);
                        }
                        this.dispatchTouchEvent(target, "touchend", startPoints, currenDelay + stepDelay);
                    };
                    TwoFingerRotate.prototype.touchPointsGenerator = function (currentPoins, stepSize, radius, angle) {
                        var lastPointer1 = currentPoins[0];
                        var lastPointer2 = currentPoins[1];
                        var rads = angle * Math.PI / 180;
                        var offsetX = Math.cos(rads) * radius;
                        var offsetY = Math.sin(rads) * radius;
                        var newPointer1 = {
                            x: lastPointer1.x + offsetX,
                            y: lastPointer1.y + offsetY
                        };
                        var newPointer2 = {
                            x: lastPointer2.x - offsetX,
                            y: lastPointer2.y - offsetY
                        };
                        return [newPointer1, newPointer2];
                    };
                    TwoFingerRotate.prototype.safePointTransform = function (target, x, y) {
                        var point;
                        if (x < 0 || y < 0) {
                            var rect = target.getBoundingClientRect();
                            point = {
                                x: rect.left + Math.floor(rect.width),
                                y: rect.top + Math.floor(rect.height)
                            };
                        }
                        else {
                            point = { x: x, y: y };
                        }
                        return point;
                    };
                    return TwoFingerRotate;
                }(Actions.TouchActionBase));
                Actions.TwoFingerRotate = TwoFingerRotate;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Actions;
            (function (Actions) {
                var ValueActions;
                (function (ValueActions) {
                    ValueActions[ValueActions["Get"] = 0] = "Get";
                    ValueActions[ValueActions["Set"] = 1] = "Set";
                })(ValueActions || (ValueActions = {}));
                var Value = (function (_super) {
                    __extends(Value, _super);
                    function Value() {
                        _super.apply(this, arguments);
                        this.ValueAction = "action";
                        this.Value = "value";
                    }
                    Object.defineProperty(Value.prototype, "Action", {
                        get: function () {
                            return Execution.Commands.Value;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Value.prototype.handleAsync = function (data, callback) {
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        var target = this.getElement(data);
                        var action = parseInt(data.getActionParam(this.ValueAction));
                        if (action == ValueActions.Get) {
                            var value = this.getValue(target);
                            result.Params = { "scriptResult": value };
                        }
                        else {
                            var value = data.getActionParam(this.Value);
                            this.setValue(target, value);
                            result.Params = { "scriptResult": "true" };
                        }
                        callback(result);
                    };
                    Value.prototype.getValue = function (target) {
                        return target["value"];
                    };
                    Value.prototype.setValue = function (target, value) {
                        target["value"] = value;
                    };
                    return Value;
                }(Execution.ActionBase));
                Actions.Value = Value;
            })(Actions = Execution.Actions || (Execution.Actions = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Dialogs;
            (function (Dialogs) {
                (function (DialogTypes) {
                    DialogTypes[DialogTypes["Alert"] = 0] = "Alert";
                    DialogTypes[DialogTypes["Confirm"] = 1] = "Confirm";
                    DialogTypes[DialogTypes["Prompt"] = 2] = "Prompt";
                })(Dialogs.DialogTypes || (Dialogs.DialogTypes = {}));
                var DialogTypes = Dialogs.DialogTypes;
                var DialogKeys = (function () {
                    function DialogKeys() {
                    }
                    DialogKeys.Alert = "alert_dialog";
                    DialogKeys.Confirm = "confirm_dialog";
                    DialogKeys.Prompt = "prompt_dialog";
                    return DialogKeys;
                }());
                Dialogs.DialogKeys = DialogKeys;
                var DialogsHandler = (function () {
                    function DialogsHandler() {
                    }
                    DialogsHandler.getState = function () {
                        var states = {};
                        for (var i in DialogsHandler.states.tList) {
                            var state = DialogsHandler.states.tList[i];
                            var key = DialogsHandler.getKey(state.key);
                            states[key] = [state.value];
                        }
                        return states;
                    };
                    DialogsHandler.overrideAlert = function (options) {
                        DialogsHandler.originalHandlers.add(DialogTypes.Alert, window.alert);
                        window.alert = function (text) {
                            var state = DialogsHandler.states.getValue(DialogTypes.Alert);
                            state.handled = true;
                            state.actualText = text;
                            DialogsHandler.restoreHandler(DialogTypes.Alert);
                        };
                        var state = {
                            handled: false,
                            prepareOptions: options,
                            actualText: "",
                            defaultText: ""
                        };
                        DialogsHandler.states.add(DialogTypes.Alert, state);
                    };
                    DialogsHandler.overrideConfirm = function (options) {
                        DialogsHandler.originalHandlers.add(DialogTypes.Confirm, window.confirm);
                        window.confirm = function (text) {
                            var state = DialogsHandler.states.getValue(DialogTypes.Confirm);
                            state.handled = true;
                            state.actualText = text;
                            var result = state.prepareOptions ? state.prepareOptions.dialogResult : false;
                            DialogsHandler.restoreHandler(DialogTypes.Confirm);
                            return result;
                        };
                        var state = {
                            handled: false,
                            prepareOptions: options,
                            actualText: "",
                            defaultText: ""
                        };
                        DialogsHandler.states.add(DialogTypes.Confirm, state);
                    };
                    DialogsHandler.overridePrompt = function (options) {
                        DialogsHandler.originalHandlers.add(DialogTypes.Prompt, window.prompt);
                        window.prompt = function (text, defaultText) {
                            var state = DialogsHandler.states.getValue(DialogTypes.Prompt);
                            state.handled = true;
                            state.actualText = text;
                            state.defaultText = defaultText;
                            var result = state.prepareOptions ? state.prepareOptions.dialogResult : "";
                            DialogsHandler.restoreHandler(DialogTypes.Prompt);
                            return result;
                        };
                        var state = {
                            handled: false,
                            prepareOptions: options,
                            actualText: "",
                            defaultText: ""
                        };
                        DialogsHandler.states.add(DialogTypes.Prompt, state);
                    };
                    DialogsHandler.getKey = function (type) {
                        if (type == DialogTypes.Alert)
                            return DialogKeys.Alert;
                        else if (type == DialogTypes.Confirm)
                            return DialogKeys.Confirm;
                        else
                            return DialogKeys.Prompt;
                    };
                    DialogsHandler.restoreHandler = function (type) {
                        var handler = DialogsHandler.originalHandlers.getValue(type);
                        if (type == DialogTypes.Alert)
                            window.alert = handler;
                        else if (type == DialogTypes.Confirm)
                            window.confirm = handler;
                        else
                            window.prompt = handler;
                        DialogsHandler.originalHandlers.remove(type);
                    };
                    DialogsHandler.states = new MobileTesting.Collections.Dictionary();
                    DialogsHandler.originalHandlers = new MobileTesting.Collections.Dictionary();
                    return DialogsHandler;
                }());
                Dialogs.DialogsHandler = DialogsHandler;
            })(Dialogs = Execution.Dialogs || (Execution.Dialogs = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Dialogs;
            (function (Dialogs) {
                var GetState = (function (_super) {
                    __extends(GetState, _super);
                    function GetState() {
                        _super.apply(this, arguments);
                    }
                    GetState.prototype.handleAsync = function (data, callback) {
                        var states = Dialogs.DialogsHandler.getState();
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "dialogsState": states };
                        callback(result);
                    };
                    return GetState;
                }(Execution.ActionBase));
                Dialogs.GetState = GetState;
            })(Dialogs = Execution.Dialogs || (Execution.Dialogs = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Execution;
        (function (Execution) {
            var Dialogs;
            (function (Dialogs) {
                var Prepare = (function (_super) {
                    __extends(Prepare, _super);
                    function Prepare() {
                        _super.apply(this, arguments);
                    }
                    Prepare.prototype.handleAsync = function (data, callback) {
                        var key = data.getActionParam("key");
                        var options = data.getActionParam("options");
                        switch (key) {
                            case Dialogs.DialogKeys.Alert:
                                Dialogs.DialogsHandler.overrideAlert(options);
                                break;
                            case Dialogs.DialogKeys.Confirm:
                                Dialogs.DialogsHandler.overrideConfirm(options);
                                break;
                            case Dialogs.DialogKeys.Prompt:
                                Dialogs.DialogsHandler.overridePrompt(options);
                                break;
                        }
                        var result = new Execution.ActionResult();
                        result.Result = this.getSuccessResult("");
                        result.Params = { "scriptResult": "true" };
                        callback(result);
                    };
                    return Prepare;
                }(Execution.ActionBase));
                Dialogs.Prepare = Prepare;
            })(Dialogs = Execution.Dialogs || (Execution.Dialogs = {}));
        })(Execution = MobileTesting.Execution || (MobileTesting.Execution = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Recording;
        (function (Recording) {
            var Translators;
            (function (Translators) {
                var TranslatorBase = (function () {
                    function TranslatorBase() {
                    }
                    Object.defineProperty(TranslatorBase.prototype, "Action", {
                        get: function () { return ""; },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(TranslatorBase.prototype, "Order", {
                        get: function () {
                            return -1;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    TranslatorBase.prototype.getFriendlyName = function (targets) {
                        return MobileTesting.Find.QueryBuilder.generateFriendlyName(targets[0]);
                    };
                    TranslatorBase.prototype.getFrameInfo = function (targets) {
                        var target = targets[0];
                        return MobileTesting.Find.FrameInfo.getFromElement(target);
                    };
                    return TranslatorBase;
                }());
                Translators.TranslatorBase = TranslatorBase;
                var PointTranslatorBase = (function (_super) {
                    __extends(PointTranslatorBase, _super);
                    function PointTranslatorBase() {
                        _super.apply(this, arguments);
                    }
                    PointTranslatorBase.prototype.buildDescriptor = function (targets) {
                        var desc = new Recording.Descriptor();
                        desc.cmd = this.Action;
                        desc.params = {
                            query: MobileTesting.Find.QueryBuilder.buildQueries(targets)
                        };
                        return desc;
                    };
                    return PointTranslatorBase;
                }(TranslatorBase));
                Translators.PointTranslatorBase = PointTranslatorBase;
                var KeyInputTranslatorBase = (function (_super) {
                    __extends(KeyInputTranslatorBase, _super);
                    function KeyInputTranslatorBase() {
                        _super.apply(this, arguments);
                    }
                    return KeyInputTranslatorBase;
                }(TranslatorBase));
                Translators.KeyInputTranslatorBase = KeyInputTranslatorBase;
            })(Translators = Recording.Translators || (Recording.Translators = {}));
        })(Recording = MobileTesting.Recording || (MobileTesting.Recording = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Recording;
        (function (Recording) {
            var Translators;
            (function (Translators) {
                var Checked = (function (_super) {
                    __extends(Checked, _super);
                    function Checked() {
                        _super.apply(this, arguments);
                    }
                    Object.defineProperty(Checked.prototype, "Action", {
                        get: function () {
                            return "web.setChecked";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(Checked.prototype, "Order", {
                        get: function () {
                            return 100;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Checked.prototype.match = function (action, targets) {
                        var target = targets[0];
                        return action == "click" && targets.length == 2 && targets[0] == targets[1] && target != undefined && target.type == "checkbox";
                    };
                    Checked.prototype.buildDescriptor = function (targets) {
                        var target = targets[0];
                        var desc = new Recording.Descriptor();
                        desc.cmd = this.Action;
                        desc.params = {
                            query: [MobileTesting.Find.QueryBuilder.buildQuery(target)],
                            checkedValue: target.checked
                        };
                        return desc;
                    };
                    return Checked;
                }(Translators.PointTranslatorBase));
                Translators.Checked = Checked;
            })(Translators = Recording.Translators || (Recording.Translators = {}));
        })(Recording = MobileTesting.Recording || (MobileTesting.Recording = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Recording;
        (function (Recording) {
            var Translators;
            (function (Translators) {
                var Click = (function (_super) {
                    __extends(Click, _super);
                    function Click() {
                        _super.apply(this, arguments);
                    }
                    Object.defineProperty(Click.prototype, "Action", {
                        get: function () {
                            return "web.click";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(Click.prototype, "Order", {
                        get: function () {
                            return 500;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Click.prototype.match = function (action, targets) {
                        if (this.ignoreMatch(targets[0]))
                            return false;
                        return action == "click" && targets.length == 2 && targets[0] == targets[1];
                    };
                    Click.prototype.buildDescriptor = function (targets) {
                        var desc = new Recording.Descriptor();
                        desc.cmd = this.Action;
                        desc.params = {
                            query: [MobileTesting.Find.QueryBuilder.buildQuery(targets[0])]
                        };
                        return desc;
                    };
                    Click.prototype.ignoreMatch = function (target) {
                        var ignore = false;
                        var tagName = target.tagName.toLowerCase();
                        ignore = (tagName == "input" && (target.type == null || target.type == "text" || target.type == "url" || target.type == "email")) ||
                            tagName == "textarea" || tagName == "select" || tagName == "option";
                        return ignore;
                    };
                    return Click;
                }(Translators.PointTranslatorBase));
                Translators.Click = Click;
            })(Translators = Recording.Translators || (Recording.Translators = {}));
        })(Recording = MobileTesting.Recording || (MobileTesting.Recording = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Recording;
        (function (Recording) {
            var Translators;
            (function (Translators) {
                var SelectedValue = (function (_super) {
                    __extends(SelectedValue, _super);
                    function SelectedValue() {
                        _super.apply(this, arguments);
                    }
                    Object.defineProperty(SelectedValue.prototype, "Action", {
                        get: function () {
                            return "web.setSelectedValue";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(SelectedValue.prototype, "Order", {
                        get: function () {
                            return 200;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    SelectedValue.prototype.match = function (action, targets) {
                        var target = targets[0];
                        return action == "change" && targets.length == 2 && targets[0] == targets[1] && target != undefined && target.tagName.toLowerCase() == "select" && !target.multiple;
                    };
                    SelectedValue.prototype.buildDescriptor = function (targets) {
                        var target = targets[0];
                        var value = "";
                        for (var i = 0; i < target.children.length; i++) {
                            var child = target.children[i];
                            if (child.selected) {
                                value = child.value ? child.value : child.text;
                                break;
                            }
                        }
                        var desc = new Recording.Descriptor();
                        desc.cmd = this.Action;
                        desc.params = {
                            query: [MobileTesting.Find.QueryBuilder.buildQuery(target)],
                            selValue: [value]
                        };
                        return desc;
                    };
                    return SelectedValue;
                }(Translators.PointTranslatorBase));
                Translators.SelectedValue = SelectedValue;
            })(Translators = Recording.Translators || (Recording.Translators = {}));
        })(Recording = MobileTesting.Recording || (MobileTesting.Recording = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Recording;
        (function (Recording) {
            var Translators;
            (function (Translators) {
                var SelectedValueMultiple = (function (_super) {
                    __extends(SelectedValueMultiple, _super);
                    function SelectedValueMultiple() {
                        _super.apply(this, arguments);
                    }
                    Object.defineProperty(SelectedValueMultiple.prototype, "Action", {
                        get: function () {
                            return "web.setSelectedValue";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(SelectedValueMultiple.prototype, "Order", {
                        get: function () {
                            return 300;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    SelectedValueMultiple.prototype.match = function (action, targets) {
                        var target = targets[0];
                        return action == "change" && targets.length == 2 && target != undefined && target.tagName.toLowerCase() == "select" && target.multiple;
                    };
                    SelectedValueMultiple.prototype.buildDescriptor = function (targets) {
                        var target = targets[0];
                        var values = new Array();
                        for (var i = 0; i < target.children.length; i++) {
                            var child = target.children[i];
                            if (child.selected) {
                                var value = child.value ? child.value : child.text;
                                values.push(value);
                            }
                        }
                        var desc = new Recording.Descriptor();
                        desc.cmd = this.Action;
                        desc.params = {
                            query: [MobileTesting.Find.QueryBuilder.buildQuery(target)],
                            selValue: values
                        };
                        return desc;
                    };
                    return SelectedValueMultiple;
                }(Translators.SelectedValue));
                Translators.SelectedValueMultiple = SelectedValueMultiple;
            })(Translators = Recording.Translators || (Recording.Translators = {}));
        })(Recording = MobileTesting.Recording || (MobileTesting.Recording = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Recording;
        (function (Recording) {
            var Translators;
            (function (Translators) {
                var Tap = (function (_super) {
                    __extends(Tap, _super);
                    function Tap() {
                        _super.apply(this, arguments);
                    }
                    Object.defineProperty(Tap.prototype, "Action", {
                        get: function () {
                            return "web.tap";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(Tap.prototype, "Order", {
                        get: function () {
                            return 400;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Tap.prototype.match = function (action, targets) {
                        if (this.ignoreMatch(targets[0]))
                            return false;
                        return action == "touchend" && targets.length == 2 && targets[0] == targets[1];
                    };
                    Tap.prototype.buildDescriptor = function (targets) {
                        var desc = new Recording.Descriptor();
                        desc.cmd = this.Action;
                        desc.params = {
                            query: [MobileTesting.Find.QueryBuilder.buildQuery(targets[0])]
                        };
                        return desc;
                    };
                    Tap.prototype.ignoreMatch = function (target) {
                        var ignore = false;
                        var tagName = target.tagName.toLowerCase();
                        ignore = (tagName == "input" && (target.type == null || target.type == "text" || target.type == "url" || target.type == "email")) ||
                            tagName == "textarea" || tagName == "select" || tagName == "option";
                        return ignore;
                    };
                    return Tap;
                }(Translators.PointTranslatorBase));
                Translators.Tap = Tap;
            })(Translators = Recording.Translators || (Recording.Translators = {}));
        })(Recording = MobileTesting.Recording || (MobileTesting.Recording = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var MobileTesting;
    (function (MobileTesting) {
        var Recording;
        (function (Recording) {
            var Translators;
            (function (Translators) {
                var TypeText = (function (_super) {
                    __extends(TypeText, _super);
                    function TypeText() {
                        _super.apply(this, arguments);
                    }
                    Object.defineProperty(TypeText.prototype, "Action", {
                        get: function () {
                            return "web.setValue";
                        },
                        enumerable: true,
                        configurable: true
                    });
                    Object.defineProperty(TypeText.prototype, "Order", {
                        get: function () {
                            return 100;
                        },
                        enumerable: true,
                        configurable: true
                    });
                    TypeText.prototype.match = function (action, targets) {
                        return action == "keyup" && targets.length == 2 && targets[0] == targets[1];
                    };
                    TypeText.prototype.buildDescriptor = function (targets, keyEvent) {
                        var target = targets[0];
                        var desc = new Recording.Descriptor();
                        desc.cmd = this.Action;
                        desc.params = {
                            query: [MobileTesting.Find.QueryBuilder.buildQuery(targets[0])],
                            value: this.getValue(target, keyEvent)
                        };
                        return desc;
                    };
                    TypeText.prototype.getValue = function (target, keyEvent) {
                        var tagName = target.tagName.toLowerCase();
                        if (tagName == "input") {
                            return target.value;
                        }
                        else if (tagName == "textarea") {
                            return target["value"];
                        }
                        else {
                            return target.textContent;
                        }
                    };
                    return TypeText;
                }(Translators.KeyInputTranslatorBase));
                Translators.TypeText = TypeText;
            })(Translators = Recording.Translators || (Recording.Translators = {}));
        })(Recording = MobileTesting.Recording || (MobileTesting.Recording = {}));
    })(MobileTesting = Telerik.MobileTesting || (Telerik.MobileTesting = {}));
})(Telerik || (Telerik = {}));

window["__telerikMobileAgent"] = agent;

var stateInfo =  {
    wsUrl: "",
    sharedKey: "",
    resumeId: "",
    timeout: 10000,
    autoReconnect: false,
    nativeQuery: "",
    subscribers: new Array()
};

window["__telerikMobileStateInfo"] = stateInfo;

function __telerikMobileAgentExecute(msg) {
    var message;
    window["__telerikMobileAgent"].Storage.setState(stateInfo);
    window["__telerikMobileAgent"].bridgeClient.MessageSend.on(function (data) {
        message = JSON.parse(data["data"])["data"];
    });

    agent.handleMessage(msg);
    return message;
}

function __telerikMobileAgentGetElements() {
    var msg = '{"data": {"cmd": "ctrl.getElements"}}';
    var message;
    window["__telerikMobileAgent"].Storage.setState(stateInfo);
    window["__telerikMobileAgent"].bridgeClient.MessageSend.on(function (data) {
         message = JSON.parse(data["data"])["data"];
    });

    window["__telerikMobileAgent"].handleMessage(msg);
    return message;
}

function __telerikMobileAgentSubscribe(query) {
    var msg = '{"fromId": "internal", "data": {"cmd": "ctrl.subscribe"}}';
    var message;
    window["__telerikMobileAgent"].Storage.setState(stateInfo);
    window["__telerikMobileAgent"].bridgeClient.MessageSend.on(function (data) {
         message = JSON.parse(data["data"])["data"];
    });
    window["__telerikMobileStateInfo"].nativeQuery = query;
    window["__telerikMobileAgent"].handleMessage(msg);
    window["__telerikMobileAgent"].Storage.setState(stateInfo);

    return message;
}
