//
//  WKWebViewController.h
//  DemoApplication
//
//  Created by Robert Shoemate on 10/1/15.
//  Copyright © 2015 Telerik. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SupportedOS.h"

@interface WKWebViewController : UIViewController <SupportedOS>

@end
