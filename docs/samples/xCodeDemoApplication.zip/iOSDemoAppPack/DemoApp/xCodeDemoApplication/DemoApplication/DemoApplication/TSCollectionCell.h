//
//  TSCollectionCell.h
//  DemoApplication
//
//  Created by David Rumley on 10/19/12.
//  Copyright (c) 2012 Telerik. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TSCollectionCell : UICollectionViewCell

@end
