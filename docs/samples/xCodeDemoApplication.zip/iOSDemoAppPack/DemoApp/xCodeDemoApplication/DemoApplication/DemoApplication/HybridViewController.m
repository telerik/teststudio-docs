//
//  HybridViewController
//  DemoApplication
//
//  Created by Bulent Karaahmed on 8/26/16.
//  Copyright 2016 Telerik. All rights reserved.
//

#import "HybridViewController.h"

@implementation HybridViewController
@synthesize ctlUIWebView = _ctlUIWebView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)dealloc
{
    [_ctlUIWebView release];
    [super dealloc];
}

#pragma mark - View lifecycle

-(void)viewDidAppear:(BOOL)animated{
    
    NSURL *url = [NSURL URLWithString:@"http://demos.telerik.com/mobile-testing/tacos/"];
    
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url];
    [self.ctlUIWebView loadRequest:urlRequest];
    [super viewDidAppear:animated];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Do any additional setup after loading the view from its nib.
    self.navigationItem.title = @"Hybrid View";
}

// TODO: Remove -viewDidUnload when we drop support for iOS 5
- (void)viewDidUnload
{
    [super viewDidUnload];
    
    // Release any retained subviews of the main view.
    self.ctlUIWebView = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

// TODO: Remove conditional compilation when we switch to Xcode 5
#ifdef __IPHONE_7_0
#if (__IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_7_0)
- (UIRectEdge)edgesForExtendedLayout {
    return UIRectEdgeNone;
}
#endif
#endif

#pragma mark -
#pragma mark Actions


@end
