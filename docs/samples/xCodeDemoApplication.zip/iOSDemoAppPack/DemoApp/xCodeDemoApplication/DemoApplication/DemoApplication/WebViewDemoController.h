//
//  WebViewDemoController.h
//  DemoApplication
//
//  Created by Robert Shoemate on 7/13/11.
//  Copyright 2011 Telerik. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface WebViewDemoController : UIViewController {

}
@property (nonatomic, retain) IBOutlet UIWebView *webView;

@end
