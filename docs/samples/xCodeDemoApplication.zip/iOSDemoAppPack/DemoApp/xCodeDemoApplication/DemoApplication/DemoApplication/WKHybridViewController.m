//
//  WKHybridViewController.m
//  DemoApplication
//
//  Created by Bulent Karaahmed on 8/26/16.
//  Copyright 2016 Telerik. All rights reserved.
//

#import "WKHybridViewController.h"


@implementation WKHybridViewController
//@synthesize containerView = _containerView;
@synthesize webView = _webView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)dealloc
{
    //[_containerView release];
    if (_webView) {
        [_webView release];
    }
    [super dealloc];
}

#pragma mark - View lifecycle

/*
- (void)loadView{
    
    WKWebViewConfiguration *configuration = [[WKWebViewConfiguration alloc] init];
    //    WKUserContentController *controller = [[WKUserContentController alloc] init];
    //    [controller addScriptMessageHandler:self name:@"observe"];
    //    configuration.userContentController = controller;
    _webView = [[WKWebView alloc] initWithFrame:CGRectZero
                                  configuration:configuration];
//    self.view = _webView;

}
*/
-(void)viewDidAppear:(BOOL)animated{

    NSURL *url = [NSURL URLWithString:@"http://demos.telerik.com/mobile-testing/tacos/"];
    [_webView loadRequest:[NSURLRequest requestWithURL:url]];
    [_webView setNavigationDelegate:self];
    [super viewDidAppear:animated];
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    WKWebViewConfiguration *configuration = [[WKWebViewConfiguration alloc] init];
    //    WKUserContentController *controller = [[WKUserContentController alloc] init];
    //    [controller addScriptMessageHandler:self name:@"observe"];
    //    configuration.userContentController = controller;
    _webView = [[WKWebView alloc] initWithFrame:CGRectZero
                                  configuration:configuration];
    
    CGRect rc = CGRectMake(0, 15, self.view.bounds.size.width, self.view.bounds.size.height - 70);
    [_webView setFrame:rc];
    [self.view addSubview:_webView];
   
    // Do any additional setup after loading the view from its nib.
    self.navigationItem.title = @"WebKit HybridView";
    [configuration release];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - WKNavgiationDelegate
/*
-(void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    NSLog(@"webView:decidePolicyForNavigationAction called");
}

-(void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler{
    NSLog(@"webView:decidePolicyForNavigatinoResponce called");
}
*/
#pragma mark - SupportedOS Implementation
- (BOOL)doesCurrentDeviceOSSupportController {
    if ([[[UIDevice currentDevice] systemVersion] compare:@"8.0" options:NSNumericSearch] != NSOrderedAscending)
        return YES;
    return NO;
}

+ (BOOL)shouldLoadNib {
    return YES;
}


#pragma mark -
#pragma mark Actions


@end
