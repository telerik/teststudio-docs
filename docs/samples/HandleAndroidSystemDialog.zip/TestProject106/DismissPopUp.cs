using System;
using Telerik.MobileTesting.Data;
using Telerik.MobileTesting.Runtime;
using Telerik.MobileTesting.Framework;
using System.Xml.Linq;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;

namespace TestProject106
{
    public class DismissPopUp
    {
		public static void DismissPopUpByName(string buttonName) {
			// Get all of the UI elements visible on the device screen using uiautomator and save them as .xml file in the working directory (c:/work in this case)
			//Check the getdump.cmd for more info
			string xmlDefault = @"C:\Work\test.xml";
			
			ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.CreateNoWindow = false;
            startInfo.UseShellExecute = false;
            startInfo.FileName = "CMD.exe";
            startInfo.Arguments = "CMD.exe" + " " + @"/C C:\Work\getdump.cmd";
			startInfo.WindowStyle = ProcessWindowStyle.Normal;
			startInfo.WorkingDirectory = @"C:\Work\";
            
			
           	Process.Start(startInfo);
			
			// Check if the xml dump exists
			int n = 0;
			while (!System.IO.File.Exists(xmlDefault) && n < 5000) {
				System.Threading.Thread.Sleep(1000);
				n++;
			}
			
			
			
			// This regex will search for the popup button by name - Aceptar in our case
			
			string findPopUpButtonRegex = String.Format(".*{0}.*?bounds=\"(.*?)\".*/>.*", buttonName);
			
			Regex parts = new Regex(findPopUpButtonRegex);
			
			// Load the .xml dump so that it can be parsed 
	
			var xml = System.Xml.Linq.XDocument.Load(xmlDefault);
			
			// Parsing the xml, what we need are the button coordinates and then the center point by xy of the button
			
			string xmlstring = xml.ToString();
			
			Match match = parts.Match(xmlstring);
			
			string result = match.ToString();
			
			int position1 = result.IndexOf("[");
			
			int position2 = result.IndexOf("]");
			
			int positionY1 = result.LastIndexOf("[");
			
			int positionY2 = result.LastIndexOf("]");
			
			string x = result.Substring(position1+1, position2-position1-1);
			
			string y = result.Substring(positionY1+1, positionY2-positionY1-1);
			
			Char coordinateDelimiter = ',';
			
			string[] xsubstrings = x.Split(coordinateDelimiter);
			
			string[] ysubstrings = y.Split(coordinateDelimiter);
			
			int boundsPoints1 = Int32.Parse(xsubstrings[0]) + Int32.Parse(ysubstrings[0]);
			
			int boundsPoints2 = Int32.Parse(xsubstrings[1]) + Int32.Parse(ysubstrings[1]);
			
			// Calculate the round center of the button so we can tap on it
			
			int centerCoordinateX = boundsPoints1/2;
			
			int centerCoordinateY = boundsPoints2/2;
			
			string[] coordinates = {centerCoordinateX.ToString(), centerCoordinateY.ToString()};
			
			// Execute the second .cmd file which will actually tap on the center of the button using the aquired coordinates
			
			System.Diagnostics.Process.Start("CMD.exe", String.Format(@"/C C:\Work\dismiss.cmd {0} {1}", coordinates));	
		}
	}
}