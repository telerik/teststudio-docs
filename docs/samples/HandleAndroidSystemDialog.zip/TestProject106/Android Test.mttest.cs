using System;
using TestProject106;
using Telerik.MobileTesting.Data;
using Telerik.MobileTesting.Runtime;
using Telerik.MobileTesting.Framework;

namespace TestProject106
{
	// It is mandatory for each test class to inherit AndroidTestBase class as shown below (this is set by default).
    public partial class Android_Test: AndroidTestBase
    {				
		public void TestMethod()
		{
			DismissPopUp.DismissPopUpByName("Aceptar");
			
			
			
		}
	}
}