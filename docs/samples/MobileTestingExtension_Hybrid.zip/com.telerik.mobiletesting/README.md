# com.telerik.mobiletesting

	This plugin provides support for hybrid apps in Telerik Test Studio Mobile. Note that this plugin should only be used
	in debug builds, and should NOT be deployed with production apps.

	This plugin is also available in the Telerik Platform. You can find more information
	at: http://docs.telerik.com/teststudio/test-studio-mobile/native-applications/configure-your-app/configure-appbuilder

## Installation

	cordova plugin add com.telerik.mobiletesting 

	For more information on configuring your app: http://docs.telerik.com/teststudio/test-studio-mobile/native-applications/configure-your-app/configure-hybrid

### Supported Platforms

- Android
- iOS