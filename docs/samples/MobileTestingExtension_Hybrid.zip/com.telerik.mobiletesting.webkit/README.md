# com.telerik.mobiletesting

	This plugin extends the Telerik Mobile Testing plugin to include support for the WKWebKit view.

	Note that this plugin should only be used in debug builds, and should NOT be deployed with production apps.

	Telerik Mobile Testing is available as part of the Telerik Platform. You can find more information at: http://platform.telerik.com

## Installation

	cordova plugin add com.telerik.mobiletesting.webkit

	For more information on configuring your app: http://docs.telerik.com/platform/mobile-testing-overview

### Supported Platforms

- iOS
