package com.telerik.demoapplication;

import android.view.KeyEvent;

public interface KeyHandling {

    void onKeyDown(int keyCode, KeyEvent event);

}
