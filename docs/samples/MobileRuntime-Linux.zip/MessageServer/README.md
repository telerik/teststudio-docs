TelerikTesting tmtest
=====================

Overview
--------
Telerik Mobile Testing CLI tool.