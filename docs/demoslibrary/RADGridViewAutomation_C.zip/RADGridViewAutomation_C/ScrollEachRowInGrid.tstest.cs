using Telerik.TestingFramework.Controls.KendoUI;
using Telerik.WebAii.Controls.Html;
using Telerik.WebAii.Controls.Xaml;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

using ArtOfTest.Common.UnitTesting;
using ArtOfTest.WebAii.Core;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Controls.HtmlControls.HtmlAsserts;
using ArtOfTest.WebAii.Design;
using ArtOfTest.WebAii.Design.Execution;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Silverlight;
using ArtOfTest.WebAii.Silverlight.UI;

namespace RADGridViewAutomation_C
{

    public class ScrollEachRowInGrid : BaseWebAiiTest
    {
        #region [ Dynamic Pages Reference ]

        private Pages _pages;

        /// <summary>
        /// Gets the Pages object that has references
        /// to all the elements, frames or regions
        /// in this project.
        /// </summary>
        public Pages Pages
        {
            get
            {
                if (_pages == null)
                {
                    _pages = new Pages(Manager.Current);
                }
                return _pages;
            }
        }

        #endregion
        
        // Add your test methods here...
    
        [CodedStep(@"New Coded Step")]
        public void WebTest_CodedStep1()
        {
                    
                    SilverlightApp app = ActiveBrowser.SilverlightApps()[0]; //Get Silverlight app 
                        
                    int verticalOffset = 0; // Holds the current vertical offset in the viewport
                    int viewPortHeight; // The height of the visible part of the grid
                    int extentHeight; // The total height of the grid, visible plus non-visible
            
                    // Copy the RadGridView into a local variable as a shortcut
                    Telerik.WebAii.Controls.Xaml.RadGridView grid = app.Find.ByType<Telerik.WebAii.Controls.Xaml.RadGridView>(); //Get RadGrid
                    // Grab the VirtualizingPanel contained in the RadGridView. This is used to control the viewable portion of the grid.
                    FrameworkElement VirtualizingPanel = grid.Find.ByType("GridViewVirtualizingPanel");
            
                    // Detect the view port height and the extent height
                    viewPortHeight = (int)VirtualizingPanel.GetProperty(new AutomationProperty("ViewportHeight", typeof(int)));
                    extentHeight = (int)VirtualizingPanel.GetProperty(new AutomationProperty("ExtentHeight", typeof(int)));
            
                    Dictionary<string, int> rowsHash = new Dictionary<string, int>();
                    // Make sure it is scrolled to the very top
                    // Walk through the entire grid verifying the data
                    VirtualizingPanel.InvokeMethod("SetVerticalOffset", 0);
                    int rowNum = 0;
                    while (verticalOffset < extentHeight)
                        {
                        grid.Refresh();
                        foreach (GridViewRow r in grid.Rows)
                            {
                            string rowId = r.Cells[0].Text;
                            if (!rowsHash.Keys.Contains(rowId))
                                {
                                rowsHash.Add(rowId, rowNum++);
                                Log.WriteLine("<-------------Start of row identified by "+rowId.ToString()+"------------->");
                                
                                int cellCounter = 1;  
                                foreach(Telerik.WebAii.Controls.Xaml.GridViewCell gCell in r.Cells) { //Nested loop; Goes through all the cells within each row

                                    Log.WriteLine("Cell "+ cellCounter.ToString()+": "+gCell.Text);   //We output the cell text to the log; 
                                    //You can implement any type of verification you like against the text here

                                    cellCounter++;
                                    }
                                }
                            }
                        // Scroll down one page
                        verticalOffset += viewPortHeight;
                        VirtualizingPanel.InvokeMethod("SetVerticalOffset", verticalOffset);
                        }   
        }
    }
}
