using Telerik.TestingFramework.Controls.KendoUI;
using Telerik.WebAii.Controls.Html;
using Telerik.WebAii.Controls.Xaml;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

using ArtOfTest.Common.UnitTesting;
using ArtOfTest.WebAii.Core;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Controls.HtmlControls.HtmlAsserts;
using ArtOfTest.WebAii.Design;
using ArtOfTest.WebAii.Design.Execution;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Silverlight;
using ArtOfTest.WebAii.Silverlight.UI;

namespace RADGridViewAutomation_C
{

    public class WebTest : BaseWebAiiTest
    {
        #region [ Dynamic Pages Reference ]

        private Pages _pages;

        /// <summary>
        /// Gets the Pages object that has references
        /// to all the elements, frames or regions
        /// in this project.
        /// </summary>
        public Pages Pages
        {
            get
            {
                if (_pages == null)
                {
                    _pages = new Pages(Manager.Current);
                }
                return _pages;
            }
        }

        #endregion
        
        // Add your test methods here...
    
        [CodedStep(@"New Coded Step")]
        public void WebTest_CodedStep()
        {
        
        SilverlightApp app = ActiveBrowser.SilverlightApps()[0]; //Get Silverlight app              

        Telerik.WebAii.Controls.Xaml.RadGridView rgv = app.Find.ByType<Telerik.WebAii.Controls.Xaml.RadGridView>(); //Get RadGrid
        int rowCounter = 1;

        foreach (Telerik.WebAii.Controls.Xaml.GridViewRow gRow in rgv.Rows) { //Loop to go through all the rows

            Log.WriteLine("<-------------Start of row "+rowCounter.ToString()+"------------->"); //Write row number to log

            int cellCounter = 1;  
            foreach(Telerik.WebAii.Controls.Xaml.GridViewCell gCell in gRow.Cells) { //Nested loop; Goes through all the cells within each row

                Log.WriteLine("Cell "+ cellCounter.ToString()+": "+gCell.Text);   //We output the cell text to the log; 
                //You can implement any type of verification you like against the text here

                cellCounter++;
                }
            rowCounter++;
            }    
        }
    }
}
