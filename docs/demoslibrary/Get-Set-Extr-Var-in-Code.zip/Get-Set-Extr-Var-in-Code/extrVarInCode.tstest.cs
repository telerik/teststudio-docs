using Telerik.TestStudio.Translators.Common;
using Telerik.TestingFramework.Controls.TelerikUI.Blazor;
using Telerik.TestingFramework.Controls.KendoUI.Angular;
using Telerik.TestingFramework.Controls.KendoUI;
using Telerik.WebAii.Controls.Html;
using Telerik.WebAii.Controls.Xaml;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

using ArtOfTest.Common.UnitTesting;
using ArtOfTest.WebAii.Core;
using ArtOfTest.WebAii.Controls.HtmlControls;
using ArtOfTest.WebAii.Controls.HtmlControls.HtmlAsserts;
using ArtOfTest.WebAii.Design;
using ArtOfTest.WebAii.Design.Execution;
using ArtOfTest.WebAii.ObjectModel;
using ArtOfTest.WebAii.Silverlight;
using ArtOfTest.WebAii.Silverlight.UI;

namespace Get_Set_Extr_Var_in_Code
{

    public class extrVarInCode : BaseWebAiiTest
    {
        #region [ Dynamic Pages Reference ]

        private Pages _pages;

        /// <summary>
        /// Gets the Pages object that has references
        /// to all the elements, frames or regions
        /// in this project.
        /// </summary>
        public Pages Pages
        {
            get
            {
                if (_pages == null)
                {
                    _pages = new Pages(Manager.Current);
                }
                return _pages;
            }
        }

        #endregion
        
        // Add your test methods here...
    
        [CodedStep(@"New Coded Step")]
        public void extrVarInCode_ModifyTextContent()
        {
            // Assign the value of the extracted variable 'DevCraftPTag' to a variable to use in the code 
            var extrValueInCode = GetExtractedValue("DevCraftPTag");
            // Ensure the value is what you expect it - you can use this while debugging the script, but it is not mandatory
            // Output the value in the execution log for debugging purposes
            Log.WriteLine("This is the value of the Extracted variable 'DevCraftPTag' from the Extracteion step: " + extrValueInCode.ToString());
            
            // Insert the necessary custom code to modify the exctracted value
            
            // This example project will take a substring of the initial extracted string
            // Then, the substring will be assigned back to an extracted variable in order to use it in the UI test steps
            
            // Take the substring you need - in this example I will get the 'Kendo UI' substring with the help of the .Net Substring() method
            string newSubstr = extrValueInCode.ToString().Substring(39, 8);
            // Ensure the substring is what you expect it - you can use this while debugging the script, but it is not mandatory
            // Output the value in the execution log for debugging purposes
            Log.WriteLine("This is the modified string: " + newSubstr);
            
            // Assign the substring back to the extracted variable - you can either use the same, or create a new one.
            // I will use a new one in this example for better visibility 
            SetExtractedValue("ModifiedExtrVariable", newSubstr);
            
            // This is another cross check, which can be used while debugging the code, it is also not mandatory
            // Output the value of the new extracted variable in the execution log for debugging purposes
            var check = GetExtractedValue("ModifiedExtrVariable");
            Log.WriteLine("This is the last cross check to verify the new extracted variable has the correct value assigned: " + check.ToString());
        }
    }
}
