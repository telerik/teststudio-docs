var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Foreground;
        (function (Foreground) {
            var AjaxInterceptor;
            (function (AjaxInterceptor) {
                function listenForAjax(frame) {
                    const httpRequests = new Array();
                    frame.XMLHttpRequest.prototype.realSend = frame.XMLHttpRequest.prototype.send;
                    frame.XMLHttpRequest.prototype.send = function (value) {
                        this.addEventListener("loadstart", function () {
                            httpRequests.push(this);
                            window.top.TS_Active_Ajax_Count++;
                        }, false);
                        this.addEventListener("progress", function () {
                            const index = httpRequests.indexOf(this);
                            if (index === -1) {
                                httpRequests.push(this);
                                window.top.TS_Active_Ajax_Count++;
                            }
                        }, false);
                        this.addEventListener("loadend", function () {
                            if (httpRequests.length > 0) {
                                const index = httpRequests.indexOf(this);
                                if (index > -1) {
                                    httpRequests.splice(index, 1);
                                    window.top.TS_Active_Ajax_Count--;
                                }
                            }
                        }, false);
                        this.realSend(value);
                    };
                }
                AjaxInterceptor.listenForAjax = listenForAjax;
            })(AjaxInterceptor = Foreground.AjaxInterceptor || (Foreground.AjaxInterceptor = {}));
        })(Foreground = TestStudio.Foreground || (TestStudio.Foreground = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
if (window.top.TS_Active_Ajax_Count === undefined) {
    window.top.TS_Active_Ajax_Count = 0;
    Telerik.TestStudio.Foreground.AjaxInterceptor.listenForAjax(window.top);
}
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Foreground;
        (function (Foreground) {
            var ConsoleInterceptor;
            (function (ConsoleInterceptor) {
                function overrideConsoleErrorFunction(frame) {
                    const oldConsoleError = frame.console.error;
                    frame.console.error = function () {
                        logError(arguments[0], arguments[1]);
                        oldConsoleError.apply(frame.console, arguments);
                    };
                }
                function overrideConsoleExceptionFunction(frame) {
                    const oldConsoleException = frame.console.exception;
                    frame.console.exception = function () {
                        logError(arguments[0], arguments[1]);
                        oldConsoleException.apply(frame.console, arguments);
                    };
                }
                function parseKey(key) {
                    if (Object.prototype.toString.call(key) === "[object String]") {
                        return key;
                    }
                    if (key instanceof Error || key.message != null) {
                        return key.message;
                    }
                    try {
                        return JSON.stringify(key);
                    }
                    catch (ex) {
                        return key;
                    }
                }
                function logError(err, extra) {
                    if (err != null) {
                        let key = parseKey(err);
                        if (extra != null) {
                            key = key + " " + parseKey(extra);
                        }
                        if (window.top.TS_JS_Console_Errors[key]) {
                            window.top.TS_JS_Console_Errors[key] += 1;
                        }
                        else {
                            window.top.TS_JS_Console_Errors[key] = 1;
                        }
                    }
                }
                function overrideConsoleFunctions(frame) {
                    if (frame.console.exception != null) {
                        overrideConsoleExceptionFunction(frame);
                    }
                    if (frame.console.error != null) {
                        overrideConsoleErrorFunction(frame);
                    }
                    frame.addEventListener("error", (ev) => {
                        logError(ev, null);
                    });
                }
                ConsoleInterceptor.overrideConsoleFunctions = overrideConsoleFunctions;
            })(ConsoleInterceptor = Foreground.ConsoleInterceptor || (Foreground.ConsoleInterceptor = {}));
        })(Foreground = TestStudio.Foreground || (TestStudio.Foreground = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
if (window.top.TS_JS_Console_Errors === undefined) {
    window.top.TS_JS_Console_Errors = {};
    Telerik.TestStudio.Foreground.ConsoleInterceptor.overrideConsoleFunctions(window.top);
}
