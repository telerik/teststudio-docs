function save_options() {
    var settings = document.getElementsByClassName('settings');
    var state = {};
    for (var i = 0; i < settings.length; i++) {
        if (settings[i].tagName.toLocaleLowerCase() == "input") {
            if (settings[i].type == "checkbox") {
                state[settings[i].id] = settings[i].checked;
            } else {
                state[settings[i].id] = settings[i].value;
            }
        }
    }

    chrome.storage.sync.set(state, function () {
        var status = document.getElementById('status');
        status.textContent = 'Options saved.';
        setTimeout(function () {
            status.textContent = '';
        }, 750);
    });
}

function restore_defaults() {
    var settings = document.getElementsByClassName('settings');
    var state = {};
    for (var i = 0; i < settings.length; i++) {
        var defaultValue = settings[i].getAttribute("data-default-value");
        if (defaultValue && settings[i].tagName.toLocaleLowerCase() == "input") {
            if (settings[i].type == "checkbox") {
                settings[i].checked = defaultValue == "true";
            } else {
                settings[i] = defaultValue;
            }
        }
    }

    var status = document.getElementById('status');
    status.textContent = 'Options restored to their default values.';
    setTimeout(function () {
        status.textContent = '';
    }, 750);
}

function restore_options() {
    chrome.storage.sync.get(function (items) {
        for (var key in items) {
            if (items.hasOwnProperty(key) && document.getElementById(key) != null) {
                let element = document.getElementById(key);
                if (element.tagName.toLocaleLowerCase() == "input") {
                    if (element.type == "checkbox") {
                        element.checked = items[key];
                    } else {
                        element.value = items[key];
                    }
                }
            }
        }
    });
}

document.addEventListener('DOMContentLoaded', restore_options);
document.getElementById('save-button').addEventListener('click', save_options);
document.getElementById('restore-defaults-button').addEventListener('click', restore_defaults);
