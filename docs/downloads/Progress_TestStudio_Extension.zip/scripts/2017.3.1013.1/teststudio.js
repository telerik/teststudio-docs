var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class ActionPoint {
                constructor(x, y) {
                    this.x = x;
                    this.y = y;
                }
                getX() {
                    return this.x;
                }
                setX(value) {
                    this.x = value;
                }
                getY() {
                    return this.y;
                }
                setY(value) {
                    this.y = value;
                }
            }
            Recorder.ActionPoint = ActionPoint;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class AutomationDescriptor {
                constructor(type, values, friendlyName, elementType) {
                    this.type = type;
                    this.values = values;
                    this.friendlyName = friendlyName;
                    this.elementType = elementType;
                }
                getType() {
                    return this.type;
                }
                setType(value) {
                    this.type = value;
                }
                getValues() {
                    return this.values;
                }
                setValues(value) {
                    this.values = value;
                }
                getFriendlyName() {
                    return this.friendlyName;
                }
                setFriendlyName(value) {
                    this.friendlyName = value;
                }
                getElementType() {
                    return this.elementType;
                }
                setElementType(value) {
                    this.elementType = value;
                }
            }
            Recorder.AutomationDescriptor = AutomationDescriptor;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class CapturedCommand {
                constructor() {
                    this.action = "";
                }
                getAction() {
                    return this.action;
                }
                setAction(value) {
                    this.action = value;
                }
                getData() {
                    return this.data;
                }
                setData(value) {
                    this.data = value;
                }
                getTarget() {
                    return this.target;
                }
                setTarget(value) {
                    this.target = value;
                }
                getExpression() {
                    return this.expression;
                }
                setExpression(value) {
                    this.expression = value;
                }
            }
            Recorder.CapturedCommand = CapturedCommand;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class FindExpression {
                constructor() {
                    this.chainStop = -1;
                    this.clauses = new Array();
                }
                addClause(clause) {
                    let newIndex = this.clauses.length;
                    this.clauses[newIndex] = clause;
                }
                matchElement(target) {
                    for (let i = 0; i < this.clauses.length; i++) {
                        if (this.clauses[i].match(target) == false) {
                            return false;
                        }
                    }
                    return true;
                }
                getClauses() {
                    let result = new Array();
                    for (let i = 0; i < this.clauses.length; i++) {
                        if (this.clauses[i].getType() == 3) {
                            result[result.length] = this.clauses[i].getName() + ":" + this.clauses[i].getValue();
                        }
                        else {
                            result[result.length] = this.clauses[i].getName() + "=" + this.clauses[i].getValue();
                        }
                    }
                    return result;
                }
                getGhainStop() {
                    return this.chainStop;
                }
                setChainStop(value) {
                    this.chainStop = value;
                }
            }
            Recorder.FindExpression = FindExpression;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            var Findxs;
            (function (Findxs) {
                let MAX_TEXTCONTENT_FIND;
                let STARTS_WITH;
                let TAG_NAMES = ["textarea", "script", "div", "table", "style",
                    "a", "img", "frameset", "frame", "iframe",
                    "map", "select", "input", "link", "th",
                    "td", "col", "tr", "span", "li",
                    "ol", "ul", "testregion", "video", "audio",
                    "source"];
                let INPUT_ELEMENTS_NAMES = ["button", "checkbox", "file", "hidden", "image",
                    "password", "radio", "reset", "submit", "text",
                    "email	", "url	", "number", "range", "search"];
                let data = "{\"UseHttpProxy\":false,\"RecordjQueryInDescriptorsIfPossible\":true,\"ShouldDeleteElement\":false,\"SkipDeleteElementPrompt\""
                    + ":false,\"HideFindExpressionWelcome\":false,\"MenuHoldTime\":1.0,\"SilverlightConnectTimeout\":30000,\"BaseClassName\":\"BaseWebAiiTest\","
                    + "\"UrlRecordMode\":2,\"HighlightBorderColor\":-65536,\"HighlightBorderSize\":1,\"CodeGenerationElementIdentificationType\":1,"
                    + "\"UrlHistory\":[],\"AbsoluteDragDropRecording\":true,\"ImageScalePercentage\":75,\"SelectedIdentificaitonScheme\":\"Html\","
                    + "\"IdentificationSchemes\":{\"Html\":{\"CheckFindParamUniqueness\":true,\"AutoDetectTestRegions\":true,\"TryAttributeCombinations\":true,"
                    + "\"AlwaysAssertTagName\":true,\"IdentificationsPerTag\":{\"All Elements\":[{\"IsLocked\":false,\"SearchType\":0,\"AttributeName\":\"id\"},"
                    + "{\"IsLocked\":false,\"SearchType\":0,\"AttributeName\":\"name\"},{\"IsLocked\":false,\"SearchType\":0,\"AttributeName\":\"src\"},"
                    + "{\"IsLocked\":false,\"SearchType\":0,\"AttributeName\":\"href\"},{\"IsLocked\":false,\"SearchType\":0,\"AttributeName\":\"value\"},"
                    + "{\"IsLocked\":false,\"SearchType\":0,\"AttributeName\":\"alt\"},{\"IsLocked\":true,\"SearchType\":1,\"AttributeName\":null},"
                    + "{\"IsLocked\":true,\"SearchType\":8,\"AttributeName\":null}]},\"TechnologyType\":1},\"Silverlight\":"
                    + "{\"CheckFindParamUniqueness\":true,\"AutoDetectTestRegions\":true,\"TryAttributeCombinations\":true,"
                    + "\"AlwaysAssertTagName\":true,\"IdentificationsPerTag\":{\"All Elements\":[{\"IsLocked\":false,\"SearchType\":0,\"AttributeName\":null},"
                    + "{\"IsLocked\":false,\"SearchType\":5,\"AttributeName\":null},{\"IsLocked\":false,\"SearchType\":1,\"AttributeName\":null},"
                    + "{\"IsLocked\":true,\"SearchType\":6,\"AttributeName\":null}]},\"TechnologyType\":2}},\"UnitTypeTypeGeneration\":1,\"DebugMode\":false,"
                    + "\"RecorderBaseUrl\":\"\",\"IsStoryBoardCapturingEnabled\":true,\"SimulateRealClickByDefault\":false,\"SimulateRealTypingByDefault\":false,"
                    + "\"SimulateRealSilverlightUserByDefault\":true,\"DefaultDropDownSelection\":1,\"QuickExecutionElementWaitTimeout\":10000,"
                    + "\"QuickExecutionClientReadyTimeout\":30000,\"QcServerUrl\":null,\"QcUserName\":null,\"QcPassword\":null,\"QcSkipAuthDialog\":false,"
                    + "\"QcDomain\":null,\"QcProject\":null,\"TfsUserName\":null,\"TfsPassword\":null,\"TfsSkipAuthDialog\":true,\"TfsDomain\":null,"
                    + "\"TeamPulseServerUrl\":\"\",\"TpUserName\":null,\"TpPassword\":null,\"TpUseWindowsAuth\":false,\"TpSkipAuthDialog\":false,"
                    + "\"RecordWpfWindowStateChanged\":false,\"PromptNameOnAddElement\":true,\"DefaultWPFApplication\":null,"
                    + "\"UseLegacySilverlightFindLogic\":false,\"BugTitleMask\":\"{Step name} step on {Test name} test failed.\","
                    + "\"BugAddAttachment\":true,\"BugAutoSubmit\":false,\"BugDescriptionMask\":\"{Description}\"}";
                function getStartsWith() {
                    return STARTS_WITH;
                }
                Findxs.getStartsWith = getStartsWith;
                function getMaxTextContentFind() {
                    return MAX_TEXTCONTENT_FIND;
                }
                Findxs.getMaxTextContentFind = getMaxTextContentFind;
                function buildExpression(target) {
                    return buildFindExpression(target);
                }
                Findxs.buildExpression = buildExpression;
                function getRoot(who) {
                    while (who.location == undefined) {
                        who = who.parentNode;
                    }
                    return who;
                }
                function indexOfSpecial(value, startIndex) {
                    for (let i = startIndex; i < value.length; i++) {
                        if (value[i] === " " || value[i] === "_" || value[i] === "." || value[i] === "," ||
                            value[i] === "?" || value[i] === "!" || value[i] === ";" || value[i] === "-" || value[i] === "|") {
                            return i;
                        }
                    }
                    return -1;
                }
                function smartTrim(value, maxLength) {
                    if (value.length <= maxLength) {
                        return value;
                    }
                    let splitLocation = 0;
                    let lastValidLocation = 0;
                    while (splitLocation !== -1 && splitLocation < maxLength - 1) {
                        lastValidLocation = splitLocation;
                        if (splitLocation === 0) {
                            splitLocation = indexOfSpecial(value, 1);
                        }
                        else {
                            splitLocation = indexOfSpecial(value, splitLocation + 1);
                        }
                    }
                    if (lastValidLocation > 0 && lastValidLocation < maxLength) {
                        return value.substring(0, lastValidLocation);
                    }
                    else {
                        return value.substr(0, maxLength);
                    }
                }
                function tryGetFileNameFromPath(path) {
                    try {
                        let fileNameIndex = path.lastIndexOf("/") + 1;
                        let filename = path.substr(fileNameIndex);
                        return filename;
                    }
                    catch (err) {
                        return "";
                    }
                }
                function generateFriendlyName(target) {
                    let stringBuilder = "";
                    if (!isEmptyOrNull(target.id)) {
                        stringBuilder = stringBuilder + target.id;
                    }
                    else if (!isEmptyOrNull(target.name)) {
                        stringBuilder = stringBuilder + target.name;
                    }
                    else if (!isEmptyOrNull(target.alt)) {
                        stringBuilder = stringBuilder + smartTrim(target.alt, MAX_TEXTCONTENT_FIND);
                    }
                    else if (!isEmptyOrNull(target.uniqueName)) {
                        stringBuilder = stringBuilder + target.uniqueName;
                    }
                    else if (!isEmptyOrNull(target.title)) {
                        stringBuilder = stringBuilder + smartTrim(target.title, MAX_TEXTCONTENT_FIND);
                    }
                    else if (!isEmptyOrNull(target.textContent)) {
                        let content = getElementTextContent(target);
                        if (content.length > MAX_TEXTCONTENT_FIND) {
                            content = smartTrim(content, MAX_TEXTCONTENT_FIND);
                        }
                        stringBuilder = stringBuilder + content;
                    }
                    else if (target.src && tryGetFileNameFromPath(target.src) !== "") {
                        stringBuilder = stringBuilder + tryGetFileNameFromPath(target.src);
                    }
                    else if (target.href && tryGetFileNameFromPath(target.href) !== "") {
                        stringBuilder = stringBuilder + tryGetFileNameFromPath(target.href);
                    }
                    stringBuilder = stringBuilder + " ";
                    if (knownElementType(target)) {
                        if (target.tagName.toLowerCase() === "a") {
                            stringBuilder = stringBuilder + "Link";
                        }
                        else if (target.tagName.toLowerCase() === "input") {
                            stringBuilder = stringBuilder + getInputType(target);
                        }
                        else {
                            stringBuilder = stringBuilder + getTypeName(target);
                        }
                    }
                    else {
                        stringBuilder = stringBuilder + target.tagName;
                        stringBuilder = stringBuilder + "Tag";
                    }
                    let aspRegEx = new RegExp("ctl[0-9]+", "i");
                    while (aspRegEx.test(stringBuilder)) {
                        let rtext = aspRegEx.exec(stringBuilder)[0];
                        stringBuilder = stringBuilder.replace(rtext, "");
                    }
                    return sanitizeString(stringBuilder);
                }
                function capitalizeFirstLetter(value) {
                    return value.charAt(0).toUpperCase() + value.slice(1);
                }
                function getInputType(target) {
                    let type = target.type.toLowerCase();
                    if (INPUT_ELEMENTS_NAMES.indexOf(type) > -1) {
                        return capitalizeFirstLetter(type);
                    }
                    return "NotSet";
                }
                function getTypeName(target) {
                    if (!target.tagName) {
                        return "Other";
                    }
                    let tagName = target.tagName.toLowerCase();
                    switch (tagName) {
                        case "textarea":
                            return "TextArea";
                        case "style":
                            return "CascadingStyleSheet";
                        case "a":
                            return "Anchor";
                        case "img":
                            return "Image";
                        case "frameset":
                            return "FrameSet";
                        case "iframe":
                            return "IFrame";
                        case "th":
                            return "TableHeader";
                        case "td":
                            return "TableCell";
                        case "col":
                            return "TableColumn";
                        case "tr":
                            return "TableRow";
                        case "li":
                            return "ListItem";
                        case "ol":
                            return "OrderedList";
                        case "ul":
                            return "UnorderedList";
                        case "testregion":
                            return "TestRegion";
                        default:
                            if (INPUT_ELEMENTS_NAMES.indexOf(tagName) > -1) {
                                return capitalizeFirstLetter(tagName);
                            }
                            return "Other";
                    }
                }
                function knownElementType(target) {
                    if (!target.tagName) {
                        return false;
                    }
                    let tagName = target.tagName.toLowerCase();
                    if (TAG_NAMES.indexOf(tagName) > -1) {
                        return true;
                    }
                    return false;
                }
                function trim(value) {
                    let startIndex = 0;
                    let endIndex = value.length - 1;
                    for (let i = 0; i < value.length; i++) {
                        startIndex = i;
                        if (value[i] !== " ") {
                            break;
                        }
                    }
                    for (let j = value.length - 1; j >= 0; j--) {
                        endIndex = j;
                        if (value[j] !== " ") {
                            break;
                        }
                    }
                    return value.substring(startIndex, endIndex + 1);
                }
                function containsLetter(value) {
                    return /^.*[A-Z].*/i.test(value);
                }
                function containsDigit(value) {
                    return /^.*[0-9].*/i.test(value);
                }
                function containsNonAsciiLetter(value) {
                    return /^.*[^\x00-\x80].*/i.test(value);
                }
                function sanitizeString(value) {
                    let newValue = trim(value);
                    let sb = "";
                    let nextCharShouldBeCaps = true;
                    let firstSpace = -1;
                    let count = newValue.length;
                    for (let idx = 0; idx < count; idx++) {
                        let charLetter = newValue[idx];
                        if (charLetter === " ") {
                            firstSpace = idx;
                        }
                        if (!containsDigit(charLetter) && !containsLetter(charLetter) && !containsNonAsciiLetter(charLetter)) {
                            nextCharShouldBeCaps = true;
                            continue;
                        }
                        else {
                            if (nextCharShouldBeCaps) {
                                sb += charLetter.toUpperCase();
                                nextCharShouldBeCaps = false;
                            }
                            else {
                                sb += charLetter;
                            }
                        }
                    }
                    if (sb.length > 0 && !isNaN(parseInt(sb[0], 10))) {
                        sb = "x" + sb;
                    }
                    return sb;
                }
                function buildFriendlyName(target) {
                    if (target.tagName == undefined) {
                        return "";
                    }
                    return generateFriendlyName(target);
                }
                Findxs.buildFriendlyName = buildFriendlyName;
                function isEmptyOrNull(item) {
                    return item == null || item === "" || item == undefined;
                }
                function buildFindExpression(target) {
                    let uc = JSON.parse(data);
                    let expr = null;
                    let isTagIndex = false;
                    let isXPath = false;
                    let idList;
                    let scheme = uc.IdentificationSchemes.Html;
                    if (scheme.IdentificationsPerTag[target.tagName] != undefined) {
                        idList = scheme.IdentificationsPerTag[target.tagName];
                    }
                    else {
                        idList = scheme.IdentificationsPerTag["All Elements"];
                    }
                    for (let i = 0; i < idList.length; i++) {
                        let identificationTag = idList[i];
                        switch (identificationTag.SearchType) {
                            case 0:
                                if (identificationTag.AttributeName.toLowerCase() === "value" &&
                                    target.tagName.toLowerCase() === "input" &&
                                    target.type.toLowerCase() === "text") {
                                    break;
                                }
                                if (identificationTag.AttributeName.toLowerCase() === "xpath") {
                                    isXPath = true;
                                    expr = getExpression(new Recorder.Clauses(identificationTag.AttributeName, generateXPath(target), "xpath", 3));
                                    break;
                                }
                                if (identificationTag.AttributeName.toLowerCase() === "href" && target.hasAttribute("href")) {
                                    let href = target.attributes["href"].nodeValue.toString();
                                    href = replaceAmp(href);
                                    let attributeValue = href;
                                    if (attributeValue.toLowerCase().indexOf("javascript") === 0 || isPotentialDynamicUrl(attributeValue)) {
                                        break;
                                    }
                                    let attrName = identificationTag.AttributeName;
                                    expr = getExpression(new Recorder.Clauses(attrName, attributeValue, attrName, 0));
                                }
                                if (target.attributes != undefined && target.attributes[identificationTag.AttributeName]) {
                                    let value = target.attributes[identificationTag.AttributeName].value;
                                    if (identificationTag.AttributeName.toLowerCase() === "id"
                                        || identificationTag.AttributeName.toLowerCase() === "name") {
                                        value = replaceAmp(value);
                                    }
                                    expr = getExpression(new Recorder.Clauses(identificationTag.AttributeName, value, identificationTag.AttributeName, 0));
                                }
                                break;
                            case 1:
                                if (target.tagName.toLowerCase() === "textarea") {
                                    break;
                                }
                                if (target.contentEditable === "true") {
                                    break;
                                }
                                let contentToUse = getElementTextContent(target);
                                if (target.textContent && contentToUse !== "") {
                                    if (contentToUse.length > MAX_TEXTCONTENT_FIND) {
                                        contentToUse = STARTS_WITH + contentToUse.substr(0, MAX_TEXTCONTENT_FIND);
                                    }
                                    expr = getExpression(new Recorder.Clauses("TextContent", contentToUse, "textContent", 1));
                                }
                                break;
                            case 8:
                                expr = getExpression(new Recorder.Clauses("TagIndex", target.tagName.toLowerCase() + ":"
                                    + buildIndexAccordingToParentBasedTree(target.ownerDocument, target).toString(), "tagIndex", 2));
                                isTagIndex = true;
                                break;
                            default:
                                break;
                        }
                        if (scheme.CheckFindParamUniqueness && !isTagIndex && !isXPath) {
                            if (expr != null) {
                                expr.addClause(new Recorder.Clauses("tagname", target.tagName.toLowerCase(), "tagName", 4));
                                if (checkForUniqueness(expr, target.ownerDocument) === 1) {
                                    break;
                                }
                            }
                        }
                        else {
                            break;
                        }
                    }
                    if (isTagIndex && scheme.TryAttributeCombinations) {
                        let expr2 = null;
                        expr2 = buildChainedExpression(target, idList);
                        if (expr2 != null) {
                            expr = expr2;
                        }
                    }
                    return { clauses: expr.getClauses(), chainStop: expr.chainStop };
                }
                function getExpression(clause) {
                    let expr = new Recorder.FindExpression();
                    expr.addClause(clause);
                    return expr;
                }
                function buildChainedExpression(e, idList) {
                    let neighbor = getClosestNeighbourWithIdOrName(e, idList);
                    if (neighbor != null) {
                        let myEasyToFindParent = neighbor.first;
                        let attrType = neighbor.second;
                        let index = buildIndexAccordingToParentBasedTree(myEasyToFindParent, e);
                        if (index >= 0) {
                            let expr = new Recorder.FindExpression();
                            if (attrType === "name") {
                                expr.addClause(new Recorder.Clauses(attrType, myEasyToFindParent.attributes[attrType].value, attrType, 0));
                            }
                            else {
                                expr.addClause(new Recorder.Clauses(attrType, myEasyToFindParent[attrType], attrType, 0));
                            }
                            expr.addClause(new Recorder.Clauses("TagIndex", e.tagName.toLowerCase() + ":" + index.toString(), "tagIndex", 2));
                            expr.setChainStop(1);
                            return expr;
                        }
                    }
                    return null;
                }
                function isPotentialDynamicUrl(url) {
                    return url.indexOf(";") > -1 && url.indexOf("?") > -1 && url.indexOf("%") > -1 && url.indexOf("=") > -1;
                }
                function getClosestNeighbourWithIdOrName(target, idList) {
                    let temp = target.parentNode;
                    let attrName;
                    while (temp != null) {
                        for (let k = 0; k < idList.length; k++) {
                            if (idList[k].SearchType != 0) {
                                continue;
                            }
                            let expr = new Recorder.FindExpression();
                            if (idList[k].AttributeName.toLowerCase() === "id" && temp.id != undefined) {
                                expr.addClause(new Recorder.Clauses("id", temp.id, "id", 0));
                                if (checkForUniqueness(expr, temp.ownerDocument) === 1) {
                                    attrName = "id";
                                    return { first: temp, second: attrName };
                                }
                            }
                            if (idList[k].AttributeName.toLowerCase() === "name" && temp.attributes && temp.getAttribute("name")) {
                                expr.addClause(new Recorder.Clauses("name", temp.getAttribute("name").toString().toLowerCase(), "name", 0));
                                if (checkForUniqueness(expr, temp.ownerDocument) === 1) {
                                    attrName = "name";
                                    return { first: temp, second: attrName };
                                }
                            }
                        }
                        temp = temp.parentNode;
                    }
                    return null;
                }
                function checkForUniqueness(expr, node) {
                    let matchedElements = 0;
                    let nodesCount = node.childNodes.length;
                    for (let i = 0; i < nodesCount; i++) {
                        if (node.childNodes[i].nodeType !== 1) {
                            continue;
                        }
                        if (expr.matchElement(node.childNodes[i])) {
                            matchedElements = matchedElements + 1;
                        }
                        matchedElements = matchedElements + checkForUniqueness(expr, node.childNodes[i]);
                    }
                    return matchedElements;
                }
                function buildIndexAccordingToParent(target) {
                    if (target && target.parentNode) {
                        try {
                            let length = target.parentNode.children.length;
                            for (let i = 0; i < length; i++) {
                                if (target == target.parentNode.children[i]) {
                                    return i;
                                }
                            }
                        }
                        catch (err) {
                            return 0;
                        }
                    }
                    return -1;
                }
                function buildIndexAccordingToParentBasedTree(startTarget, target) {
                    let items = startTarget.getElementsByTagName(target.tagName);
                    for (let i = 0; i < items.length; i++) {
                        if (target == items[i]) {
                            return i;
                        }
                    }
                    return -1;
                }
                Findxs.buildIndexAccordingToParentBasedTree = buildIndexAccordingToParentBasedTree;
                function getAllElementsAccordingToClause(startTarget, clause, items) {
                    try {
                        let chlidrenCount = startTarget.children.length;
                        for (let i = 0; i < chlidrenCount; i++) {
                            if (clause.match(startTarget.children[i]) == true) {
                                items[items.length] = startTarget.children[i];
                            }
                            getAllElementsAccordingToClause(startTarget.children[i], clause, items);
                        }
                    }
                    catch (err) {
                        return;
                    }
                }
                function getElementTextContent(element) {
                    let retStr = "";
                    let appendVal = "";
                    if (element.nodeType === 3) {
                        retStr = element.textContent;
                    }
                    let count = element.childNodes.length;
                    for (let i = 0; i < count; i++) {
                        let child = element.childNodes[i];
                        if (child.nodeType === 3) {
                            appendVal += child.textContent.trim();
                        }
                    }
                    if (appendVal.length > 0) {
                        retStr = appendVal;
                    }
                    return retStr;
                }
                Findxs.getElementTextContent = getElementTextContent;
                function generateXPath(element) {
                    try {
                        let path = new Array();
                        let recurseFlag = true;
                        let currentIndex = 0;
                        while (recurseFlag) {
                            if (element == null) {
                                recurseFlag = false;
                                break;
                            }
                            path[currentIndex] = "/" + element.tagName + "[" + (buildIndexAccordingToParent(element) + 1).toString() + "]";
                            currentIndex++;
                            if (element.tagName === "HTML") {
                                break;
                            }
                            element = element.parentNode;
                        }
                        let sb = "";
                        for (let i = path.length - 1; i >= 0; i--) {
                            sb = sb + path[i];
                        }
                        return sb;
                    }
                    catch (ex) {
                        alert("error");
                        return "";
                    }
                }
                Findxs.generateXPath = generateXPath;
                function replaceAmp(val) {
                    let result = val.replace("&", "&amp;");
                    return result;
                }
                Findxs.replaceAmp = replaceAmp;
                function getData() {
                    return data;
                }
                function setData(d) {
                    data = d;
                }
                Findxs.setData = setData;
            })(Findxs = Recorder.Findxs || (Recorder.Findxs = {}));
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            var UiManager;
            (function (UiManager) {
                let highlight = false;
                let lastHoveredTarget = null;
                let lastHoveredTargetX = 0;
                let lastHoveredTargetY = 0;
                let tWin = null;
                let tDoc = null;
                let overlay = null;
                let inspectedElement = null;
                let inspectedElementTranslator = null;
                let observer = null;
                let globalElementIndex = 0;
                function init() {
                    tWin = parent.window;
                    tDoc = parent.window.document;
                    inspectedElement = tDoc.getElementsByTagName("html")[0];
                    inspectedElementTranslator = Recorder.Translators.Instance.findTranslator(inspectedElement);
                    observer = new MutationObserver(refreshFramesHighlighting);
                    testStudioWsLogger.info("UiManager initialized.");
                }
                UiManager.init = init;
                function findById(id) {
                    let element = null;
                    element = tDoc.getElementById(id);
                    if (element == null) {
                        for (let i = 0; i < tWin.frames.length; i++) {
                            try {
                                element = tWin.frames[i].frameElement.contentDocument.getElementById(id);
                                if (element != null) {
                                    break;
                                }
                            }
                            catch (ex) {
                            }
                        }
                    }
                    return element;
                }
                function updateInspectedElement(element) {
                    inspectedElement = element;
                    inspectedElementTranslator = Recorder.Translators.Instance.findTranslator(element);
                }
                function attachOverlayListeners() {
                    observer.observe(telerik_jsRecorder_teststudio.getTDoc().documentElement, { childList: true, subtree: true });
                    hookOverlayDocumentEvents(telerik_jsRecorder_teststudio.getTDoc());
                    telerik_jsRecorder_teststudio.enumFrames(tWin, (frame) => {
                        hookOverlayDocumentEvents(frame);
                    });
                }
                function detachOverlayListeners() {
                    unhookOverlayDocumentEvents(telerik_jsRecorder_teststudio.getTDoc());
                    observer.disconnect();
                    telerik_jsRecorder_teststudio.enumFrames(tWin, (frame) => {
                        unhookOverlayDocumentEvents(frame);
                    });
                }
                function hookOverlayDocumentEvents(doc) {
                    doc.addEventListener("mousemove", onMouseMove, true);
                    doc.addEventListener("mouseout", onMouseOut, true);
                }
                function unhookOverlayDocumentEvents(doc) {
                    doc.removeEventListener("mousemove", onMouseMove, true);
                    doc.removeEventListener("mouseout", onMouseOut, true);
                }
                function refreshFramesHighlighting() {
                    telerik_jsRecorder_teststudio.enumFrames(tWin, (frame) => {
                        unhookOverlayDocumentEvents(frame);
                    });
                    telerik_jsRecorder_teststudio.enumFrames(tWin, (frame) => {
                        hookOverlayDocumentEvents(frame);
                    });
                }
                function enableOverlay() {
                    highlight = true;
                    attachOverlayListeners();
                }
                UiManager.enableOverlay = enableOverlay;
                function disableOverlay() {
                    detachOverlayListeners();
                    highlight = false;
                }
                UiManager.disableOverlay = disableOverlay;
                function onMouseOut(args) {
                }
                function getElementGlobalIndex(root, element) {
                    if (root == element) {
                        return true;
                    }
                    for (let i = 0; i < root.children.length; i++) {
                        if (root.children[i] == element) {
                            return true;
                        }
                        globalElementIndex++;
                        if (getElementGlobalIndex(root.children[i], element) == true) {
                            return true;
                        }
                    }
                    return false;
                }
                function onMouseMove(args) {
                    lastHoveredTargetX = args.clientX;
                    lastHoveredTargetY = args.clientY;
                    if (lastHoveredTarget == args.target) {
                        return;
                    }
                    globalElementIndex = 0;
                    getElementGlobalIndex(args.target.ownerDocument, args.target);
                    let frameIndex = telerik_jsRecorder_teststudio.getElementFrameIndex(tWin, args.target);
                    let originalRect = getMainDocumentRalatedRect(args.target);
                    let elementDimensions = {
                        top: originalRect.top,
                        left: originalRect.left,
                        height: originalRect.height,
                        width: originalRect.width,
                        bottom: originalRect.bottom,
                        right: originalRect.right,
                        elementIndex: globalElementIndex,
                        frameIndex: frameIndex
                    };
                    window.top.postMessage(JSON.stringify({ tjsr_v_2_message: "sendElementBounds", data: elementDimensions }), "*");
                }
                function getElementFrames(win, element, foundframes) {
                    if (win && win.frames && win.frames.length > 0) {
                        for (let ii = 0; ii < win.frames.length; ii++) {
                            let frame = win.frames[ii];
                            if (element.ownerDocument == frame.document) {
                                foundframes.push(frame);
                                return true;
                            }
                            if (getElementFrames(frame.window, element, foundframes) == true) {
                                foundframes.push(frame);
                                return true;
                            }
                        }
                    }
                    return false;
                }
                function getMainDocumentRalatedRect(element) {
                    let originalRect = element.getBoundingClientRect();
                    let rect = {
                        top: originalRect.top,
                        left: originalRect.left,
                        height: originalRect.height,
                        width: originalRect.width,
                        bottom: originalRect.bottom,
                        right: originalRect.right
                    };
                    if (element.ownerDocument != tDoc) {
                        let foundframes = [];
                        getElementFrames(tWin, element, foundframes);
                        let frameBorderWidth = 2;
                        for (let ii = 0; ii < foundframes.length; ii++) {
                            let frameElement = foundframes[ii].frameElement;
                            let framePadding = getFramePadding(frameElement);
                            let parentRect = frameElement.getBoundingClientRect();
                            rect.top += parentRect.top + frameBorderWidth + framePadding.tp;
                            rect.left += parentRect.left + frameBorderWidth + framePadding.lp;
                            rect.bottom += parentRect.top + frameBorderWidth;
                            rect.right += parentRect.left + frameBorderWidth;
                        }
                    }
                    return rect;
                }
                UiManager.getMainDocumentRalatedRect = getMainDocumentRalatedRect;
                function getFramePadding(targetFrameElement) {
                    let tp;
                    let lp;
                    try {
                        if (window.jQuery != null) {
                            lp = jQuery(targetFrameElement).css("padding-left") ? parseInt(jQuery(targetFrameElement).css("padding-left"), 10) : 0;
                            tp = jQuery(targetFrameElement).css("padding-top") ? parseInt(jQuery(targetFrameElement).css("padding-top"), 10) : 0;
                        }
                        else {
                            lp = targetFrameElement.style.paddingLeft ? parseInt(targetFrameElement.style.paddingLeft, 10) : 0;
                            tp = targetFrameElement.style.paddingTop ? parseInt(targetFrameElement.style.paddingTop, 10) : 0;
                        }
                    }
                    catch (ex) {
                        lp = targetFrameElement.style.paddingLeft ? parseInt(targetFrameElement.style.paddingLeft, 10) : 0;
                        tp = targetFrameElement.style.paddingTop ? parseInt(targetFrameElement.style.paddingTop, 10) : 0;
                    }
                    return { lp: lp, tp: tp };
                }
                function getTWin() {
                    return tWin;
                }
                UiManager.getTWin = getTWin;
                function setTWin(value) {
                    tWin = value;
                }
                UiManager.setTWin = setTWin;
            })(UiManager = Recorder.UiManager || (Recorder.UiManager = {}));
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            var Utils;
            (function (Utils) {
                let namespacePrefix = "ArtOfTest.WebAii.Design.IntrinsicTranslators.Descriptors.";
                let cachedBrowserName = null;
                function getElementTypeByTarget(target) {
                    let elementType = "ArtOfTest.WebAii.Controls.HtmlControls.HtmlControl";
                    if (target.tagName == null || target.tagName == undefined) {
                        return elementType;
                    }
                    let tagName = target.tagName.toLowerCase();
                    switch (tagName) {
                        case "a":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlAnchor";
                        case "audio":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlAudio";
                        case "button":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlButton";
                        case "canvas":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlCanvas";
                        case "div":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlDiv";
                        case "form":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlForm";
                        case "img":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlImage";
                        case "option":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlOption";
                        case "select":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlSelect";
                        case "span":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlSpan";
                        case "table":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlTable";
                        case "tr":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlTableRow";
                        case "th":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlTableCell";
                        case "td":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlTableCell";
                        case "video":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlVideo";
                        case "details":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlDetails";
                        case "textarea":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlTextArea";
                        case "input":
                            return getInputSubTypeByTarget(target);
                        case "meter":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlMeter";
                        case "progress":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlProgress";
                        case "time":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlTime";
                        default:
                            return elementType;
                    }
                }
                Utils.getElementTypeByTarget = getElementTypeByTarget;
                function getInputSubTypeByTarget(target) {
                    if (target.type == null) {
                        return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputControl";
                    }
                    let type = target.type.toLowerCase();
                    switch (type) {
                        case "text":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputText";
                        case "button":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputButton";
                        case "checkbox":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputCheckBox";
                        case "file":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputFile";
                        case "hidden":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputHidden";
                        case "image":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputImage";
                        case "password":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputPassword";
                        case "radio":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputRadioButton";
                        case "reset":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputReset";
                        case "submit":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputSubmit";
                        case "email":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputEmail";
                        case "number":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputNumber";
                        case "range":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputRange";
                        case "search":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputSearch";
                        case "url":
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputUrl";
                        default:
                            return "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputControl";
                    }
                }
                Utils.getInputSubTypeByTarget = getInputSubTypeByTarget;
                function buildStep(element, descriptorType, values, elementType) {
                    let descriptor = new Recorder.AutomationDescriptor(namespacePrefix + descriptorType, values, telerik_jsRecorder_findxs.buildFriendlyName(element), elementType);
                    let step = new Recorder.Step(descriptor);
                    step.setExpression(telerik_jsRecorder_findxs.buildExpression(element));
                    step.setFrameInfo(element.ownerDocument.defaultView && element.ownerDocument.defaultView.frameElement ? new Recorder.FrameInfo(element) : null);
                    step.setPage(telerik_jsRecorder_teststudio.getTargetPage());
                    step.setFriendlyName(telerik_jsRecorder_findxs.buildFriendlyName(element));
                    return step;
                }
                Utils.buildStep = buildStep;
                function fromStorage(key, defvalue) {
                    let o = window.localStorage[key];
                    if (o == "undefined" || o == null) {
                        return defvalue;
                    }
                    return o;
                }
                Utils.fromStorage = fromStorage;
                function toStorage(key, value) {
                    window.localStorage[key] = value.toString();
                }
                Utils.toStorage = toStorage;
                function delStorage(key) {
                    window.localStorage.removeItem(key);
                }
                Utils.delStorage = delStorage;
                function isParentOf(child, parent) {
                    if (child == parent) {
                        return true;
                    }
                    if (child == null) {
                        return false;
                    }
                    let p = child.parentNode;
                    while (p != null) {
                        if (p == parent) {
                            return true;
                        }
                        else {
                            p = p.parentNode;
                        }
                    }
                    return false;
                }
                Utils.isParentOf = isParentOf;
                function sleep(millis) {
                    let start = (new Date()).getTime();
                    let curTime = null;
                    do {
                        curTime = (new Date()).getTime();
                    } while (curTime - start < millis);
                }
                Utils.sleep = sleep;
                function type(object) {
                    return !!object && Object.prototype.toString.call(object).match(/(\w+)\]/)[1];
                }
                Utils.type = type;
                function getCaret(target) {
                    try {
                        if (target.selectionStart) {
                            return target.selectionStart;
                        }
                    }
                    catch (ex) {
                    }
                }
                Utils.getCaret = getCaret;
                function getBrowserName() {
                    if (cachedBrowserName === null) {
                        let N = navigator.appName;
                        let ua = navigator.userAgent;
                        let tem = ua.match(/version\/([\.\d]+)/i);
                        let M = ua.match(/(opera|chrome|safari|firefox|msie)\/?\s*(\.?\d+(\.\d+)*)/i);
                        if ((M && tem) != null) {
                            M[2] = tem[1];
                        }
                        M = M ? [M[1], M[2]] : [N, navigator.appVersion, "-?"];
                        cachedBrowserName = M[0];
                    }
                    return cachedBrowserName;
                }
                Utils.getBrowserName = getBrowserName;
                function getNamespacePrefix() {
                    return namespacePrefix;
                }
                Utils.getNamespacePrefix = getNamespacePrefix;
            })(Utils = Recorder.Utils || (Recorder.Utils = {}));
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class FrameInfo {
                constructor(target) {
                    this.frameSrc = "";
                    this.frameId = "";
                    this.frameName = "";
                    this.frameIndex = -1;
                    if (target.ownerDocument.defaultView != undefined && target.ownerDocument.defaultView.frameElement != null) {
                        this.frameSrc = target.ownerDocument.defaultView.frameElement.src;
                        this.frameId = target.ownerDocument.defaultView.frameElement.id;
                        this.frameName = target.ownerDocument.defaultView.frameElement.name;
                        let thisRef = this;
                        let indexCounter = -1;
                        telerik_jsRecorder_teststudio.enumFrames(window.top, function (frame) {
                            indexCounter++;
                            if (target.ownerDocument.defaultView == frame) {
                                thisRef.frameIndex = indexCounter;
                            }
                        });
                        if (this.frameName == undefined || this.frameName == "") {
                            this.frameName = "Frame_" + this.frameIndex.toString();
                        }
                    }
                }
                getFrameSrc() {
                    return this.frameSrc;
                }
                setFrameSrc(value) {
                    this.frameSrc = value;
                }
                getFrameId() {
                    return this.frameId;
                }
                setFrameId(value) {
                    this.frameId = value;
                }
                getFrameName() {
                    return this.frameName;
                }
                setFrameName(value) {
                    this.frameName = value;
                }
                getFrameIndex() {
                    return this.frameIndex;
                }
                setFrameIndex(value) {
                    this.frameIndex = value;
                }
            }
            Recorder.FrameInfo = FrameInfo;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class Step {
                constructor(descriptor) {
                    this.descriptor = null;
                    this.expression = null;
                    this.page = null;
                    this.friendlyName = "";
                    this.frameInfo = null;
                    this.descriptor = descriptor;
                }
                static NavigateForwardStep() {
                    return new Step({ type: "ArtOfTest.WebAii.Design.IntrinsicTranslators.Descriptors.NavigateForwardActionDescriptor" });
                }
                static NavigateBackStep() {
                    return new Step({ type: "ArtOfTest.WebAii.Design.IntrinsicTranslators.Descriptors.NavigateBackActionDescriptor" });
                }
                static NavigateToUrlStep(url) {
                    return new Step({
                        type: "ArtOfTest.WebAii.Design.IntrinsicTranslators.Descriptors.NavigateToActionDescriptor",
                        values: {
                            NavigateUrl: url
                        }
                    });
                }
                static RefreshBrowserStep() {
                    return new Step({ type: "ArtOfTest.WebAii.Design.IntrinsicTranslators.Descriptors.RefreshBrowserActionDescriptor" });
                }
                static NavigateToCorrectionStep(url) {
                    return new Step({
                        type: "ArtOfTest.WebAii.Design.IntrinsicTranslators.Descriptors.NavigateToCorrectionDescriptor",
                        values: {
                            NavigateUrl: url
                        }
                    });
                }
                toJson() {
                    return JSON.stringify(this);
                }
                getDescriptor() {
                    return this.descriptor;
                }
                setDescriptor(value) {
                    this.descriptor = value;
                }
                getExpression() {
                    return this.expression;
                }
                setExpression(value) {
                    this.expression = value;
                }
                getPage() {
                    return this.page;
                }
                setPage(value) {
                    this.page = value;
                }
                getFriendlyName() {
                    return this.friendlyName;
                }
                setFriendlyName(value) {
                    this.friendlyName = value;
                }
                getFrameInfo() {
                    return this.frameInfo;
                }
                setFrameInfo(value) {
                    this.frameInfo = value;
                }
            }
            Recorder.Step = Step;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class TestStudioContext {
                constructor(port, mode) {
                    this.port = port;
                    this.mode = mode;
                }
            }
            Common.TestStudioContext = TestStudioContext;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class UrlHelper {
                static getQueryParameterByName(url, paramName) {
                    paramName = paramName.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
                    let regex = new RegExp("[\\?&]" + paramName + "=([^&#]*)");
                    let results = regex.exec(url);
                    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
                }
                static getTestStudioContextFromUrl(url) {
                    if (url.indexOf(UrlHelper.startPageBaseUrl) === -1) {
                        return new Common.TestStudioContext(null, null);
                    }
                    return new Common.TestStudioContext(UrlHelper.getQueryParameterByName(url, "port"), UrlHelper.getQueryParameterByName(url, "mode"));
                }
            }
            UrlHelper.startPageBaseUrl = "/WebUI/teststudio_start_page.html";
            Common.UrlHelper = UrlHelper;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            var Mediator;
            (function (Mediator) {
                let logger = null;
                let domModel;
                let globalIndex = 0;
                let globalElementIndex = 0;
                function init() {
                    logger = testStudioWsLogger;
                    if (window.constructor.prototype && window.constructor.prototype.addEventListener) {
                        window.constructor.prototype.addEventListener.call(window, "message", handleCommandMessage, false);
                    }
                    else {
                        window.addEventListener("message", handleCommandMessage);
                    }
                    sendRecorderCommand({ command: "getSettings", data: "" });
                    logger.info("Mediator: Initialized");
                }
                Mediator.init = init;
                function sendRecorderCommand(cmd) {
                    window.postMessage(JSON.stringify({ tjsr_v_2_message: "sendRecorderCommand", command: cmd }), "*");
                }
                Mediator.sendRecorderCommand = sendRecorderCommand;
                function findElementDomIndex(element) {
                    let index = -1;
                    for (let ii = 0; ii < domModel.elementMap.length; ii++) {
                        if (domModel.elementMap[ii] == element) {
                            index = ii;
                            break;
                        }
                    }
                    return index;
                }
                function findElementByIndex(root, index) {
                    if (globalIndex == index) {
                        return root;
                    }
                    for (let i = 0; i < root.children.length; i++) {
                        globalIndex++;
                        if (globalIndex == index) {
                            return root.children[i];
                        }
                        let el = findElementByIndex(root.children[i], index);
                        if (el != null) {
                            return el;
                        }
                    }
                    return null;
                }
                function getElementGlobalIndex(root, element) {
                    if (root == element) {
                        return true;
                    }
                    for (let i = 0; i < root.children.length; i++) {
                        globalElementIndex++;
                        if (root.children[i] == element) {
                            return true;
                        }
                        if (getElementGlobalIndex(root.children[i], element) == true) {
                            return true;
                        }
                    }
                    return false;
                }
                function showRecorder() {
                    sendRecorderCommand({ command: "showRecorder", data: telerik_jsRecorder_utils.getBrowserName().toLowerCase() });
                }
                function handleCommandMessage(e) {
                    let jObj = null;
                    try {
                        jObj = JSON.parse(e.data);
                    }
                    catch (ex) {
                    }
                    if (!jObj || !jObj.tjsr_v_2_message) {
                        return;
                    }
                    if (TestStudio.Common.UrlHelper.getTestStudioContextFromUrl(window.location.href).mode === "1" &&
                        jObj.tjsr_v_2_message !== "navigateToUrl" &&
                        jObj.tjsr_v_2_message !== "showRecorder") {
                        return;
                    }
                    switch (jObj.tjsr_v_2_message) {
                        case "userSettings":
                            telerik_jsRecorder_findxs.setData(jObj.data);
                            break;
                        case "isResponsive":
                            if (jObj.browserType.toLowerCase() === telerik_jsRecorder_utils.getBrowserName().toLowerCase()) {
                                sendRecorderCommand({ command: "isResponsiveResponse", data: "" });
                            }
                            break;
                        case "enableRecording":
                            if (jObj.data) {
                                telerik_jsRecorder_teststudio.record();
                            }
                            else {
                                telerik_jsRecorder_teststudio.stop();
                            }
                            break;
                        case "enableHighlight":
                            if (jObj.data) {
                                telerik_jsRecorder_uiManager.enableOverlay();
                            }
                            else {
                                telerik_jsRecorder_uiManager.disableOverlay();
                            }
                            break;
                        case "navigateForward":
                            history.go(1);
                            break;
                        case "navigateBackward":
                            history.go(-1);
                            break;
                        case "refreshBrowser":
                            let refreshdStep = Recorder.Step.RefreshBrowserStep();
                            sendRecorderCommand({ command: "showNotification", data: "Refresh" });
                            window.location.reload();
                            break;
                        case "navigateToUrl":
                            if (jObj.data.callback) {
                                let navigateToUrlStep = Recorder.Step.NavigateToUrlStep(jObj.data.url);
                                sendRecorderCommand({ command: "recordAction", data: navigateToUrlStep });
                            }
                            window.location.href = jObj.data.url;
                            break;
                        case "showRecorder":
                            showRecorder();
                            break;
                        case "recordNavigateToUrl":
                            let correctionStep = Recorder.Step.NavigateToCorrectionStep(window.location.href);
                            sendRecorderCommand({ command: "recordAction", data: correctionStep });
                            window.setTimeout(() => {
                                sendRecorderCommand({ command: "showNotification", data: "Navigate to " + window.location.href });
                            }, 200);
                            break;
                        case "sendElementBounds":
                            jObj.data.startTimer = true;
                            sendRecorderCommand({ command: "elementBounds", data: jObj.data });
                            break;
                        case "getElementBounds":
                            let frames = telerik_jsRecorder_teststudio.getAllFrames(telerik_jsRecorder_uiManager.getTWin());
                            let doc = document;
                            if (jObj.frameIndex != -1) {
                                doc = frames[jObj.frameIndex].document;
                            }
                            globalIndex = -1;
                            let element = findElementByIndex(doc, jObj.elementIndex);
                            if (!jObj.isMutation) {
                                element.scrollIntoView();
                            }
                            let frameIndex = telerik_jsRecorder_teststudio.getElementFrameIndex(telerik_jsRecorder_uiManager.getTWin(), element);
                            let originalRect = telerik_jsRecorder_uiManager.getMainDocumentRalatedRect(element);
                            let elementDimensions = {
                                top: originalRect.top,
                                left: originalRect.left,
                                height: originalRect.height,
                                width: originalRect.width,
                                bottom: originalRect.bottom,
                                right: originalRect.right,
                                elementIndex: jObj.elementIndex,
                                frameIndex: jObj.frameIndex,
                                startTimer: false
                            };
                            sendRecorderCommand({ command: "elementBounds", data: elementDimensions });
                            break;
                        default:
                            break;
                    }
                }
            })(Mediator = Recorder.Mediator || (Recorder.Mediator = {}));
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class DragDropWindowData {
                constructor(windowWidth, windowHeight, windowX, windowY, scrollLeft, scrollTop, windowDropX, windowDropY) {
                    this.windowWidth = windowWidth;
                    this.windowHeight = windowHeight;
                    this.windowX = windowX;
                    this.windowY = windowY;
                    this.scrollLeft = scrollLeft;
                    this.scrollTop = scrollTop;
                    this.windowDropX = windowDropX;
                    this.windowDropY = windowDropY;
                }
                getWindowWidth() {
                    return this.windowWidth;
                }
                setWindowWidth(value) {
                    this.windowWidth = value;
                }
                getWindowHeight() {
                    return this.windowHeight;
                }
                setWindowHeight(value) {
                    this.windowHeight = value;
                }
                getWindowX() {
                    return this.windowX;
                }
                setWindowX(value) {
                    this.windowX = value;
                }
                getWindowY() {
                    return this.windowY;
                }
                setWindowY(value) {
                    this.windowY = value;
                }
                getScrollLeft() {
                    return this.scrollLeft;
                }
                setScrollLeft(value) {
                    this.scrollLeft = value;
                }
                getScrollTop() {
                    return this.scrollTop;
                }
                setScrollTop(value) {
                    this.scrollTop = value;
                }
                getWindowDropX() {
                    return this.windowDropX;
                }
                setWindowDropX(value) {
                    this.windowDropX = value;
                }
                getWindowDropY() {
                    return this.windowDropY;
                }
                setWindowDropY(value) {
                    this.windowDropY = value;
                }
            }
            Recorder.DragDropWindowData = DragDropWindowData;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class TextTypingInfo {
                constructor() {
                    this.elementText = "";
                    this.caretPosition = 0;
                    this.typedText = "";
                    this.isTextArea = false;
                    this.isBackSpace = false;
                }
                createFromTarget(target) {
                    this.elementText = target.value;
                    if (target.tagName.toLowerCase() === "textarea") {
                        this.isTextArea = true;
                    }
                    if (target.contentEditable == "true") {
                        this.elementText = target.innerText;
                    }
                    if (!this.elementText) {
                        this.elementText = target.textContent;
                    }
                    this.caretPosition = telerik_jsRecorder_utils.getCaret(target);
                }
                getElementText() {
                    return this.elementText;
                }
                setElementText(value) {
                    this.elementText = value;
                }
                getCaretPosition() {
                    return this.caretPosition;
                }
                setCaretPosition(value) {
                    this.caretPosition = value;
                }
                getTypedText() {
                    return this.typedText;
                }
                setTypedText(value) {
                    this.typedText = value;
                }
                getIsTextArea() {
                    return this.isTextArea;
                }
                setIsTextArea(value) {
                    this.isTextArea = value;
                }
                getIsBackSpace() {
                    return this.isBackSpace;
                }
                setIsBackSpace(value) {
                    this.isBackSpace = value;
                }
            }
            Recorder.TextTypingInfo = TextTypingInfo;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class SelectionValues {
                constructor(index, value, text) {
                    this.index = index;
                    this.value = value;
                    this.text = text;
                }
                getIndex() {
                    return this.index;
                }
                setIndex(value) {
                    this.index = value;
                }
                getValue() {
                    return this.value;
                }
                setValue(value) {
                    this.value = value;
                }
                getText() {
                    return this.text;
                }
                setText(value) {
                    this.text = value;
                }
            }
            Recorder.SelectionValues = SelectionValues;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class Translators {
                constructor() {
                    this.logger = testStudioWsLogger;
                    this.all = new Array();
                    this.all.push(new IntrinsicTranslator());
                    this.logger.info("Initializing translators...");
                }
                static get Instance() {
                    if (this.instance === null || this.instance === undefined) {
                        this.instance = new Translators();
                    }
                    return this.instance;
                }
                findTranslator(e) {
                    this.logger.info("translators.findTranslater called for: " + e);
                    for (let i = 0; i < this.all.length; i++) {
                        let currTrans = this.all[i];
                        if (currTrans.match(e)) {
                            return currTrans;
                        }
                    }
                    return null;
                }
            }
            Recorder.Translators = Translators;
            class IntrinsicTranslator {
                constructor() {
                    this.name = "Intrinsic translator";
                    this.useMatchFunc = true;
                    this.verificators = new Array();
                }
                match(e) {
                    return true;
                }
                translate(command) {
                    let translation = { descriptor: null, notification: null };
                    let values = {
                        InputNumberActionType: null,
                        NumberUpDownStep: null,
                        ExpectedValue: null,
                        CheckedState: null,
                        Focus: null,
                        OffSet: null,
                        SelectedItems: null,
                        SelectMode: null,
                        SelectionIndex: null,
                        SelectionValue: null,
                        SelectionText: null,
                        InvokeSelectionChanged: null,
                        DragDropWindowData: null,
                        DropTargetType: null,
                        elementText: null
                    };
                    command.friendlyName = telerik_jsRecorder_findxs.buildFriendlyName(command.target);
                    if (command.action === "LC") {
                        if ((command.target.tagName.toLowerCase() === "input" &&
                            (command.target.type == null || command.target.type === "text" || command.target.type === "url" || command.target.type === "email")) ||
                            command.target.tagName.toLowerCase() === "textarea" || command.target.tagName.toLowerCase() === "select"
                            || command.target.tagName.toLowerCase() === "option") {
                        }
                        else if (command.target.tagName.toLowerCase() === "input" && command.target.type === "number") {
                            let step = parseInt(command.target.step, 10);
                            if (telerik_jsRecorder_teststudio.getIsInputNumberStepUp()) {
                                values.InputNumberActionType = 0;
                                values.NumberUpDownStep = isNaN(step) ? 1 : command.target.step;
                                translation.descriptor = new Recorder.AutomationDescriptor(telerik_jsRecorder_utils.getNamespacePrefix() +
                                    "InputNumberActionDescriptor", values, command.friendlyName, "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputNumber");
                                translation.notification = "Step up on '" + command.friendlyName + "' with step '" + values.NumberUpDownStep + "'";
                            }
                            else if (telerik_jsRecorder_teststudio.getIsInputNumberStepDown()) {
                                values.InputNumberActionType = 1;
                                values.NumberUpDownStep = isNaN(step) ? 1 : command.target.step;
                                translation.descriptor = new Recorder.AutomationDescriptor(telerik_jsRecorder_utils.getNamespacePrefix() +
                                    "InputNumberActionDescriptor", values, command.friendlyName, "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputNumber");
                                translation.notification = "Step down on '" + command.friendlyName + "' with step '" + values.NumberUpDownStep + "'";
                            }
                        }
                        else if (command.target.tagName.toLowerCase() === "input" && command.target.type === "range") {
                            values.ExpectedValue = command.target.valueAsNumber;
                            translation.descriptor = new Recorder.AutomationDescriptor(telerik_jsRecorder_utils.getNamespacePrefix() +
                                "InputRangeActionDescriptor", values, command.friendlyName, "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputRange");
                            translation.notification = "Set range input value on '" + command.friendlyName + "' to '" + values.ExpectedValue + "'";
                        }
                        else if (command.target.type === "checkbox") {
                            values.CheckedState = !command.target.checked;
                            translation.descriptor = new Recorder.AutomationDescriptor(telerik_jsRecorder_utils.getNamespacePrefix() +
                                "CheckActionDescriptor", values, command.friendlyName, "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputCheckBox");
                            translation.notification = "Checked state of '" + command.friendlyName + "' set to be " + values.CheckedState;
                        }
                        else if (command.target.type === "radio" && !command.target.checked) {
                            values.CheckedState = !command.target.checked;
                            translation.descriptor = new Recorder.AutomationDescriptor(telerik_jsRecorder_utils.getNamespacePrefix() +
                                "CheckActionDescriptor", values, command.friendlyName, "ArtOfTest.WebAii.Controls.HtmlControls.HtmlInputCheckBox");
                            translation.notification = "Checked state of '" + command.friendlyName + "' set to be " + values.CheckedState;
                        }
                        else if (command.target.tagName.toLowerCase() === "audio") {
                            values.Focus = true;
                            values.OffSet = telerik_jsRecorder_teststudio.getStartDragPoint();
                            translation.descriptor = new Recorder.AutomationDescriptor(telerik_jsRecorder_utils.getNamespacePrefix() +
                                "DesktopActionDescriptor", values, command.friendlyName, telerik_jsRecorder_utils.getElementTypeByTarget(command.target));
                            translation.notification = "Desktop command: Left Click on '" + command.friendlyName + "'";
                        }
                        else {
                            translation.descriptor = new Recorder.AutomationDescriptor(telerik_jsRecorder_utils.getNamespacePrefix() +
                                "ClickActionDescriptor", values, command.friendlyName, telerik_jsRecorder_utils.getElementTypeByTarget(command.target));
                            translation.notification = "Click '" + command.friendlyName + "'";
                        }
                    }
                    else if (command.action === "OPTION") {
                        let selectedItems = new Array();
                        let selectCtrl = command.target;
                        let selectionNtf = "";
                        for (let i = 0; i < selectCtrl.options.length; i++) {
                            let option = selectCtrl.options[i];
                            if (option.selected) {
                                selectedItems.push(new Recorder.SelectionValues(option.index, option.textContent, option.value));
                                selectionNtf += "'" + option.textContent + "' ";
                            }
                        }
                        values.SelectedItems = selectedItems;
                        values.SelectMode = 2;
                        command.target = command.target.parentNode;
                        translation.descriptor = new Recorder.AutomationDescriptor(telerik_jsRecorder_utils.getNamespacePrefix() +
                            "ListBoxSelectActionDescriptor", values, "Select index", "ArtOfTest.WebAii.Controls.HtmlControls.HtmlSelect");
                        translation.notification = "Select " + selectionNtf + "in '" + command.friendlyName + "'";
                    }
                    else if (command.action === "CHANGE") {
                        let count1 = command.target.children.length;
                        for (let i = 0; i < count1; i++) {
                            if (command.target.children[i].selected == true) {
                                values.SelectionIndex = i;
                                values.SelectionValue = command.target.children[i].value;
                                values.SelectionText = command.target.children[i].text;
                                values.InvokeSelectionChanged = true;
                                break;
                            }
                        }
                        translation.descriptor = new Recorder.AutomationDescriptor(telerik_jsRecorder_utils.getNamespacePrefix() +
                            "SelectDropDownActionDescriptor", values, command.friendlyName, "ArtOfTest.WebAii.Controls.HtmlControls.HtmlSelect");
                        translation.notification = "Select '" + values.SelectionText + "' in '" + command.friendlyName + "'";
                    }
                    else if (command.action === "DD") {
                        values.OffSet = telerik_jsRecorder_teststudio.getStartDragPoint();
                        values.DragDropWindowData = telerik_jsRecorder_teststudio.getDragDropWindowData();
                        values.DropTargetType = 1;
                        values.Focus = true;
                        translation.descriptor = new Recorder.AutomationDescriptor(telerik_jsRecorder_utils.getNamespacePrefix() +
                            "DragDropActionDescriptor", values, command.friendlyName, telerik_jsRecorder_utils.getElementTypeByTarget(command.target));
                        translation.notification = "Drag drop  '" + command.friendlyName + "'";
                    }
                    else if (command.action === "KP") {
                        if (command.target.type == null ||
                            command.target.type === "text" ||
                            command.target.type === "textarea" ||
                            command.target.type === "password" ||
                            command.target.type === "file" ||
                            command.target.type === "search" ||
                            command.target.type === "email" ||
                            command.target.type === "number" ||
                            command.target.type === "url") {
                            values = command.data;
                            translation.descriptor = new Recorder.AutomationDescriptor(telerik_jsRecorder_utils.getNamespacePrefix() +
                                "SetTextActionDescriptor", values, command.friendlyName, telerik_jsRecorder_utils.getElementTypeByTarget(command.target));
                            translation.notification = "Enter text '" + values.elementText + "' in '" + command.friendlyName + "'";
                        }
                    }
                    else if (command.action === "DKP") {
                        translation.descriptor = new Recorder.AutomationDescriptor(telerik_jsRecorder_utils.getNamespacePrefix() +
                            "DesktopKeyboardActionDescriptor", command.data, command.friendlyName, telerik_jsRecorder_utils.getElementTypeByTarget(command.target));
                        translation.notification = "Keyboard(KeyPress) - '" + command.data + "' on '" + command.friendlyName + "'";
                    }
                    else if (command.action === "HO") {
                    }
                    return translation;
                }
            }
            Recorder.IntrinsicTranslator = IntrinsicTranslator;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class PageUri {
                constructor(url, title) {
                    this.url = url;
                    this.title = title;
                }
                getUrl() {
                    return this.url;
                }
                setUrl(value) {
                    this.url = value;
                }
                getTitle() {
                    return this.title;
                }
                setTitle(value) {
                    this.title = value;
                }
            }
            Recorder.PageUri = PageUri;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class SpecialKey {
                constructor(success, isSpecialKey, data) {
                    this.success = success;
                    this.isSpecialKey = isSpecialKey;
                    this.data = data;
                }
            }
            Recorder.SpecialKey = SpecialKey;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class PaddingOffset {
                constructor(leftPadding, topPadding) {
                    this.leftPadding = leftPadding;
                    this.topPadding = topPadding;
                }
            }
            Common.PaddingOffset = PaddingOffset;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class Rectangle {
                constructor(left, top, width, height, right, bottom) {
                    this.left = left;
                    this.top = top;
                    this.width = width;
                    this.height = height;
                    this.right = right;
                    this.bottom = bottom;
                }
                static createFromClientRect(clientRect) {
                    return new Rectangle(clientRect.left, clientRect.top, clientRect.width, clientRect.height, clientRect.right, clientRect.bottom);
                }
                toString() {
                    return `${this.left},${this.top},${this.width},${this.height}`;
                }
            }
            Common.Rectangle = Rectangle;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class FramesUtils {
                static buildFlatFramesCollection(frame) {
                    let flatFramesColletion = [];
                    FramesUtils.buildFrames(frame, flatFramesColletion);
                    return flatFramesColletion;
                }
                static buildFramesInfo(framesCollection) {
                    let framesInfo = "";
                    for (let i = 0; i < framesCollection.length; ++i) {
                        let frameElement = framesCollection[i].frameElement;
                        if (frameElement != null) {
                            framesInfo += i;
                            framesInfo += "-@-";
                            framesInfo += frameElement.name;
                            framesInfo += "-@-";
                            framesInfo += frameElement.id;
                            framesInfo += "-@-";
                            framesInfo += frameElement.src;
                            framesInfo += "-@-";
                            let frameRect = FramesUtils.getFrameRectangle(frameElement);
                            framesInfo += frameRect.toString();
                            framesInfo += "-@-";
                            framesInfo += "-@-";
                            framesInfo += frameElement.tagName;
                            framesInfo += "-@-";
                            framesInfo += framesCollection[i].frameIndexRaw;
                            framesInfo += "-@-";
                            if (frameElement.hasAttribute("testStudioTag")) {
                                framesInfo += frameElement.getAttribute("testStudioTag");
                            }
                            framesInfo += "**;**";
                        }
                        else {
                            framesInfo += "**;**";
                        }
                    }
                    return framesInfo;
                }
                static getFrameRectangle(frameElement) {
                    let frameRect = frameElement.getBoundingClientRect();
                    let parentElement = frameElement.__webaii_parentWindow.frameElement;
                    let left = frameRect.left;
                    let top = frameRect.top;
                    while (parentElement != undefined) {
                        let parentRect = parentElement.getBoundingClientRect();
                        left += parentRect.left;
                        top += parentRect.top;
                        parentElement = parentElement.__webaii_parentWindow.frameElement;
                    }
                    return new Common.Rectangle(left, top, frameRect.width, frameRect.height, left + frameRect.width, top + frameRect.height);
                }
                static getFramePaddingOffset(targetFrameElement) {
                    let tp;
                    let lp;
                    try {
                        if (window.jQuery != undefined) {
                            lp = jQuery(targetFrameElement).css("padding-left") ? parseInt(jQuery(targetFrameElement).css("padding-left"), 10) : 0;
                            tp = jQuery(targetFrameElement).css("padding-top") ? parseInt(jQuery(targetFrameElement).css("padding-top"), 10) : 0;
                        }
                        else {
                            lp = targetFrameElement.style.paddingLeft ? parseInt(targetFrameElement.style.paddingLeft, 10) : 0;
                            tp = targetFrameElement.style.paddingTop ? parseInt(targetFrameElement.style.paddingTop, 10) : 0;
                        }
                    }
                    catch (ex) {
                        lp = targetFrameElement.style.paddingLeft ? parseInt(targetFrameElement.style.paddingLeft, 10) : 0;
                        tp = targetFrameElement.style.paddingTop ? parseInt(targetFrameElement.style.paddingTop, 10) : 0;
                    }
                    return new Common.PaddingOffset(lp, tp);
                }
                static buildFrames(parentWindow, flatFramesCollection) {
                    try {
                        if (parentWindow != undefined && parentWindow.frames != undefined && parentWindow.frames.length > 0) {
                            let count = parentWindow.frames.length;
                            for (let i = 0; i < count; ++i) {
                                let frame = parentWindow.frames[i];
                                if (frame == null || frame.frameElement == null) {
                                    continue;
                                }
                                let rect = frame.frameElement.getBoundingClientRect();
                                if (rect != null && rect.width > 0 && rect.height > 0) {
                                    frame.frameIndexRaw = i;
                                    flatFramesCollection[flatFramesCollection.length] = frame;
                                }
                                if (frame.frameElement != undefined) {
                                    frame.frameElement.__webaii_parentWindow = parentWindow;
                                    if (frame.frames.length > 0) {
                                        FramesUtils.buildFrames(frame, flatFramesCollection);
                                    }
                                }
                            }
                        }
                    }
                    catch (err) {
                        if (err.name !== "SecurityError") {
                            throw "BuildFrames().Error: " + err;
                        }
                    }
                }
            }
            Common.FramesUtils = FramesUtils;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio_1) {
        var Recorder;
        (function (Recorder) {
            var TestStudio;
            (function (TestStudio) {
                let initialized = false;
                let isRecording = false;
                let lastElementTarget = null;
                let isScrollAction = false;
                let isMouseButtonDown = false;
                let inMutation = false;
                let targetUnderMouse = null;
                let jQueryInstance = null;
                let tWin = null;
                let tDoc = null;
                let framesInterval = 0;
                let isDragElement = false;
                let xMove = -1;
                let yMove = -1;
                let startDragPoint = null;
                let dragDropWindowData = null;
                let lastKeyPressEventKeyCode = null;
                let mouseDownInputValue;
                let isInputNumberStepUp = false;
                let isInputNumberStepDown = false;
                let observer = null;
                let logger = null;
                function init() {
                    if (initialized) {
                        return;
                    }
                    logger = testStudioWsLogger;
                    tWin = parent.window;
                    tDoc = parent.window.document;
                    jQueryInstance = parent.window.jQuery;
                    initialized = true;
                    telerik_jsRecorder_mediator.sendRecorderCommand({ command: "refreshDom" });
                    observer = new MutationObserver(function (mutations) {
                        telerik_jsRecorder_mediator.sendRecorderCommand({ command: "mutationRefresh" });
                    });
                    observer.observe(tDoc.documentElement, { childList: true, subtree: true });
                    enumFrames(tWin, (frame) => {
                        observer.observe(frame.frameElement.contentDocument.documentElement, { childList: true, subtree: true });
                    });
                    logger.info("TestStudio Manager initialized.");
                }
                TestStudio.init = init;
                function enumFrames(win, callback) {
                    if (win && win.frames && win.frames.length > 0) {
                        for (let ii = 0; ii < win.frames.length; ii++) {
                            let frame = win.frames[ii];
                            try {
                                callback(frame);
                            }
                            catch (ex) {
                                continue;
                            }
                            if (frame.frames.length > 0) {
                                enumFrames(frame, callback);
                            }
                        }
                    }
                }
                TestStudio.enumFrames = enumFrames;
                function getAllFrames(win) {
                    return TestStudio_1.Common.FramesUtils.buildFlatFramesCollection(win);
                }
                TestStudio.getAllFrames = getAllFrames;
                function getElementFrameIndex(win, element) {
                    let frameIndex = -1;
                    let frames = TestStudio_1.Common.FramesUtils.buildFlatFramesCollection(win);
                    for (let ii = 0; ii < frames.length; ii++) {
                        try {
                            if (element.ownerDocument == frames[ii].window.document) {
                                frameIndex = ii;
                                break;
                            }
                        }
                        catch (ex) {
                            continue;
                        }
                    }
                    return frameIndex;
                }
                TestStudio.getElementFrameIndex = getElementFrameIndex;
                function domMutationActive(args) {
                    inMutation = true;
                    if (inMutation) {
                        setTimeout(() => {
                            let r = isTargetReady(args.srcElement);
                            if (args.relatedNode != null && args.relatedNode != args.srcElement) {
                                r = r && isTargetReady(args.relatedNode);
                            }
                            inMutation = !r;
                        }, 250);
                    }
                }
                function isReady() {
                    if ((jQueryInstance && jQueryInstance.active != 0) || inMutation) {
                        return false;
                    }
                    return true;
                }
                function isTargetReady(target) {
                    if (!jQueryInstance) {
                        return true;
                    }
                    return !jQueryInstance(target).data("animating") &&
                        !jQueryInstance(target).data("transitioning") &&
                        !jQueryInstance(target).is(":animated");
                }
                function hookDocumentEvents(doc) {
                    doc.addEventListener("mousedown", captureMouse, true);
                    doc.addEventListener("mouseup", captureMouse, true);
                    doc.addEventListener("keyup", captureKeyboard, true);
                    doc.addEventListener("keypress", captureKeyboard, true);
                    doc.addEventListener("change", change, true);
                    doc.addEventListener("mousemove", captureMouseOver, true);
                    doc.addEventListener("scroll", captureScroll, true);
                }
                function unHookDocumentEvents(doc) {
                    doc.removeEventListener("mousedown", captureMouse, true);
                    doc.removeEventListener("mouseup", captureMouse, true);
                    doc.removeEventListener("keyup", captureKeyboard, true);
                    doc.removeEventListener("keypress", captureKeyboard, true);
                    doc.removeEventListener("change", change, true);
                    doc.removeEventListener("mousemove", captureMouseOver, true);
                    doc.removeEventListener("scroll", captureScroll, true);
                }
                function record() {
                    if (isRecording === true) {
                        return;
                    }
                    if (telerik_jsRecorder_utils.getBrowserName() === "Firefox") {
                        tDoc.defaultView.addEventListener("beforeunload", beforeWindowUnload, true);
                    }
                    hookDocumentEvents(tDoc);
                    enumFrames(tWin, (frame) => {
                        hookDocumentEvents(frame.frameElement.contentDocument);
                    });
                    if (telerik_jsRecorder_utils.getBrowserName() === "Chrome" ||
                        telerik_jsRecorder_utils.getBrowserName() === "Firefox") {
                        framesInterval = setInterval(() => {
                            enumFrames(tWin, function (frame) {
                                hookDocumentEvents(frame.frameElement.contentDocument);
                            });
                        }, 2500);
                    }
                    isRecording = true;
                    logger.info("Recording started...");
                }
                TestStudio.record = record;
                function stop() {
                    if (isRecording === false) {
                        return;
                    }
                    if (telerik_jsRecorder_utils.getBrowserName() === "Firefox") {
                        tDoc.defaultView.removeEventListener("beforeunload", beforeWindowUnload, true);
                    }
                    unHookDocumentEvents(tDoc);
                    enumFrames(tWin, function (frame) {
                        unHookDocumentEvents(frame.frameElement.contentDocument);
                    });
                    if (telerik_jsRecorder_utils.getBrowserName() === "Chrome" ||
                        telerik_jsRecorder_utils.getBrowserName() === "Firefox") {
                        clearInterval(framesInterval);
                    }
                    isRecording = false;
                    logger.info("Recording stopped...");
                }
                TestStudio.stop = stop;
                function captureMouseOver(args) {
                    targetUnderMouse = args.target;
                    if (isMouseButtonDown) {
                        if (xMove == -1) {
                            xMove = args.screenX;
                        }
                        if (yMove == -1) {
                            yMove = args.screenY;
                        }
                        if (Math.abs(xMove - args.screenX) > 10 || Math.abs(yMove - args.screenY) > 10) {
                            isDragElement = true;
                        }
                    }
                }
                function captureMouse(args) {
                    if (!args.target) {
                        return;
                    }
                    let target = args.target;
                    if (target.tagName && target.tagName.toLowerCase() === "html") {
                        return;
                    }
                    let recordTarget = args.target;
                    let cmd = new Recorder.CapturedCommand();
                    if (telerik_jsRecorder_utils.type(args) === "MouseEvent") {
                        if (args.which == 3) {
                            cmd.setAction("RC");
                        }
                        else {
                            cmd.setAction("LC");
                        }
                        if (args.type === "mousedown") {
                            lastElementTarget = args.target;
                            isScrollAction = false;
                            isMouseButtonDown = true;
                            if (telerik_jsRecorder_utils.getBrowserName() === "Firefox") {
                                startDragPoint = new Recorder.ActionPoint(args.layerX, args.layerY);
                            }
                            else {
                                startDragPoint = new Recorder.ActionPoint(args.offsetX, args.offsetY);
                            }
                            if (target.tagName.toLowerCase() === "input") {
                                let inputTarget = target;
                                if (inputTarget.type === "number" || inputTarget.type === "range") {
                                    isInputNumberStepUp = false;
                                    isInputNumberStepDown = false;
                                    mouseDownInputValue = inputTarget.valueAsNumber;
                                }
                            }
                            return;
                        }
                        if (args.type === "mouseup") {
                            if (isScrollAction) {
                                return;
                            }
                            if (isDragElement) {
                                let scrollTop = document.getElementsByTagName("html")[0].scrollTop;
                                let scrollLeft = document.getElementsByTagName("html")[0].scrollLeft;
                                dragDropWindowData = new Recorder.DragDropWindowData(window.innerWidth, window.innerHeight, window.screenX, window.screenY, scrollLeft, scrollTop, args.pageX, args.pageY);
                                recordTarget = lastElementTarget;
                                cmd.setAction("DD");
                            }
                            if (target.tagName.toLowerCase() === "input") {
                                let inputTarget = target;
                                if (inputTarget.type === "number") {
                                    if (inputTarget.valueAsNumber > mouseDownInputValue) {
                                        isInputNumberStepUp = true;
                                        isInputNumberStepDown = false;
                                    }
                                    else if (inputTarget.valueAsNumber < mouseDownInputValue) {
                                        isInputNumberStepDown = true;
                                        isInputNumberStepUp = false;
                                    }
                                    else if (inputTarget.valueAsNumber !== mouseDownInputValue &&
                                        !isNaN(inputTarget.valueAsNumber)) {
                                        isInputNumberStepUp = true;
                                        isInputNumberStepDown = false;
                                    }
                                }
                                if (inputTarget.type === "range") {
                                    if (inputTarget.valueAsNumber === mouseDownInputValue ||
                                        isNaN(inputTarget.valueAsNumber)) {
                                        return;
                                    }
                                }
                                if (inputTarget.type === "search") {
                                    let oldInputValue = inputTarget.value;
                                    window.setTimeout(function () {
                                        if (oldInputValue != inputTarget.value) {
                                            let delayedCommand = new Recorder.CapturedCommand();
                                            delayedCommand.setAction("KP");
                                            delayedCommand.setTarget(args.target);
                                            let tpi = new Recorder.TextTypingInfo();
                                            tpi.createFromTarget(args.target);
                                            delayedCommand.setData(tpi);
                                            translateCommand(delayedCommand);
                                        }
                                    }, 0);
                                    return;
                                }
                            }
                            isMouseButtonDown = false;
                            isDragElement = false;
                            xMove = -1;
                            yMove = -1;
                            lastElementTarget = null;
                        }
                    }
                    else {
                        logger.error("Unknown Event :" + args.type + ":" + args.relatedNode + ":" + args.srcElement + ":" + args.target);
                        return;
                    }
                    cmd.setExpression(telerik_jsRecorder_findxs.buildExpression(recordTarget));
                    cmd.setTarget(recordTarget);
                    translateCommand(cmd);
                }
                function getSpecialKeys(args, browser) {
                    let isSpecialKey = false;
                    let isSuccess = true;
                    let data;
                    let target = args.target;
                    if (browser === "Firefox" ||
                        (browser === "Chrome" && args.key) ||
                        (browser === "Safari" && args.keyIdentifier)) {
                        switch (args.keyCode) {
                            case 16:
                                isSuccess = false;
                                break;
                            case 17:
                                isSuccess = false;
                                break;
                            case 18:
                                isSuccess = false;
                                break;
                            case 13:
                                if (browser === "Safari" && args.type === "keyup" && !lastKeyPressEventKeyCode) {
                                    isSuccess = false;
                                    break;
                                }
                                if (target.tagName.toLowerCase() === "textarea" || target.contentEditable === "true") {
                                    data = "Enter";
                                    break;
                                }
                                isSpecialKey = true;
                                data = "Enter";
                                break;
                            case 9:
                                data = "Tab";
                                isSpecialKey = true;
                                break;
                            case 27:
                                data = "Escape";
                                isSpecialKey = true;
                                break;
                            case 33:
                                data = "PgUp";
                                isSpecialKey = true;
                                break;
                            case 34:
                                data = "PgDown";
                                isSpecialKey = true;
                                break;
                            case 35:
                                data = "End";
                                isSpecialKey = true;
                                break;
                            case 36:
                                data = "Home";
                                isSpecialKey = true;
                                break;
                            case 37:
                                data = "Left";
                                isSpecialKey = true;
                                break;
                            case 38:
                                data = "Up";
                                isSpecialKey = true;
                                break;
                            case 39:
                                data = "Right";
                                isSpecialKey = true;
                                break;
                            case 40:
                                data = "Down";
                                isSpecialKey = true;
                                break;
                            case 45:
                                data = "Ins";
                                isSpecialKey = true;
                                break;
                            case 46:
                                data = "Del";
                                isSpecialKey = true;
                                break;
                            case 112:
                                data = "F1";
                                isSpecialKey = true;
                                break;
                            case 113:
                                data = "F2";
                                isSpecialKey = true;
                                break;
                            case 114:
                                data = "F3";
                                isSpecialKey = true;
                                break;
                            case 115:
                                data = "F4";
                                isSpecialKey = true;
                                break;
                            case 117:
                                data = "F6";
                                isSpecialKey = true;
                                break;
                            case 118:
                                data = "F7";
                                isSpecialKey = true;
                                break;
                            case 119:
                                data = "F8";
                                isSpecialKey = true;
                                break;
                            case 120:
                                data = "F9";
                                isSpecialKey = true;
                                break;
                            case 121:
                                data = "F10";
                                isSpecialKey = true;
                                break;
                            case 122:
                                data = "F11";
                                isSpecialKey = true;
                                break;
                            case 123:
                                data = "F12";
                                isSpecialKey = true;
                                break;
                            default:
                                break;
                        }
                    }
                    return new Recorder.SpecialKey(isSuccess, isSpecialKey, data);
                }
                function captureKeyboard(args) {
                    if (!args.target) {
                        return;
                    }
                    let target = args.target;
                    if (target.tagName && target.tagName.toLowerCase() === "html") {
                        return;
                    }
                    let recordTarget = args.target;
                    let cmd = new Recorder.CapturedCommand();
                    if (telerik_jsRecorder_utils.type(args) === "KeyboardEvent") {
                        if (args.type === "keypress") {
                            lastKeyPressEventKeyCode = args.keyCode || args.charCode;
                        }
                        let browser = telerik_jsRecorder_utils.getBrowserName();
                        let isSpecialKey = false;
                        let keyData = getSpecialKeys(args, browser);
                        if (keyData.success === false) {
                            return;
                        }
                        isSpecialKey = keyData.isSpecialKey;
                        cmd.setData(keyData.data);
                        if (args.ctrlKey) {
                            switch (args.which) {
                                case 65:
                                    cmd.setData("A");
                                    isSpecialKey = true;
                                    break;
                                case 67:
                                    cmd.setData("C");
                                    isSpecialKey = true;
                                    break;
                                case 86:
                                    cmd.setData("V");
                                    isSpecialKey = true;
                                    break;
                                case 88:
                                    cmd.setData("X");
                                    isSpecialKey = true;
                                    break;
                                case 89:
                                    cmd.setData("Y");
                                    isSpecialKey = true;
                                    break;
                                case 90:
                                    cmd.setData("Z");
                                    isSpecialKey = true;
                                    break;
                                default:
                                    break;
                            }
                        }
                        if (isSpecialKey) {
                            if (args.type === "keypress") {
                                return;
                            }
                            if (args.shiftKey) {
                                cmd.setData("Shift+" + cmd.getData());
                            }
                            if (args.altKey) {
                                cmd.setData("Alt+" + cmd.getData());
                            }
                            if (args.ctrlKey) {
                                cmd.setData("Ctrl+" + cmd.getData());
                            }
                            cmd.setAction("DKP");
                        }
                        else {
                            if (target.tagName.toLowerCase() !== "textarea" &&
                                target.tagName.toLowerCase() !== "input" &&
                                target.contentEditable != "true") {
                                return;
                            }
                            cmd.setAction("KP");
                            let tpi = new Recorder.TextTypingInfo();
                            tpi.createFromTarget(args.target);
                            if (tpi.getIsTextArea()) {
                                let skipEvent = "keyup";
                                if ((args.keyCode || args.charCode) === 8) {
                                    tpi.setIsBackSpace(true);
                                    if (browser === "Firefox" && args.type === skipEvent) {
                                        return;
                                    }
                                }
                                else if (args.type === skipEvent) {
                                    return;
                                }
                                tpi.setTypedText(String.fromCharCode(args.keyCode || args.charCode));
                            }
                            else if (args.type === "keypress") {
                                return;
                            }
                            cmd.setData(tpi);
                        }
                        if (args.type === "keyup") {
                            lastKeyPressEventKeyCode = null;
                        }
                    }
                    else {
                        logger.error("Unknown Event :" + args.type + ":" + args.relatedNode + ":" + args.srcElement + ":" + args.target);
                        return;
                    }
                    cmd.setExpression(telerik_jsRecorder_findxs.buildExpression(recordTarget));
                    cmd.setTarget(recordTarget);
                    translateCommand(cmd);
                }
                function captureScroll(args) {
                    if (args.type === "scroll") {
                        isScrollAction = true;
                    }
                }
                function change(args) {
                    if (args.target.tagName.toLowerCase() !== "select") {
                        return;
                    }
                    let action = "";
                    if (args.target["multiple"]) {
                        action = "OPTION";
                    }
                    else {
                        action = "CHANGE";
                    }
                    let cmd = new Recorder.CapturedCommand();
                    cmd.setAction(action);
                    cmd.setTarget(args.target);
                    translateCommand(cmd);
                }
                function translateCommand(cmd) {
                    let translator = Recorder.Translators.Instance.findTranslator(cmd.getTarget());
                    if (translator != null) {
                        let translation = translator.translate(cmd);
                        processTranslation(translation, cmd.getTarget());
                    }
                }
                TestStudio.translateCommand = translateCommand;
                function beforeWindowUnload() {
                    if (isRecording && lastElementTarget) {
                        let target = lastElementTarget;
                        let cmd = new Recorder.CapturedCommand();
                        cmd.setAction("LC");
                        cmd.setExpression(telerik_jsRecorder_findxs.buildExpression(target));
                        cmd.setTarget(target);
                        translateCommand(cmd);
                    }
                }
                function getTargetPage() {
                    return new Recorder.PageUri(tDoc.location.href, tDoc.title);
                }
                TestStudio.getTargetPage = getTargetPage;
                function processTranslation(translation, target) {
                    if (translation != null && translation.descriptor != null) {
                        let step = new Recorder.Step(translation.descriptor);
                        step.setExpression(telerik_jsRecorder_findxs.buildExpression(target));
                        step.setFrameInfo(target.ownerDocument.defaultView && target.ownerDocument.defaultView.frameElement ? new Recorder.FrameInfo(target) : null);
                        step.setPage(getTargetPage());
                        step.setFriendlyName(telerik_jsRecorder_findxs.buildFriendlyName(target));
                        telerik_jsRecorder_mediator.sendRecorderCommand({ command: "recordAction", data: step });
                        telerik_jsRecorder_mediator.sendRecorderCommand({ command: "showNotification", data: translation.notification });
                    }
                }
                function createEvent(type, name) {
                    let evt = tDoc.createEvent(type);
                    if (type === "MouseEvent") {
                        evt.initMouseEvent(name, true, true, parent.window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
                    }
                    else {
                        if (type === "KeyboardEvents") {
                        }
                        else {
                            evt.initEvent(name, true, true);
                        }
                    }
                    return evt;
                }
                function decodeTarget(encodedTarget) {
                    let s = encodedTarget.split(":");
                    return parent.document.getElementsByTagName(s[0])[s[1]];
                }
                function getTDoc() {
                    return tDoc;
                }
                TestStudio.getTDoc = getTDoc;
                function setTDoc(value) {
                    tDoc = value;
                }
                function getIsInputNumberStepUp() {
                    return isInputNumberStepUp;
                }
                TestStudio.getIsInputNumberStepUp = getIsInputNumberStepUp;
                function setIsInputNumberStepUp(value) {
                    isInputNumberStepUp = value;
                }
                function getIsInputNumberStepDown() {
                    return isInputNumberStepDown;
                }
                TestStudio.getIsInputNumberStepDown = getIsInputNumberStepDown;
                function setIsInputNumberStepDown(value) {
                    isInputNumberStepDown = value;
                }
                function getStartDragPoint() {
                    return startDragPoint;
                }
                TestStudio.getStartDragPoint = getStartDragPoint;
                function setStartDragPoint(value) {
                    startDragPoint = value;
                }
                function getDragDropWindowData() {
                    return dragDropWindowData;
                }
                TestStudio.getDragDropWindowData = getDragDropWindowData;
                function setDragDropWindowData(value) {
                    dragDropWindowData = value;
                }
                function getInitialized() {
                    return initialized;
                }
                TestStudio.getInitialized = getInitialized;
            })(TestStudio = Recorder.TestStudio || (Recorder.TestStudio = {}));
        })(Recorder = TestStudio_1.Recorder || (TestStudio_1.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            var LogSeverity;
            (function (LogSeverity) {
                LogSeverity[LogSeverity["INFO"] = 0] = "INFO";
                LogSeverity[LogSeverity["ERROR"] = 1] = "ERROR";
            })(LogSeverity = Common.LogSeverity || (Common.LogSeverity = {}));
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class Logger {
                static info(message) {
                    Logger.log(Common.LogSeverity[Common.LogSeverity.INFO], message);
                }
                static error(message) {
                    Logger.log(Common.LogSeverity[Common.LogSeverity.ERROR], message);
                }
                static log(level, message) {
                    let sb;
                    sb = `${Logger.getFormattedDate()} - `;
                    sb += `[${level}] `;
                    sb += message;
                    console.log(sb);
                }
                static getFormattedDate() {
                    let date = new Date();
                    let str = Logger.pad(date.getDate(), 2) + "/" + Logger.pad((date.getMonth() + 1), 2) + "/" + date.getFullYear()
                        + " " + Logger.pad(date.getHours(), 2) + ":" + Logger.pad(date.getMinutes(), 2) + ":"
                        + Logger.pad(date.getSeconds(), 2) + "." + Logger.pad(date.getMilliseconds(), 3);
                    return str;
                }
                static pad(num, size) {
                    let s = num + "";
                    while (s.length < size) {
                        s = "0" + s;
                    }
                    return s;
                }
            }
            Common.Logger = Logger;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class LoggerPageScript extends Common.Logger {
                static info(message) {
                    LoggerPageScript.log(Common.LogSeverity[Common.LogSeverity.INFO], message);
                }
                static error(message) {
                    LoggerPageScript.log(Common.LogSeverity[Common.LogSeverity.ERROR], message);
                }
                static log(level, message) {
                    let sb;
                    sb = `${Common.Logger.getFormattedDate()} - `;
                    sb += `[${level} - PAGE SCRIPT] `;
                    sb += message;
                    console.log(sb);
                    let logMsg = { message: "teststudio_v_2.log.message", data: sb };
                    window.postMessage(logMsg, "*");
                }
            }
            Common.LoggerPageScript = LoggerPageScript;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
let testStudioWsLogger = Telerik.TestStudio.Common.LoggerPageScript;
testStudioWsLogger.info("Loading recorder... ");
let telerik_jsRecorder_findxs = Telerik.TestStudio.Recorder.Findxs;
let telerik_jsRecorder_uiManager = Telerik.TestStudio.Recorder.UiManager;
telerik_jsRecorder_uiManager.init();
let telerik_jsRecorder_utils = Telerik.TestStudio.Recorder.Utils;
let telerik_jsRecorder_mediator = Telerik.TestStudio.Recorder.Mediator;
telerik_jsRecorder_mediator.init();
let telerik_jsRecorder_teststudio = Telerik.TestStudio.Recorder.TestStudio;
telerik_jsRecorder_teststudio.init();
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class Clauses {
                constructor(name, value, propertyName, type) {
                    this.compareType = 7;
                    this.trimChar = false;
                    this.value = value;
                    this.name = name;
                    this.propertyName = propertyName;
                    this.type = type;
                    if (value != undefined && value !== "") {
                        switch (value[0]) {
                            case "~":
                                this.trimChar = true;
                                this.compareType = 4;
                                break;
                            case "!":
                                this.trimChar = true;
                                this.compareType = 3;
                                break;
                            case "?":
                                this.trimChar = true;
                                this.compareType = 5;
                                break;
                            case "^":
                                this.trimChar = true;
                                this.compareType = 6;
                                break;
                            case "#":
                                this.trimChar = false;
                                this.compareType = 8;
                                break;
                            case "-":
                                this.trimChar = true;
                                this.compareType = 1;
                                break;
                            case "+":
                                this.trimChar = true;
                                this.compareType = 2;
                                break;
                            case "'":
                                this.trimChar = true;
                                break;
                            default:
                                break;
                        }
                        if (this.trimChar) {
                            this.value = value.substring(1);
                        }
                        if (this.compareType == 1 || this.compareType == 2) {
                            this.value = "";
                        }
                    }
                }
                stringCompare(a, b, compareType) {
                    switch (compareType) {
                        case 1:
                            return b == undefined || b === "";
                        case 2:
                            return !(b == undefined || b === "");
                        case 3:
                            return a.toLowerCase().indexOf(b.toLowerCase()) === -1;
                        case 4:
                            return a.toLowerCase().indexOf(b.toLowerCase()) !== -1;
                        case 5:
                            let lastIndex = a.toLowerCase().lastIndexOf(b.toLowerCase());
                            return lastIndex !== -1 && (lastIndex + b.length) === a.length;
                        case 6:
                            return a.toLowerCase().indexOf(b.toLowerCase()) === 0;
                        case 7:
                            return a.toLowerCase() == b.toLowerCase();
                        case 8:
                            let regex = new RegExp(b, "i");
                            return regex.test(a);
                        default:
                            break;
                    }
                    return false;
                }
                match(target) {
                    switch (this.type) {
                        case 0:
                            let actual = "";
                            if (target[this.propertyName]) {
                                actual = target[this.propertyName];
                            }
                            if (target.hasAttribute(this.propertyName)) {
                                actual = target.attributes[this.propertyName].nodeValue.toString();
                                if (this.propertyName === "id" || this.propertyName === "name" || this.propertyName === "href") {
                                    actual = telerik_jsRecorder_findxs.replaceAmp(actual);
                                }
                            }
                            if (actual === "") {
                                return false;
                            }
                            else {
                                return this.stringCompare(actual.toString(), this.value.toString(), this.compareType);
                            }
                        case 1:
                            if (!target.textContent || (target.textContent && target.textContent === "")) {
                                return false;
                            }
                            let contentToUse = telerik_jsRecorder_findxs.getElementTextContent(target);
                            if (contentToUse.length > telerik_jsRecorder_findxs.getMaxTextContentFind()) {
                                contentToUse = telerik_jsRecorder_findxs.getStartsWith + contentToUse.substr(0, telerik_jsRecorder_findxs.getMaxTextContentFind());
                            }
                            return this.stringCompare(contentToUse, this.value, this.compareType);
                        case 2:
                            let val = target.tagName.toLowerCase() + ":"
                                + telerik_jsRecorder_findxs.buildIndexAccordingToParentBasedTree(target.ownerDocument, target).toString();
                            return this.stringCompare(val, this.value, this.compareType);
                        case 3:
                            return this.stringCompare(telerik_jsRecorder_findxs.generateXPath(target), this.value, this.compareType);
                        case 4:
                            return this.stringCompare(target.tagName.toLowerCase(), this.value, this.compareType);
                        default:
                            break;
                    }
                    return false;
                }
                getValue() {
                    return this.value;
                }
                setValue(value) {
                    this.value = value;
                }
                getName() {
                    return this.name;
                }
                setName(value) {
                    this.name = value;
                }
                getType() {
                    return this.type;
                }
                setType(value) {
                    this.type = value;
                }
            }
            Recorder.Clauses = Clauses;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class Param {
                constructor(paramBuilder) {
                    this.canEdit = paramBuilder.getCanEdit();
                    this.select = paramBuilder.getSelect();
                    this.defaultValue = paramBuilder.getDefaultValue();
                    this.valueType = paramBuilder.getValueType();
                }
                getCanEdit() {
                    return this.canEdit;
                }
                setCanEdit(value) {
                    this.canEdit = value;
                }
                getSelect() {
                    return this.select;
                }
                setSelect(value) {
                    this.select = value;
                }
                getDefaultValue() {
                    return this.defaultValue;
                }
                setDefaultValue(value) {
                    this.defaultValue = value;
                }
                getValueType() {
                    return this.valueType;
                }
                setValueType(value) {
                    this.valueType = value;
                }
            }
            Recorder.Param = Param;
            class ParamBuilder {
                build() {
                    return new Param(this);
                }
                setCanEdit(value) {
                    this.canEdit = value;
                    return this;
                }
                setSelect(select) {
                    this.select = select;
                    return this;
                }
                setDefaultValue(defaultValue) {
                    this.defaultValue = defaultValue;
                    return this;
                }
                setValueType(value) {
                    this.valueType = value;
                    return this;
                }
                getCanEdit() {
                    return this.canEdit;
                }
                getSelect() {
                    return this.select;
                }
                getDefaultValue() {
                    return this.defaultValue;
                }
                getValueType() {
                    return this.valueType;
                }
            }
            Recorder.ParamBuilder = ParamBuilder;
            function BoolSelectParam(defaultValue) {
                return new ParamBuilder().setSelect([{ display: "True", value: true }, { display: "False", value: false }])
                    .setDefaultValue(defaultValue)
                    .setCanEdit(false)
                    .build();
            }
            function StringCompareSelectParam() {
                return new ParamBuilder().setSelect([{ display: "Exact", value: 0 },
                    { display: "Same", value: 1 },
                    { display: "Contains", value: 2 },
                    { display: "Does not contain", value: 3 },
                    { display: "Starts with", value: 4 },
                    { display: "Ends with", value: 5 },
                    { display: "RegEx", value: 6 }])
                    .setDefaultValue(0)
                    .setCanEdit(false)
                    .build();
            }
            function IntCompareSelectParam() {
                return new ParamBuilder().setSelect([{ display: "Equals", value: 0 },
                    { display: "Less Than", value: 1 },
                    { display: "Greater Than", value: 2 },
                    { display: "Less Than Or Equal", value: 3 },
                    { display: "Greater Than Or Equal", value: 4 },
                    { display: "Not Equal", value: 5 }])
                    .setDefaultValue(0)
                    .setCanEdit(false)
                    .build();
            }
            function SingleValueParam(defaultValue, valueType) {
                return new ParamBuilder().setDefaultValue(defaultValue)
                    .setValueType(valueType)
                    .setCanEdit(true)
                    .build();
            }
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class Test {
                constructor(jsonObj) {
                    this.name = "(NewTest)";
                    this.steps = [];
                    this.name = jsonObj.name;
                    this.steps = jsonObj.steps;
                }
                addStep(step) {
                    this.steps.push(step);
                }
                numOfSteps() {
                    return this.steps.length;
                }
                getName() {
                    return this.name;
                }
                setName(value) {
                    this.name = value;
                }
                getSteps() {
                    return this.steps;
                }
                setSteps(value) {
                    this.steps = value;
                }
            }
            Recorder.Test = Test;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
