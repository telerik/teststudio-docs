var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class PaddingOffset {
                constructor(leftPadding, topPadding) {
                    this.leftPadding = leftPadding;
                    this.topPadding = topPadding;
                }
            }
            Common.PaddingOffset = PaddingOffset;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class Rectangle {
                constructor(left, top, width, height, right, bottom) {
                    this.left = left;
                    this.top = top;
                    this.width = width;
                    this.height = height;
                    this.right = right;
                    this.bottom = bottom;
                }
                static createFromClientRect(clientRect) {
                    return new Rectangle(clientRect.left, clientRect.top, clientRect.width, clientRect.height, clientRect.right, clientRect.bottom);
                }
                toString() {
                    return `${this.left},${this.top},${this.width},${this.height}`;
                }
            }
            Common.Rectangle = Rectangle;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class FramesUtils {
                static buildFlatFramesCollection(frame) {
                    let flatFramesColletion = [];
                    FramesUtils.buildFrames(frame, flatFramesColletion);
                    return flatFramesColletion;
                }
                static buildFramesInfo(framesCollection) {
                    let framesInfo = "";
                    for (let i = 0; i < framesCollection.length; ++i) {
                        let frameElement = framesCollection[i].frameElement;
                        if (frameElement != null) {
                            framesInfo += i;
                            framesInfo += "-@-";
                            framesInfo += frameElement.name;
                            framesInfo += "-@-";
                            framesInfo += frameElement.id;
                            framesInfo += "-@-";
                            framesInfo += frameElement.src;
                            framesInfo += "-@-";
                            let frameRect = FramesUtils.getFrameRectangle(frameElement);
                            framesInfo += frameRect.toString();
                            framesInfo += "-@-";
                            framesInfo += "-@-";
                            framesInfo += frameElement.tagName;
                            framesInfo += "-@-";
                            framesInfo += framesCollection[i].frameIndexRaw;
                            framesInfo += "-@-";
                            if (frameElement.hasAttribute("testStudioTag")) {
                                framesInfo += frameElement.getAttribute("testStudioTag");
                            }
                            framesInfo += "**;**";
                        }
                        else {
                            framesInfo += "**;**";
                        }
                    }
                    return framesInfo;
                }
                static getFrameRectangle(frameElement) {
                    let frameRect = frameElement.getBoundingClientRect();
                    let parentElement = frameElement.__webaii_parentWindow.frameElement;
                    let left = frameRect.left;
                    let top = frameRect.top;
                    while (parentElement != undefined) {
                        let parentRect = parentElement.getBoundingClientRect();
                        left += parentRect.left;
                        top += parentRect.top;
                        parentElement = parentElement.__webaii_parentWindow.frameElement;
                    }
                    return new Common.Rectangle(left, top, frameRect.width, frameRect.height, left + frameRect.width, top + frameRect.height);
                }
                static getFramePaddingOffset(targetFrameElement) {
                    let tp;
                    let lp;
                    try {
                        if (window.jQuery != undefined) {
                            lp = jQuery(targetFrameElement).css("padding-left") ? parseInt(jQuery(targetFrameElement).css("padding-left"), 10) : 0;
                            tp = jQuery(targetFrameElement).css("padding-top") ? parseInt(jQuery(targetFrameElement).css("padding-top"), 10) : 0;
                        }
                        else {
                            lp = targetFrameElement.style.paddingLeft ? parseInt(targetFrameElement.style.paddingLeft, 10) : 0;
                            tp = targetFrameElement.style.paddingTop ? parseInt(targetFrameElement.style.paddingTop, 10) : 0;
                        }
                    }
                    catch (ex) {
                        lp = targetFrameElement.style.paddingLeft ? parseInt(targetFrameElement.style.paddingLeft, 10) : 0;
                        tp = targetFrameElement.style.paddingTop ? parseInt(targetFrameElement.style.paddingTop, 10) : 0;
                    }
                    return new Common.PaddingOffset(lp, tp);
                }
                static buildFrames(parentWindow, flatFramesCollection) {
                    try {
                        if (parentWindow != undefined && parentWindow.frames != undefined && parentWindow.frames.length > 0) {
                            let count = parentWindow.frames.length;
                            for (let i = 0; i < count; ++i) {
                                let frame = parentWindow.frames[i];
                                if (frame == null || frame.frameElement == null) {
                                    continue;
                                }
                                let rect = frame.frameElement.getBoundingClientRect();
                                if (rect != null && rect.width > 0 && rect.height > 0) {
                                    frame.frameIndexRaw = i;
                                    flatFramesCollection[flatFramesCollection.length] = frame;
                                }
                                if (frame.frameElement != undefined) {
                                    frame.frameElement.__webaii_parentWindow = parentWindow;
                                    if (frame.frames.length > 0) {
                                        FramesUtils.buildFrames(frame, flatFramesCollection);
                                    }
                                }
                            }
                        }
                    }
                    catch (err) {
                        if (err.name !== "SecurityError") {
                            throw "BuildFrames().Error: " + err;
                        }
                    }
                }
            }
            Common.FramesUtils = FramesUtils;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Foreground;
        (function (Foreground) {
            class CommmandProcessor {
                getElement(doc, tagName, index) {
                    return doc.getElementsByTagName(tagName)[index];
                }
                getCommandExecutionContext(command) {
                    return new Foreground.CommandExecutionContext(command, TestStudio.Common.FramesUtils.buildFlatFramesCollection(window));
                }
            }
            Foreground.CommmandProcessor = CommmandProcessor;
        })(Foreground = TestStudio.Foreground || (TestStudio.Foreground = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Foreground;
        (function (Foreground) {
            class ActionCommmandProcessor extends Foreground.CommmandProcessor {
                constructor() {
                    super(...arguments);
                    this.eventHandlers = {};
                }
                processCommand(command) {
                    let executionContext = this.getCommandExecutionContext(command);
                    switch (command.ActionType) {
                        case TestStudio.Common.Enums.BrowserActionType.Click: {
                            let target = this.getElement(executionContext.document, command.Target.TagName, command.Target.OccurrenceIndex);
                            let mouseEventInit = {
                                bubbles: true,
                                cancelable: true,
                                view: executionContext.window,
                                detail: 1,
                                screenX: 0,
                                screenY: 0,
                                clientX: 0,
                                clientY: 0,
                                ctrlKey: false,
                                altKey: false,
                                shiftKey: false,
                                metaKey: false,
                                button: 0,
                                relatedTarget: null
                            };
                            let clickEvent = new MouseEvent("click", mouseEventInit);
                            window.setTimeout(function () { target.dispatchEvent(clickEvent); }, 1);
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.SetText: {
                            let target = this.getElement(executionContext.document, command.Target.TagName, command.Target.OccurrenceIndex);
                            target.value = command.Data;
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.SelectDropDown: {
                            let target = this.getElement(executionContext.document, command.Target.TagName, command.Target.OccurrenceIndex);
                            this.selectDropDown(target, command.Data);
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.Check: {
                            let target = this.getElement(executionContext.document, command.Target.TagName, command.Target.OccurrenceIndex);
                            target.checked = this.toBoolean(command.Data);
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.ScrollToVisible: {
                            let target = this.getElement(executionContext.document, command.Target.TagName, command.Target.OccurrenceIndex);
                            target.scrollIntoView(command.Data === "1");
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.NavigateTo: {
                            window.location.href = command.Data;
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.InvokeEvent: {
                            let event;
                            let endEventNameIndex = command.Data.indexOf("--@@--");
                            let eventName = command.Data.substring(0, endEventNameIndex);
                            if (eventName.substring(0, 2) === "on") {
                                eventName = eventName.substring(2);
                            }
                            let eventObjJSON = command.Data.substring(endEventNameIndex + "--@@--".length);
                            let eventObj = JSON.parse(eventObjJSON);
                            let eventType = "HTMLEvents";
                            if (eventName.substring(0, 3) === "key") {
                                eventType = "KeyboardEvent";
                            }
                            else if (eventName.substring(0, 5) === "mouse" || eventName === "click" || eventName === "dblclick") {
                                eventType = "MouseEvents";
                            }
                            let altKey = false;
                            let ctrlKey = false;
                            let shiftKey = false;
                            let metaKey = false;
                            if (eventType === "HTMLEvents" || !eventObj) {
                                event = executionContext.document.createEvent(eventType);
                                event.initEvent(eventName, true, true);
                            }
                            else {
                                if (eventObj.modifiers & 0x01) {
                                    altKey = true;
                                }
                                if (eventObj.modifiers & 0x02) {
                                    ctrlKey = true;
                                }
                                if (eventObj.modifiers & 0x04) {
                                    shiftKey = true;
                                }
                                if (eventObj.modifiers & 0x08) {
                                    metaKey = true;
                                }
                                if (eventType === "MouseEvents") {
                                    let button = 0;
                                    if (eventObj.button & 1) {
                                        button = 0;
                                    }
                                    else if (eventObj.button & 2) {
                                        button = 2;
                                    }
                                    else if (eventObj.button & 4) {
                                        button = 1;
                                    }
                                    let relatedTarget;
                                    if (eventObj.relatedTarget) {
                                        relatedTarget = TestStudio.Common.run(eventObj.relatedTarget, executionContext.window);
                                    }
                                    let mouseEventInit = {
                                        bubbles: true,
                                        cancelable: true,
                                        view: executionContext.window,
                                        detail: 0,
                                        screenX: eventObj.screenX,
                                        screenY: eventObj.screenY,
                                        clientX: 0,
                                        clientY: 0,
                                        ctrlKey: ctrlKey,
                                        altKey: altKey,
                                        shiftKey: shiftKey,
                                        metaKey: metaKey,
                                        button: button,
                                        relatedTarget: relatedTarget
                                    };
                                    event = new MouseEvent(eventName, mouseEventInit);
                                }
                                else if (eventType === "KeyboardEvent") {
                                    let keyCode = eventObj.keyCode;
                                    let keyEventInit = {
                                        bubbles: true,
                                        cancelable: true,
                                        view: executionContext.window,
                                        detail: 0,
                                        key: keyCode,
                                        ctrlKey: ctrlKey,
                                        altKey: altKey,
                                        shiftKey: shiftKey,
                                        metaKey: metaKey
                                    };
                                    event = new KeyboardEvent(eventName, keyEventInit);
                                }
                            }
                            if (event == null) {
                                throw "Error creating event";
                            }
                            let target = this.getElement(executionContext.document, command.Target.TagName, command.Target.OccurrenceIndex);
                            target.dispatchEvent(event);
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.InvokeJsFunction: {
                            let result = TestStudio.Common.run(command.Data, executionContext.window);
                            if (result == null) {
                                command.Response = null;
                            }
                            else {
                                command.Response = result.toString();
                            }
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.Refresh: {
                            window.location.reload();
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.GoBack: {
                            history.go(-1);
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.GoForward: {
                            history.go(1);
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.LoadString: {
                            command.InError = true;
                            command.Response = "LoadString command not supported for WebKit browsers";
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.GetProperty: {
                            command.InError = true;
                            command.Response = "GetProperty should not be used";
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.SetProperty: {
                            command.InError = true;
                            command.Response = "SetProperty should not be used";
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.InvokeMethod: {
                            command.InError = true;
                            command.Response = "InvokeMethod should not be used";
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.SetCookie: {
                            command.InError = true;
                            command.Response = "SetCookie should not be handled here";
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.ScrollBy: {
                            let coords = command.Data.split(";");
                            executionContext.window.scrollBy(parseInt(coords[0], 10), parseInt(coords[1], 19));
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.Stop: {
                            command.InError = true;
                            command.Response = "Stop not implemented";
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.ClearHistory: {
                            command.InError = true;
                            command.Response = "ClearHistory not supported";
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.ClearFilesCache: {
                            command.InError = true;
                            command.Response = "ClearFilesCache not supported";
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.ClearCookies: {
                            command.InError = true;
                            command.Response = "ClearCookies not supported";
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.InvokeJsFunctionReturnJSON: {
                            let result = TestStudio.Common.run(command.Data, executionContext.window);
                            command.Response = JSON.stringify(result);
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.AttachEventHandler: {
                            let splitIndex = command.Data.indexOf("--@@--");
                            let eventUuid = command.Data.substring(splitIndex + 6);
                            let eventName = command.Data.substring(0, splitIndex);
                            let target = this.getElement(executionContext.document, command.Target.TagName, command.Target.OccurrenceIndex);
                            if (target == null) {
                                throw "Unable to find target element";
                            }
                            let handler = function (e) {
                                let jem = ({
                                    type: e.type,
                                    charCode: 0,
                                    clientX: 0,
                                    clientY: 0,
                                    guid: eventUuid,
                                    keyCode: 0,
                                    modifierKeys: 0,
                                    screenX: 0,
                                    screenY: 0
                                });
                                if (e.charCode) {
                                    jem.charCode = e.charCode;
                                }
                                if (e.clientX) {
                                    jem.clientX = e.clientX;
                                }
                                if (e.clientY) {
                                    jem.clientY = e.clientY;
                                }
                                if (e.keyCode) {
                                    jem.keyCode = e.keyCode;
                                }
                                if (e.altKey) {
                                    jem.modifierKeys = jem.modifierKeys | 0x01;
                                }
                                if (e.ctrlKey) {
                                    jem.modifierKeys = jem.modifierKeys | 0x02;
                                }
                                if (e.shiftKey) {
                                    jem.modifierKeys = jem.modifierKeys | 0x04;
                                }
                                if (e.metaKey) {
                                    jem.modifierKeys = jem.modifierKeys | 0x08;
                                }
                                if (e.screenX) {
                                    jem.screenX = e.screenX;
                                }
                                if (e.screenY) {
                                    jem.screenY = e.screenY;
                                }
                                window.postMessage({ message: "teststudio_v_2.exec.dispatchJsEvent", data: jem }, "*");
                            };
                            target.addEventListener(eventName, handler, false);
                            this.eventHandlers[eventUuid] = { target: target, name: eventName, handler: handler };
                            command.Response = true;
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.RemoveEventHandler: {
                            let splitIndex = command.Data.indexOf("--@@--");
                            let eventName = command.Data.substring(0, splitIndex);
                            let eventId = command.Data.substring(splitIndex + 6);
                            let token = this.eventHandlers[eventId];
                            if (token != undefined) {
                                token.target.removeEventListener(token.name, token.handler, false);
                                delete this.eventHandlers[eventId];
                            }
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.CloseWindow: {
                            window.postMessage({ message: "teststudio.exec.windowClose", data: null }, "*");
                            setTimeout(() => {
                                window.open("", "_self", "");
                                window.close();
                            }, 100);
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.GetFramePadding: {
                            let frameIndex = parseInt(command.Data, 10);
                            let frame = executionContext.frames[frameIndex];
                            let result = TestStudio.Common.FramesUtils.getFramePaddingOffset(frame.frameElement);
                            command.Response = result.leftPadding + "--@@--" + result.topPadding;
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.TagIndexFromClientRectangle: {
                            const coords = command.Data.split(",");
                            command.Response = this.getTagIndexFromClientRectangle(executionContext.document, parseInt(coords[0], 10), parseInt(coords[1], 10), parseInt(coords[2], 10), parseInt(coords[3], 10), parseInt(coords[4], 10), parseInt(coords[5], 10));
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.ViewPortAndScrollSize: {
                            const clientWidth = Math.min(executionContext.document.documentElement.clientWidth, executionContext.window.innerWidth);
                            const clientHeight = Math.min(executionContext.document.documentElement.clientHeight, executionContext.window.innerHeight);
                            const scrollWidth = executionContext.document.documentElement.scrollWidth;
                            const scrollHeight = executionContext.document.documentElement.scrollHeight;
                            command.Response = clientWidth + ":" + clientHeight + ":" + scrollWidth + ":" + scrollHeight;
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserActionType.ScrollToDocumentCoordinates: {
                            const coords = command.Data.split(",");
                            executionContext.window.scrollTo(parseInt(coords[0], 10), parseInt(coords[1], 10));
                            command.Response = Math.round(executionContext.window.pageXOffset) + ":" +
                                Math.round(executionContext.window.pageYOffset);
                            break;
                        }
                        default: {
                            command.InError = true;
                            command.Response = "Unknown action " + command.ActionType;
                            break;
                        }
                    }
                    return command;
                }
                getTagIndexFromClientRectangle(doc, x, y, width, height, offsetX, offsetY) {
                    const elem = this.findElementByRect(doc, x, y, width, height, offsetX, offsetY);
                    return this.elementToTagAndIndex(doc, elem);
                }
                reactangleWithIn(rect, rX, rY, rWidth, rHeight) {
                    return rect.left >= rX &&
                        rect.top >= rY &&
                        rect.left + rect.width <= rX + rWidth &&
                        rect.top + rect.height <= rY + rHeight;
                }
                findElementByRect(doc, x, y, width, height, xOffset, yOffset) {
                    const midPntX = x + width / 2 + xOffset;
                    const midPntY = y + height / 2 + yOffset;
                    let bestFind = doc.elementFromPoint(midPntX, midPntY);
                    let element = null;
                    let areaToBeat = 0;
                    if (bestFind) {
                        element = bestFind.parentElement;
                        const rect = bestFind.getClientRects()[0];
                        areaToBeat = rect.width * rect.height;
                    }
                    while (element) {
                        const rects = element.getClientRects();
                        if (!rects) {
                            break;
                        }
                        for (const rect of rects) {
                            const area = rect.width * rect.height;
                            if (this.reactangleWithIn(rect, x, y, width, height) && areaToBeat < area) {
                                areaToBeat = area;
                                bestFind = element;
                                break;
                            }
                        }
                        element = element.parentElement;
                    }
                    return bestFind;
                }
                elementToTagAndIndex(doc, element) {
                    if (!element) {
                        return null;
                    }
                    const elementsByTagName = doc.getElementsByTagName(element.tagName);
                    for (let ii = 0; ii < elementsByTagName.length; ii++) {
                        if (elementsByTagName[ii] === element) {
                            return element.tagName + ":" + ii;
                        }
                    }
                }
                selectDropDown(target, optionString) {
                    let selectionType = optionString[0];
                    let selectionValue = optionString.slice(2);
                    let selectionValueFound = false;
                    if (selectionType === "V") {
                        for (let i = 0; i < target.length; i++) {
                            if (target.options[i].value === selectionValue) {
                                selectionValueFound = true;
                                target.selectedIndex = i;
                                break;
                            }
                        }
                    }
                    else if (selectionType === "T") {
                        for (let i = 0; i < target.length; i++) {
                            if (target.options[i].text === selectionValue) {
                                selectionValueFound = true;
                                target.selectedIndex = i;
                                break;
                            }
                        }
                    }
                    else if (selectionType === "I") {
                        let index = parseInt(selectionValue, 10);
                        if (isNaN(index) || target.length < 1 || (target.length - 1) < index) {
                            throw "SelectDropDown(): DropDown has either zero items to select or less items than the desired index!";
                        }
                        selectionValueFound = true;
                        target.selectedIndex = index;
                    }
                    if (!selectionValueFound) {
                        throw "SelectDropDown(): DropDown was unable to find the " +
                            selectionType === "T" ? "text" : "value" + " '" + selectionValue + "' in the dropdown requested.";
                    }
                }
                toBoolean(boolString) {
                    return boolString.toLowerCase() === "true";
                }
            }
            Foreground.ActionCommmandProcessor = ActionCommmandProcessor;
        })(Foreground = TestStudio.Foreground || (TestStudio.Foreground = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Foreground;
        (function (Foreground) {
            class CommandExecutionContext {
                constructor(command, frames) {
                    this.frames = frames;
                    if (command.TargetFrameIndex === -1) {
                        this.window = window;
                        this.document = document;
                    }
                    else if (command.TargetFrameIndex <= this.frames.length - 1) {
                        this.window = this.frames[command.TargetFrameIndex];
                        this.document = this.window.document;
                    }
                }
            }
            Foreground.CommandExecutionContext = CommandExecutionContext;
        })(Foreground = TestStudio.Foreground || (TestStudio.Foreground = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            var Enums;
            (function (Enums) {
                let BrowserCommandType;
                (function (BrowserCommandType) {
                    BrowserCommandType[BrowserCommandType["Information"] = 1] = "Information";
                    BrowserCommandType[BrowserCommandType["Action"] = 2] = "Action";
                    BrowserCommandType[BrowserCommandType["Silverlight"] = 3] = "Silverlight";
                    BrowserCommandType[BrowserCommandType["Config"] = 4] = "Config";
                })(BrowserCommandType = Enums.BrowserCommandType || (Enums.BrowserCommandType = {}));
            })(Enums = Common.Enums || (Common.Enums = {}));
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Foreground;
        (function (Foreground) {
            class InformationCommmandProcessor extends Foreground.CommmandProcessor {
                processCommand(command) {
                    let executionContext = this.getCommandExecutionContext(command);
                    switch (command.InformationType) {
                        case TestStudio.Common.Enums.BrowserInformationType.ElementRectangle: {
                            let target = this.getElement(executionContext.document, command.Target.TagName, command.Target.OccurrenceIndex);
                            let rect = TestStudio.Common.Rectangle.createFromClientRect(target.getBoundingClientRect());
                            command.Response = rect.toString();
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserInformationType.FrameRectangle: {
                            let frameRect = TestStudio.Common.FramesUtils.getFrameRectangle(executionContext.window.frameElement);
                            command.Response = frameRect.toString();
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserInformationType.DocumentMarkup: {
                            command.Response = this.getDocumentMarkup(executionContext.document);
                            if (executionContext.frames.length > 0 && command.TargetFrameIndex === -1) {
                                command.HasFrames = true;
                                command.FramesInfo = TestStudio.Common.FramesUtils.buildFramesInfo(executionContext.frames);
                            }
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserInformationType.IsReady: {
                            command.Response = executionContext.document != null &&
                                (executionContext.document.readyState === "complete" || executionContext.document.readyState === "interactive");
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserInformationType.Cookies: {
                            command.Response = executionContext.document.cookie;
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserInformationType.ComputedStyle: {
                            let target = this.getElement(executionContext.document, command.Target.TagName, command.Target.OccurrenceIndex);
                            let styles = executionContext.window.getComputedStyle(target);
                            command.Response = styles[command.Data];
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserInformationType.QuerySelector: {
                            let element = executionContext.document.querySelector(command.Data);
                            let result = "";
                            if (element != null) {
                                const elementsByTagName = executionContext.document.getElementsByTagName(element.tagName);
                                for (let i = 0; i < elementsByTagName.length; i++) {
                                    if (elementsByTagName[i] === element) {
                                        result = element.tagName + ":" + i;
                                        break;
                                    }
                                }
                            }
                            command.Response = result;
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserInformationType.QuerySelectorAll: {
                            let elementsFound = executionContext.document.querySelectorAll(command.Data);
                            let result = [];
                            for (let i = 0; i < elementsFound.length; i++) {
                                const elementsByTagName = executionContext.document.getElementsByTagName(elementsFound[i].tagName);
                                for (let j = 0; j < elementsByTagName.length; j++) {
                                    if (elementsByTagName[j] === elementsFound[i]) {
                                        result.push(elementsFound[i].tagName + ":" + j);
                                        break;
                                    }
                                }
                            }
                            command.Response = JSON.stringify(result);
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserInformationType.JSConsoleErrors: {
                            command.Response = JSON.stringify(window.TS_JS_Console_Errors || {});
                            break;
                        }
                        case TestStudio.Common.Enums.BrowserInformationType.GetScrollPosition: {
                            command.Response = Math.round(executionContext.window.pageXOffset) + ":" +
                                Math.round(executionContext.window.pageYOffset);
                            break;
                        }
                        default: {
                            command.InError = true;
                            command.Response = `InformationType ${command.InformationType} not implemented`;
                            break;
                        }
                    }
                    return command;
                }
                getDocumentMarkup(doc) {
                    return `${doc.URL}@@URL@@${doc.documentElement.outerHTML}`;
                }
            }
            Foreground.InformationCommmandProcessor = InformationCommmandProcessor;
        })(Foreground = TestStudio.Foreground || (TestStudio.Foreground = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Foreground;
        (function (Foreground) {
            class SilverlightCommmandProcessor extends Foreground.CommmandProcessor {
                processCommand(command) {
                    let executionContext = this.getCommandExecutionContext(command);
                    let element = executionContext.document.getElementsByTagName(command.Target.TagName)[command.Target.OccurrenceIndex];
                    command.Response = element.content._webaiiSlCient.ProcessCommand(command.Data);
                    return command;
                }
            }
            Foreground.SilverlightCommmandProcessor = SilverlightCommmandProcessor;
        })(Foreground = TestStudio.Foreground || (TestStudio.Foreground = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Foreground;
        (function (Foreground) {
            class NotImplementedCommmandProcessor extends Foreground.CommmandProcessor {
                processCommand(command) {
                    command.InError = true;
                    command.Response = `BrowserCommandType ${command.CommandType} not implemented`;
                    return command;
                }
            }
            Foreground.NotImplementedCommmandProcessor = NotImplementedCommmandProcessor;
        })(Foreground = TestStudio.Foreground || (TestStudio.Foreground = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Foreground;
        (function (Foreground) {
            class CommandProcessorFactory {
                constructor() {
                    this.commandProcessors = {};
                }
                createCommandProcessor(commandType) {
                    switch (commandType) {
                        case TestStudio.Common.Enums.BrowserCommandType.Information:
                            if (this.commandProcessors[commandType] == undefined) {
                                this.commandProcessors[commandType] = new Foreground.InformationCommmandProcessor();
                            }
                            return this.commandProcessors[commandType];
                        case TestStudio.Common.Enums.BrowserCommandType.Action:
                            if (this.commandProcessors[commandType] == undefined) {
                                this.commandProcessors[commandType] = new Foreground.ActionCommmandProcessor();
                            }
                            return this.commandProcessors[commandType];
                        case TestStudio.Common.Enums.BrowserCommandType.Silverlight:
                            if (this.commandProcessors[commandType] == undefined) {
                                this.commandProcessors[commandType] = new Foreground.SilverlightCommmandProcessor();
                            }
                            return this.commandProcessors[commandType];
                        default:
                            if (this.commandProcessors[commandType] == undefined) {
                                this.commandProcessors[commandType] = new Foreground.NotImplementedCommmandProcessor();
                            }
                            return this.commandProcessors[commandType];
                    }
                }
            }
            Foreground.CommandProcessorFactory = CommandProcessorFactory;
        })(Foreground = TestStudio.Foreground || (TestStudio.Foreground = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            var Enums;
            (function (Enums) {
                let BrowserActionType;
                (function (BrowserActionType) {
                    BrowserActionType[BrowserActionType["Click"] = 1] = "Click";
                    BrowserActionType[BrowserActionType["SetText"] = 2] = "SetText";
                    BrowserActionType[BrowserActionType["SelectDropDown"] = 3] = "SelectDropDown";
                    BrowserActionType[BrowserActionType["Check"] = 4] = "Check";
                    BrowserActionType[BrowserActionType["ScrollToVisible"] = 5] = "ScrollToVisible";
                    BrowserActionType[BrowserActionType["NavigateTo"] = 6] = "NavigateTo";
                    BrowserActionType[BrowserActionType["InvokeEvent"] = 7] = "InvokeEvent";
                    BrowserActionType[BrowserActionType["InvokeJsFunction"] = 8] = "InvokeJsFunction";
                    BrowserActionType[BrowserActionType["Refresh"] = 9] = "Refresh";
                    BrowserActionType[BrowserActionType["GoBack"] = 10] = "GoBack";
                    BrowserActionType[BrowserActionType["GoForward"] = 11] = "GoForward";
                    BrowserActionType[BrowserActionType["LoadString"] = 12] = "LoadString";
                    BrowserActionType[BrowserActionType["GetProperty"] = 13] = "GetProperty";
                    BrowserActionType[BrowserActionType["SetProperty"] = 14] = "SetProperty";
                    BrowserActionType[BrowserActionType["InvokeMethod"] = 15] = "InvokeMethod";
                    BrowserActionType[BrowserActionType["SetCookie"] = 16] = "SetCookie";
                    BrowserActionType[BrowserActionType["ScrollBy"] = 18] = "ScrollBy";
                    BrowserActionType[BrowserActionType["Stop"] = 19] = "Stop";
                    BrowserActionType[BrowserActionType["ClearHistory"] = 20] = "ClearHistory";
                    BrowserActionType[BrowserActionType["ClearFilesCache"] = 21] = "ClearFilesCache";
                    BrowserActionType[BrowserActionType["ClearCookies"] = 23] = "ClearCookies";
                    BrowserActionType[BrowserActionType["InvokeJsFunctionReturnJSON"] = 24] = "InvokeJsFunctionReturnJSON";
                    BrowserActionType[BrowserActionType["AttachEventHandler"] = 25] = "AttachEventHandler";
                    BrowserActionType[BrowserActionType["RemoveEventHandler"] = 26] = "RemoveEventHandler";
                    BrowserActionType[BrowserActionType["AddCustomSilverlightAssembly"] = 29] = "AddCustomSilverlightAssembly";
                    BrowserActionType[BrowserActionType["CloseWindow"] = 30] = "CloseWindow";
                    BrowserActionType[BrowserActionType["GetFramePadding"] = 31] = "GetFramePadding";
                    BrowserActionType[BrowserActionType["SwitchTab"] = 32] = "SwitchTab";
                    BrowserActionType[BrowserActionType["TagIndexFromClientRectangle"] = 33] = "TagIndexFromClientRectangle";
                    BrowserActionType[BrowserActionType["ViewPortAndScrollSize"] = 34] = "ViewPortAndScrollSize";
                    BrowserActionType[BrowserActionType["ScrollToDocumentCoordinates"] = 35] = "ScrollToDocumentCoordinates";
                })(BrowserActionType = Enums.BrowserActionType || (Enums.BrowserActionType = {}));
            })(Enums = Common.Enums || (Common.Enums = {}));
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            var Enums;
            (function (Enums) {
                let BrowserInformationType;
                (function (BrowserInformationType) {
                    BrowserInformationType[BrowserInformationType["ElementRectangle"] = 1] = "ElementRectangle";
                    BrowserInformationType[BrowserInformationType["FrameRectangle"] = 2] = "FrameRectangle";
                    BrowserInformationType[BrowserInformationType["DocumentMarkup"] = 4] = "DocumentMarkup";
                    BrowserInformationType[BrowserInformationType["IsReady"] = 5] = "IsReady";
                    BrowserInformationType[BrowserInformationType["Cookies"] = 6] = "Cookies";
                    BrowserInformationType[BrowserInformationType["ComputedStyle"] = 7] = "ComputedStyle";
                    BrowserInformationType[BrowserInformationType["InformationBar"] = 10] = "InformationBar";
                    BrowserInformationType[BrowserInformationType["QuerySelectorAll"] = 11] = "QuerySelectorAll";
                    BrowserInformationType[BrowserInformationType["QuerySelector"] = 12] = "QuerySelector";
                    BrowserInformationType[BrowserInformationType["JSConsoleErrors"] = 13] = "JSConsoleErrors";
                    BrowserInformationType[BrowserInformationType["GetScrollPosition"] = 14] = "GetScrollPosition";
                })(BrowserInformationType = Enums.BrowserInformationType || (Enums.BrowserInformationType = {}));
            })(Enums = Common.Enums || (Common.Enums = {}));
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class Command {
                constructor(command) {
                    this.TargetFrameIndex = parseInt(command.TargetFrameIndex, 10);
                    this.TargetFrameId = command.TargetFrameId;
                    this.InError = command.InError;
                    this.Handled = command.Handled;
                    this.IsDialog = command.IsDialog;
                    this.HasFrames = command.HasFrames;
                    this.FramesInfo = command.FramesInfo;
                    this.Response = command.Response;
                    this.CommandType = command.CommandType;
                    this.InformationType = command.InformationType;
                    this.ActionType = command.ActionType;
                    this.Target = command.Target;
                    this.ClientId = command.ClientId;
                    this.RequestId = command.RequestId;
                    this.Cookies = command.Cookies;
                    this.Data = command.Data;
                }
            }
            Common.Command = Command;
            function cloneCommand(command) {
                return JSON.parse(JSON.stringify(command));
            }
            Common.cloneCommand = cloneCommand;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            function run(func, contextWindow) {
                contextWindow = contextWindow || window;
                return contextWindow.eval(func);
            }
            Common.run = run;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            let LogSeverity;
            (function (LogSeverity) {
                LogSeverity[LogSeverity["INFO"] = 0] = "INFO";
                LogSeverity[LogSeverity["ERROR"] = 1] = "ERROR";
            })(LogSeverity = Common.LogSeverity || (Common.LogSeverity = {}));
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class Logger {
                static info(message) {
                    Logger.log(Common.LogSeverity[Common.LogSeverity.INFO], message);
                }
                static error(message) {
                    Logger.log(Common.LogSeverity[Common.LogSeverity.ERROR], message);
                }
                static log(level, message) {
                    let sb;
                    sb = `${Logger.getFormattedDate()} - `;
                    sb += `[${level}] `;
                    sb += message;
                    console.log(sb);
                }
                static getFormattedDate() {
                    let date = new Date();
                    let str = Logger.pad(date.getDate(), 2) + "/" + Logger.pad((date.getMonth() + 1), 2) + "/" + date.getFullYear()
                        + " " + Logger.pad(date.getHours(), 2) + ":" + Logger.pad(date.getMinutes(), 2) + ":"
                        + Logger.pad(date.getSeconds(), 2) + "." + Logger.pad(date.getMilliseconds(), 3);
                    return str;
                }
                static pad(num, size) {
                    let s = num + "";
                    while (s.length < size) {
                        s = "0" + s;
                    }
                    return s;
                }
            }
            Common.Logger = Logger;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class LoggerPageScript extends Common.Logger {
                static info(message) {
                    LoggerPageScript.log(Common.LogSeverity[Common.LogSeverity.INFO], message);
                }
                static error(message) {
                    LoggerPageScript.log(Common.LogSeverity[Common.LogSeverity.ERROR], message);
                }
                static log(level, message) {
                    let sb;
                    sb = `${Common.Logger.getFormattedDate()} - `;
                    sb += `[${level} - PAGE SCRIPT] `;
                    sb += message;
                    console.log(sb);
                    let logMsg = { message: "teststudio_v_2.log.message", data: sb };
                    window.postMessage(logMsg, "*");
                }
            }
            Common.LoggerPageScript = LoggerPageScript;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Foreground;
        (function (Foreground) {
            var ConsoleInterceptor;
            (function (ConsoleInterceptor) {
                function overrideConsoleErrorFunction(frame) {
                    const oldConsoleError = frame.console.error;
                    frame.console.error = function () {
                        logError(arguments[0], arguments[1]);
                        oldConsoleError.apply(frame.console, arguments);
                    };
                }
                function overrideConsoleExceptionFunction(frame) {
                    const oldConsoleException = frame.console.exception;
                    frame.console.exception = function () {
                        logError(arguments[0], arguments[1]);
                        oldConsoleException.apply(frame.console, arguments);
                    };
                }
                function parseKey(key) {
                    if (Object.prototype.toString.call(key) === "[object String]") {
                        return key;
                    }
                    if (key instanceof Error || key.message != null) {
                        return key.message;
                    }
                    try {
                        return JSON.stringify(key);
                    }
                    catch (ex) {
                        return key;
                    }
                }
                function logError(err, extra) {
                    if (err != null) {
                        let key = parseKey(err);
                        if (extra != null) {
                            key = key + " " + parseKey(extra);
                        }
                        if (window.top.TS_JS_Console_Errors[key]) {
                            window.top.TS_JS_Console_Errors[key] += 1;
                        }
                        else {
                            window.top.TS_JS_Console_Errors[key] = 1;
                        }
                    }
                }
                function overrideConsoleFunctions(frame) {
                    if (frame.console.exception != null) {
                        overrideConsoleExceptionFunction(frame);
                    }
                    if (frame.console.error != null) {
                        overrideConsoleErrorFunction(frame);
                    }
                    frame.addEventListener("error", (ev) => {
                        logError(ev, null);
                    });
                }
                ConsoleInterceptor.overrideConsoleFunctions = overrideConsoleFunctions;
            })(ConsoleInterceptor = Foreground.ConsoleInterceptor || (Foreground.ConsoleInterceptor = {}));
        })(Foreground = TestStudio.Foreground || (TestStudio.Foreground = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
if (window.top.TS_JS_Console_Errors === undefined) {
    window.top.TS_JS_Console_Errors = {};
    Telerik.TestStudio.Foreground.ConsoleInterceptor.overrideConsoleFunctions(window.top);
}
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Foreground;
        (function (Foreground) {
            var AjaxInterceptor;
            (function (AjaxInterceptor) {
                function listenForAjax(frame) {
                    const httpRequests = new Array();
                    frame.XMLHttpRequest.prototype.realSend = frame.XMLHttpRequest.prototype.send;
                    frame.XMLHttpRequest.prototype.send = function (value) {
                        this.addEventListener("loadstart", function () {
                            httpRequests.push(this);
                            window.top.TS_Active_Ajax_Count++;
                        }, false);
                        this.addEventListener("progress", function () {
                            const index = httpRequests.indexOf(this);
                            if (index === -1) {
                                httpRequests.push(this);
                                window.top.TS_Active_Ajax_Count++;
                            }
                        }, false);
                        this.addEventListener("loadend", function () {
                            if (httpRequests.length > 0) {
                                const index = httpRequests.indexOf(this);
                                if (index > -1) {
                                    httpRequests.splice(index, 1);
                                    window.top.TS_Active_Ajax_Count--;
                                }
                            }
                        }, false);
                        this.realSend(value);
                    };
                }
                AjaxInterceptor.listenForAjax = listenForAjax;
            })(AjaxInterceptor = Foreground.AjaxInterceptor || (Foreground.AjaxInterceptor = {}));
        })(Foreground = TestStudio.Foreground || (TestStudio.Foreground = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
if (window.top.TS_Active_Ajax_Count === undefined) {
    window.top.TS_Active_Ajax_Count = 0;
    Telerik.TestStudio.Foreground.AjaxInterceptor.listenForAjax(window.top);
}
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Foreground;
        (function (Foreground) {
            class ContentProcessor {
                constructor() {
                    this.logger = null;
                }
                processCommand(cmd) {
                    let result = TestStudio.Common.cloneCommand(cmd);
                    try {
                        let commandProcessor = this.commandProcessorFactory.createCommandProcessor(result.CommandType);
                        commandProcessor.processCommand(result);
                    }
                    catch (err) {
                        result.InError = true;
                        result.Response = err.message ? err.message : err;
                    }
                    return result;
                }
                addCommandListener(event) {
                    if (event.data && event.data.message && event.data.message === "teststudio_v_2.exec.processCommand") {
                        let command = new TestStudio.Common.Command(event.data.data);
                        let result = this.processCommand(command);
                        window.postMessage({ message: "teststudio_v_2.exec.processCommandResponse", data: result }, "*");
                    }
                }
                init() {
                    this.logger = Telerik.TestStudio.Common.LoggerPageScript;
                    this.commandProcessorFactory = new Foreground.CommandProcessorFactory();
                    if (window.constructor.prototype && window.constructor.prototype.addEventListener) {
                        window.constructor.prototype.addEventListener.call(window, "message", event => this.addCommandListener(event), false);
                    }
                    else {
                        window.addEventListener("message", event => this.addCommandListener(event));
                    }
                    const frames = TestStudio.Common.FramesUtils.buildFlatFramesCollection(window);
                    frames.forEach(Telerik.TestStudio.Foreground.ConsoleInterceptor.overrideConsoleFunctions);
                    frames.forEach(Telerik.TestStudio.Foreground.AjaxInterceptor.listenForAjax);
                    window.postMessage({ message: "teststudio_v_2.exec.contentProcessorInjected" }, "*");
                }
            }
            Foreground.ContentProcessor = ContentProcessor;
        })(Foreground = TestStudio.Foreground || (TestStudio.Foreground = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
let testStudioContentProcessor = new Telerik.TestStudio.Foreground.ContentProcessor();
testStudioContentProcessor.init();
