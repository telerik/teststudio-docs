var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class Windows {
                getCurrent(getInfo) {
                    if (getInfo) {
                        return new Promise((resolve, reject) => {
                            chrome.windows.getCurrent(getInfo, (result) => {
                                resolve(result);
                            });
                        });
                    }
                    else {
                        return new Promise((resolve, reject) => {
                            chrome.windows.getCurrent((result) => {
                                resolve(result);
                            });
                        });
                    }
                }
                onCreatedAddListener(callback) {
                    chrome.windows.onCreated.addListener(callback);
                }
            }
            class Tabs {
                executeScript(tabId, injectOptions) {
                    return new Promise((resolve, reject) => {
                        chrome.tabs.executeScript(tabId, injectOptions, (result) => {
                            resolve(result);
                        });
                    });
                }
                get(tabId) {
                    return new Promise((resolve, reject) => {
                        chrome.tabs.get(tabId, (tab) => {
                            chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(tab);
                        });
                    });
                }
                onActivatedAddListener(callback) {
                    chrome.tabs.onActivated.addListener(callback);
                }
                onCreatedAddListener(callback) {
                    chrome.tabs.onCreated.addListener(callback);
                }
                onRemovedAddListener(callback) {
                    chrome.tabs.onRemoved.addListener(callback);
                }
                onReplacedAddListener(callback) {
                    chrome.tabs.onReplaced.addListener(callback);
                }
                query(queryInfo) {
                    return new Promise((resolve, reject) => {
                        chrome.tabs.query(queryInfo, (result) => {
                            resolve(result);
                        });
                    });
                }
                sendMessage(tabId, args) {
                    return new Promise((resolve, reject) => {
                        chrome.tabs.sendMessage(tabId, args, (response) => {
                            chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
                        });
                    });
                }
            }
            class History {
                deleteAll() {
                    return new Promise((resolve, reject) => {
                        chrome.history.deleteAll(() => {
                            chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve();
                        });
                    });
                }
            }
            class Runtime {
                getURL(path) {
                    return chrome.runtime.getURL(path);
                }
                sendMessage(args) {
                    return new Promise((resolve, reject) => {
                        chrome.runtime.sendMessage(args, (response) => {
                            chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
                        });
                    });
                }
                onMessageAddListener(callback) {
                    chrome.runtime.onMessage.addListener(callback);
                }
                id() {
                    return chrome.runtime.id;
                }
            }
            class BrowsingData {
                removeCache(options) {
                    return new Promise((resolve, reject) => {
                        chrome.browsingData.removeCache(options, () => {
                            resolve();
                        });
                    });
                }
                removeLocalStorage(options) {
                    return new Promise((resolve, reject) => {
                        chrome.browsingData.removeLocalStorage(options, () => {
                            resolve();
                        });
                    });
                }
            }
            class Cookies {
                getAll(details) {
                    return new Promise((resolve, reject) => {
                        chrome.cookies.getAll(details, (cookies) => {
                            resolve(cookies);
                        });
                    });
                }
                remove(details) {
                    return new Promise((resolve, reject) => {
                        chrome.cookies.remove(details, (result) => {
                            resolve(result);
                        });
                    });
                }
                set(details) {
                    return new Promise((resolve, reject) => {
                        chrome.cookies.set(details, (cookie) => {
                            resolve(cookie);
                        });
                    });
                }
            }
            class Storage {
                localSet(details) {
                    return new Promise((resolve, reject) => {
                        chrome.storage.sync.set(details, () => {
                            resolve();
                        });
                    });
                }
                localGet() {
                    return new Promise((resolve, reject) => {
                        chrome.storage.sync.get((items) => {
                            resolve(items);
                        });
                    });
                }
            }
            class Browser {
                static getBrowserName() {
                    if (navigator.userAgent.indexOf("Edg") >= 0) {
                        return "EdgeChromium";
                    }
                    return "Chrome";
                }
                static getBrowserVersion() {
                    if (navigator.userAgent.indexOf("Edg") >= 0) {
                        return window.navigator.appVersion.match(/Edg\/([^ ]*)/)[1];
                    }
                    return window.navigator.appVersion.match(/Chrome\/([^ ]*)/)[1];
                }
            }
            Browser.runtime = new Runtime();
            Browser.browsingData = new BrowsingData();
            Browser.cookies = new Cookies();
            Browser.history = new History();
            Browser.tabs = new Tabs();
            Browser.windows = new Windows();
            Browser.storage = new Storage();
            Common.Browser = Browser;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            function run(func, contextWindow) {
                contextWindow = contextWindow || window;
                return contextWindow.eval(func);
            }
            Common.run = run;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Foreground;
        (function (Foreground) {
            class MessageResponse {
            }
            Foreground.MessageResponse = MessageResponse;
        })(Foreground = TestStudio.Foreground || (TestStudio.Foreground = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class TestStudioContext {
                constructor(port, mode, version) {
                    this.port = port;
                    this.mode = mode;
                    this.version = version;
                }
            }
            Common.TestStudioContext = TestStudioContext;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class UrlHelper {
                static getQueryParameterByName(url, paramName) {
                    paramName = paramName.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
                    let regex = new RegExp("[\\?&]" + paramName + "=([^&#]*)");
                    let results = regex.exec(url);
                    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
                }
                static getTestStudioContextFromUrl(url) {
                    if (url.indexOf(UrlHelper.startPageBaseUrl) === -1) {
                        return new Common.TestStudioContext(null, null, null);
                    }
                    return new Common.TestStudioContext(UrlHelper.getQueryParameterByName(url, "port"), UrlHelper.getQueryParameterByName(url, "mode"), UrlHelper.getQueryParameterByName(url, "version"));
                }
            }
            UrlHelper.startPageBaseUrl = "/WebUI/teststudio_start_page.html";
            Common.UrlHelper = UrlHelper;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            let LogSeverity;
            (function (LogSeverity) {
                LogSeverity[LogSeverity["INFO"] = 0] = "INFO";
                LogSeverity[LogSeverity["ERROR"] = 1] = "ERROR";
            })(LogSeverity = Common.LogSeverity || (Common.LogSeverity = {}));
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class Logger {
                static info(message) {
                    Logger.log(Common.LogSeverity[Common.LogSeverity.INFO], message);
                }
                static error(message) {
                    Logger.log(Common.LogSeverity[Common.LogSeverity.ERROR], message);
                }
                static log(level, message) {
                    let sb;
                    sb = `${Logger.getFormattedDate()} - `;
                    sb += `[${level}] `;
                    sb += message;
                    console.log(sb);
                }
                static getFormattedDate() {
                    let date = new Date();
                    let str = Logger.pad(date.getDate(), 2) + "/" + Logger.pad((date.getMonth() + 1), 2) + "/" + date.getFullYear()
                        + " " + Logger.pad(date.getHours(), 2) + ":" + Logger.pad(date.getMinutes(), 2) + ":"
                        + Logger.pad(date.getSeconds(), 2) + "." + Logger.pad(date.getMilliseconds(), 3);
                    return str;
                }
                static pad(num, size) {
                    let s = num + "";
                    while (s.length < size) {
                        s = "0" + s;
                    }
                    return s;
                }
            }
            Common.Logger = Logger;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class LoggerForeground extends Common.Logger {
                static info(message) {
                    LoggerForeground.log(Common.LogSeverity[Common.LogSeverity.INFO], message);
                }
                static error(message) {
                    LoggerForeground.log(Common.LogSeverity[Common.LogSeverity.ERROR], message);
                }
                static log(level, message) {
                    let sb;
                    sb = `${Common.Logger.getFormattedDate()} - `;
                    sb += `[${level} - CONTENT SCRIPTS] `;
                    sb += message;
                    console.log(sb);
                    let logMsg = { message: "teststudio_v_2.log.message", data: sb };
                    Common.Browser.runtime.sendMessage(logMsg);
                }
            }
            Common.LoggerForeground = LoggerForeground;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Foreground;
        (function (Foreground) {
            var Injector;
            (function (Injector) {
                Injector.isStarted = false;
                Injector.insertInHead = false;
                let logger = null;
                let checkBackgroundAvailableInterval;
                let injectInterval;
                let isRecorderLoaded = false;
                let isBackgroundAvailable = false;
                let checkInterval;
                let processorInjected = false;
                let alreadyInjected = false;
                const recorderTagId = "teststudio-recorder";
                const executionTagId = "teststudio-execution";
                function CheckForStartedExecution(url) {
                    let context = TestStudio.Common.UrlHelper.getTestStudioContextFromUrl(url);
                    if (context.mode !== "0") {
                        return;
                    }
                    TestStudio.Common.Browser.runtime.sendMessage({ message: "executionStarted" });
                }
                function ExtractRecorderData(url) {
                    let context = TestStudio.Common.UrlHelper.getTestStudioContextFromUrl(url);
                    if (context.mode !== "1" || context.port == null) {
                        return;
                    }
                    TestStudio.Common.Browser.runtime.sendMessage({ message: "setRecorderData_v_2", context: context });
                }
                function SetPageScriptVersion(ver) {
                    TestStudio.Common.Browser.runtime.sendMessage({ message: "setVersion", version: ver });
                }
                function ForwardContentWindowMessages(e) {
                    let jObj;
                    try {
                        jObj = JSON.parse(e.data);
                    }
                    catch (ex) {
                    }
                    if (!jObj || !jObj.tjsr_v_2_message) {
                        return;
                    }
                    if (jObj.tjsr_v_2_message === "sendRecorderCommand") {
                        TestStudio.Common.Browser.runtime.sendMessage({ message: jObj.tjsr_v_2_message, command: jObj.command });
                    }
                }
                function HandleCommandMessages(e) {
                    let jObj;
                    try {
                        jObj = JSON.parse(e.data);
                    }
                    catch (ex) {
                    }
                    if (!jObj || !jObj.tjsr_cmd_message) {
                        return;
                    }
                    if (jObj.tjsr_cmd_message === "loadRecorder_v_2") {
                        let socket = jObj.tjsr_cmd_socketPort;
                        TestStudio.Common.Browser.runtime.sendMessage({ message: "clearExecutionTab" });
                        if (!isRecorderLoaded) {
                            window.addEventListener("message", ForwardContentWindowMessages, true);
                            TestStudio.Common.Browser.runtime.onMessageAddListener(HandleExtensionMessage);
                            injectScript("teststudio.js", recorderTagId);
                            isRecorderLoaded = true;
                            if (jObj.tjsr_cmd_isMainWindow === true) {
                                TestStudio.Common.Browser.runtime.sendMessage({ message: "setRecorderData_v_2", context: { port: socket } });
                            }
                        }
                    }
                }
                function injectScript(script, id) {
                    TestStudio.Common.Browser.runtime.sendMessage({ message: "getVersion" }).then((response) => {
                        let version = response.version;
                        if (version != null && version.length > 1) {
                            version = normalizeVersion(version);
                            for (let key in Injector.versions) {
                                if (Injector.versions.hasOwnProperty(key)) {
                                    if (version <= key) {
                                        injectPageScript("scripts/" + Injector.versions[key] + "/" + script, id);
                                        return;
                                    }
                                }
                            }
                            injectPageScript("scripts/" + script, id);
                            return;
                        }
                        injectPageScript("scripts/" + Injector.initalVersion + "/" + script, id);
                    });
                }
                function normalizeVersion(version) {
                    let sp = version.split(".");
                    if (sp[2].length < 4) {
                        sp[2] = "0" + sp[2];
                    }
                    return sp.join(".");
                }
                function HandleExtensionMessage(request, sender, sendResponse) {
                    if (!request.webSocketMsg) {
                        return;
                    }
                    window.postMessage(request.webSocketMsg, "*");
                }
                function InjectRecorder() {
                    TestStudio.Common.Browser.runtime.sendMessage({ message: "getRecorderData_v_2" }).then((response) => {
                        if (!response || response.tabNotLoaded) {
                            return;
                        }
                        window.clearInterval(injectInterval);
                        injectInterval = 0;
                        if (response.socket === "") {
                            return;
                        }
                        if (!isRecorderLoaded) {
                            window.addEventListener("message", ForwardContentWindowMessages, true);
                            TestStudio.Common.Browser.runtime.onMessageAddListener(HandleExtensionMessage);
                            injectScript("teststudio.js", recorderTagId);
                            isRecorderLoaded = true;
                        }
                    });
                }
                function injectPageScript(scriptUrl, id) {
                    if (document.getElementById(id) != null) {
                        return;
                    }
                    let pageScript = document.createElement("script");
                    pageScript.id = id;
                    pageScript.setAttribute("extension_id", TestStudio.Common.Browser.runtime.id());
                    pageScript.type = "text/javascript";
                    pageScript.src = TestStudio.Common.Browser.runtime.getURL(scriptUrl);
                    if (Injector.insertInHead && document.head != null) {
                        document.head.appendChild(pageScript);
                        logger.info(`Page script: ${scriptUrl} loaded in document.head`);
                    }
                    else if (document.body != null) {
                        document.body.appendChild(pageScript);
                        logger.info(`Page script: ${scriptUrl} loaded in document.body`);
                    }
                    else {
                        logger.error(`Could not inject page script: ${scriptUrl}`);
                    }
                }
                function WaitUntilBackgoundAvailable() {
                    TestStudio.Common.Browser.runtime.sendMessage({ message: "isAvailable" })
                        .then((response) => {
                        if (isBackgroundAvailable) {
                            return;
                        }
                        isBackgroundAvailable = true;
                        window.clearInterval(checkBackgroundAvailableInterval);
                        if (!isRecorderLoaded) {
                            CheckForStartedExecution(window.location.href);
                            ExtractRecorderData(window.location.href);
                            window.clearInterval(injectInterval);
                            injectInterval = window.setInterval(InjectRecorder, 100);
                        }
                    }, (error) => {
                    });
                }
                function CheckIsAutomated() {
                    TestStudio.Common.Browser.runtime.sendMessage({ message: "teststudio_v_2.exec.isAutomated" }).then((response) => {
                        if (!response) {
                            return;
                        }
                        clearInterval(checkInterval);
                        if (response.state && !alreadyInjected) {
                            injectScript("pageScript.js", executionTagId);
                            alreadyInjected = true;
                        }
                    });
                }
                function HandleWindowMessage(event) {
                    if (!event || !event.data || !event.data.message) {
                        return;
                    }
                    if (window.closed) {
                        logger.info("Window already closed. Ignoring message.");
                        return;
                    }
                    switch (event.data.message) {
                        case "teststudio.checkForInstalledExtension":
                            window.postMessage({ message: "testStudioExtensionIsInstalled" }, "*");
                            break;
                        case "teststudio_v_2.exec.contentProcessorInjected":
                            processorInjected = true;
                            break;
                        case "teststudio_v_2.exec.processCommandResponse":
                        case "teststudio_v_2.exec.dispatchJsEvent":
                            TestStudio.Common.Browser.runtime.sendMessage(event.data);
                            break;
                        case "teststudio_v_2.exec.enableExecution":
                            TestStudio.Common.Browser.runtime.sendMessage(event.data);
                            CheckIsAutomated();
                            break;
                        case "teststudio_v_2.exec.windowClose":
                            TestStudio.Common.Browser.runtime.sendMessage(event.data.message);
                            break;
                        case "teststudio_v_2.log.message":
                            TestStudio.Common.Browser.runtime.sendMessage(event.data);
                            break;
                        default:
                            break;
                    }
                }
                function PostToWindow(command) {
                    if (processorInjected) {
                        window.postMessage(command, "*");
                    }
                    else {
                        window.setTimeout(() => { PostToWindow(command); }, 50);
                    }
                }
                function start() {
                    logger = Telerik.TestStudio.Common.LoggerForeground;
                    window.clearInterval(checkBackgroundAvailableInterval);
                    TestStudio.Common.Browser.storage.localGet().then((data) => {
                        if (data != null && data.hasOwnProperty("insert_in_header")) {
                            Telerik.TestStudio.Foreground.Injector.insertInHead = data.insert_in_header;
                        }
                    });
                    if (!isRecorderLoaded) {
                        checkBackgroundAvailableInterval = window.setInterval(WaitUntilBackgoundAvailable, 500);
                        window.addEventListener("message", HandleCommandMessages, true);
                    }
                    TestStudio.Common.Browser.runtime.onMessageAddListener((message, sender, sendResponse) => {
                        let msgObj;
                        if (typeof message === "object") {
                            msgObj = message;
                        }
                        else {
                            msgObj = JSON.parse(message);
                        }
                        if (!msgObj.message) {
                            return;
                        }
                        switch (msgObj.message) {
                            case "teststudio_v_2.exec.getPageInfo":
                                const response = new Foreground.MessageResponse();
                                response.title = document.title;
                                if (!response.title) {
                                    response.title = window.location.host;
                                    if (window.location.pathname.length !== 1) {
                                        response.title = response.title + window.location.pathname;
                                    }
                                }
                                response.title = unescape(response.title);
                                response.version = TestStudio.Common.Browser.getBrowserVersion();
                                sendResponse(response);
                                break;
                            case "teststudio_v_2.exec.processCommand":
                                PostToWindow(msgObj);
                                sendResponse(true);
                                break;
                            case "teststudio_v_2.exec.started":
                                CheckIsAutomated();
                                sendResponse(true);
                                break;
                            default:
                                sendResponse(true);
                                break;
                        }
                    });
                    window.addEventListener("message", HandleWindowMessage);
                    TestStudio.Common.Browser.runtime.sendMessage({ message: "teststudio_v_2.exec.tabLoaded" });
                    checkInterval = window.setInterval(() => CheckIsAutomated(), 100);
                    CheckIsAutomated();
                    logger.info("Initialized.");
                    Injector.isStarted = true;
                }
                Injector.start = start;
            })(Injector = Foreground.Injector || (Foreground.Injector = {}));
        })(Foreground = TestStudio.Foreground || (TestStudio.Foreground = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
if (window === window.top && !Telerik.TestStudio.Foreground.Injector.isStarted) {
    Telerik.TestStudio.Foreground.Injector.start();
}
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Foreground;
        (function (Foreground) {
            var Injector;
            (function (Injector) {
                Injector.initalVersion = "2017.3.1013.1";
                Injector.versions = {
                    "2017.3.1013.1": "2017.3.1013.1",
                    "2018.1.0130.2": "2017.3.1013.1",
                    "2018.1.0418.2": "2017.3.1013.1",
                };
            })(Injector = Foreground.Injector || (Foreground.Injector = {}));
        })(Foreground = TestStudio.Foreground || (TestStudio.Foreground = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
