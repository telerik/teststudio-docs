var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class ActionPoint {
                constructor(x, y) {
                    this.x = x;
                    this.y = y;
                }
                getX() {
                    return this.x;
                }
                setX(value) {
                    this.x = value;
                }
                getY() {
                    return this.y;
                }
                setY(value) {
                    this.y = value;
                }
            }
            Recorder.ActionPoint = ActionPoint;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class CapturedCommand {
                constructor() {
                    this.expression = null;
                    this.page = null;
                    this.timestamp = null;
                    this.frameInfo = null;
                    this.elementRect = null;
                    this.elementDimensions = null;
                }
                getData() {
                    return this.commandData;
                }
                setData(value) {
                    this.commandData = value;
                }
                getTarget() {
                    return this.target;
                }
                setTarget(value) {
                    this.target = value;
                }
                getExpression() {
                    return this.expression;
                }
                setExpression(value) {
                    this.expression = value;
                }
                getPage() {
                    return this.page;
                }
                setPage(value) {
                    this.page = value;
                }
                getTimestamp() {
                    return this.timestamp;
                }
                setTimestamp(value) {
                    this.timestamp = value;
                }
                getFrameInfo() {
                    return this.frameInfo;
                }
                setFrameInfo(value) {
                    this.frameInfo = value;
                }
                getElementRect() {
                    return this.elementRect;
                }
                setElementRect(value) {
                    this.elementRect = value;
                }
                getCommandCategoryType() {
                    return this.commandCategoryType;
                }
                setCommandCategoryType(value) {
                    this.commandCategoryType = value;
                }
                getBrowserCommandType() {
                    return this.browserCommandType;
                }
                setBrowserCommandType(value) {
                    this.browserCommandType = value;
                }
                getDesktopCommandType() {
                    return this.desktopCommandType;
                }
                setDesktopCommandType(value) {
                    this.desktopCommandType = value;
                }
                getElementDimensions() {
                    return this.elementDimensions;
                }
                setElementDimensions(value) {
                    this.elementDimensions = value;
                }
            }
            Recorder.CapturedCommand = CapturedCommand;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class FindExpression {
                constructor() {
                    this.chainStop = -1;
                    this.clauses = new Array();
                }
                addClause(clause) {
                    let newIndex = this.clauses.length;
                    this.clauses[newIndex] = clause;
                }
                matchElement(target) {
                    for (let i = 0; i < this.clauses.length; i++) {
                        if (this.clauses[i].match(target) == false) {
                            return false;
                        }
                    }
                    return true;
                }
                getClauses() {
                    let result = new Array();
                    for (let i = 0; i < this.clauses.length; i++) {
                        if (this.clauses[i].getType() == 3) {
                            result[result.length] = this.clauses[i].getName() + ":" + this.clauses[i].getValue();
                        }
                        else {
                            result[result.length] = this.clauses[i].getName() + "=" + this.clauses[i].getValue();
                        }
                    }
                    return result;
                }
                getGhainStop() {
                    return this.chainStop;
                }
                setChainStop(value) {
                    this.chainStop = value;
                }
            }
            Recorder.FindExpression = FindExpression;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            var Findxs;
            (function (Findxs) {
                let MAX_TEXTCONTENT_FIND;
                let STARTS_WITH;
                let TAG_NAMES = ["textarea", "script", "div", "table", "style",
                    "a", "img", "frameset", "frame", "iframe",
                    "map", "select", "input", "link", "th",
                    "td", "col", "tr", "span", "li",
                    "ol", "ul", "testregion", "video", "audio",
                    "source"];
                let INPUT_ELEMENTS_NAMES = ["button", "checkbox", "file", "hidden", "image",
                    "password", "radio", "reset", "submit", "text",
                    "email	", "url	", "number", "range", "search"];
                let data = JSON.parse("{\"UseHttpProxy\":false,\"RecordjQueryInDescriptorsIfPossible\":true,\"ShouldDeleteElement\":false,\"SkipDeleteElementPrompt\""
                    + ":false,\"HideFindExpressionWelcome\":false,\"MenuHoldTime\":1.0,\"SilverlightConnectTimeout\":30000,\"BaseClassName\":\"BaseWebAiiTest\","
                    + "\"UrlRecordMode\":2,\"HighlightBorderColor\":-65536,\"HighlightBorderSize\":1,\"CodeGenerationElementIdentificationType\":1,"
                    + "\"UrlHistory\":[],\"AbsoluteDragDropRecording\":true,\"ImageScalePercentage\":75,\"SelectedIdentificaitonScheme\":\"Html\","
                    + "\"IdentificationSchemes\":{\"Html\":{\"CheckFindParamUniqueness\":true,\"AutoDetectTestRegions\":true,\"TryAttributeCombinations\":true,"
                    + "\"AlwaysAssertTagName\":true,\"IdentificationsPerTag\":{\"All Elements\":[{\"IsLocked\":false,\"SearchType\":0,\"AttributeName\":\"id\"},"
                    + "{\"IsLocked\":false,\"SearchType\":0,\"AttributeName\":\"name\"},{\"IsLocked\":false,\"SearchType\":0,\"AttributeName\":\"src\"},"
                    + "{\"IsLocked\":false,\"SearchType\":0,\"AttributeName\":\"href\"},{\"IsLocked\":false,\"SearchType\":0,\"AttributeName\":\"value\"},"
                    + "{\"IsLocked\":false,\"SearchType\":0,\"AttributeName\":\"alt\"},{\"IsLocked\":true,\"SearchType\":1,\"AttributeName\":null},"
                    + "{\"IsLocked\":true,\"SearchType\":8,\"AttributeName\":null}]},\"TechnologyType\":1},\"Silverlight\":"
                    + "{\"CheckFindParamUniqueness\":true,\"AutoDetectTestRegions\":true,\"TryAttributeCombinations\":true,"
                    + "\"AlwaysAssertTagName\":true,\"IdentificationsPerTag\":{\"All Elements\":[{\"IsLocked\":false,\"SearchType\":0,\"AttributeName\":null},"
                    + "{\"IsLocked\":false,\"SearchType\":5,\"AttributeName\":null},{\"IsLocked\":false,\"SearchType\":1,\"AttributeName\":null},"
                    + "{\"IsLocked\":true,\"SearchType\":6,\"AttributeName\":null}]},\"TechnologyType\":2}},\"UnitTypeTypeGeneration\":1,\"DebugMode\":false,"
                    + "\"RecorderBaseUrl\":\"\",\"IsStoryBoardCapturingEnabled\":true,\"SimulateRealClickByDefault\":false,\"SimulateRealTypingByDefault\":false,"
                    + "\"SimulateRealSilverlightUserByDefault\":true,\"DefaultDropDownSelection\":1,\"QuickExecutionElementWaitTimeout\":10000,"
                    + "\"QuickExecutionClientReadyTimeout\":30000,\"QcServerUrl\":null,\"QcUserName\":null,\"QcPassword\":null,\"QcSkipAuthDialog\":false,"
                    + "\"QcDomain\":null,\"QcProject\":null,\"TfsUserName\":null,\"TfsPassword\":null,\"TfsSkipAuthDialog\":true,\"TfsDomain\":null,"
                    + "\"TeamPulseServerUrl\":\"\",\"TpUserName\":null,\"TpPassword\":null,\"TpUseWindowsAuth\":false,\"TpSkipAuthDialog\":false,"
                    + "\"RecordWpfWindowStateChanged\":false,\"PromptNameOnAddElement\":true,\"DefaultWPFApplication\":null,"
                    + "\"UseLegacySilverlightFindLogic\":false,\"BugTitleMask\":\"{Step name} step on {Test name} test failed.\","
                    + "\"BugAddAttachment\":true,\"BugAutoSubmit\":false,\"BugDescriptionMask\":\"{Description}\"}");
                function getStartsWith() {
                    return STARTS_WITH;
                }
                Findxs.getStartsWith = getStartsWith;
                function getMaxTextContentFind() {
                    return MAX_TEXTCONTENT_FIND;
                }
                Findxs.getMaxTextContentFind = getMaxTextContentFind;
                function buildExpression(target) {
                    return buildFindExpression(target);
                }
                Findxs.buildExpression = buildExpression;
                function getRoot(who) {
                    while (who.location == undefined) {
                        who = who.parentNode;
                    }
                    return who;
                }
                function indexOfSpecial(value, startIndex) {
                    for (let i = startIndex; i < value.length; i++) {
                        if (value[i] === " " || value[i] === "_" || value[i] === "." || value[i] === "," ||
                            value[i] === "?" || value[i] === "!" || value[i] === ";" || value[i] === "-" || value[i] === "|") {
                            return i;
                        }
                    }
                    return -1;
                }
                function smartTrim(value, maxLength) {
                    if (value.length <= maxLength) {
                        return value;
                    }
                    let splitLocation = 0;
                    let lastValidLocation = 0;
                    while (splitLocation !== -1 && splitLocation < maxLength - 1) {
                        lastValidLocation = splitLocation;
                        if (splitLocation === 0) {
                            splitLocation = indexOfSpecial(value, 1);
                        }
                        else {
                            splitLocation = indexOfSpecial(value, splitLocation + 1);
                        }
                    }
                    if (lastValidLocation > 0 && lastValidLocation < maxLength) {
                        return value.substring(0, lastValidLocation);
                    }
                    else {
                        return value.substr(0, maxLength);
                    }
                }
                function tryGetFileNameFromPath(path) {
                    try {
                        let fileNameIndex = path.lastIndexOf("/") + 1;
                        let filename = path.substr(fileNameIndex);
                        return filename;
                    }
                    catch (err) {
                        return "";
                    }
                }
                function capitalizeFirstLetter(value) {
                    return value.charAt(0).toUpperCase() + value.slice(1);
                }
                function getInputType(target) {
                    let type = target.type.toLowerCase();
                    if (INPUT_ELEMENTS_NAMES.indexOf(type) > -1) {
                        return capitalizeFirstLetter(type);
                    }
                    return "NotSet";
                }
                function getTypeName(target) {
                    if (!target.tagName) {
                        return "Other";
                    }
                    let tagName = target.tagName.toLowerCase();
                    switch (tagName) {
                        case "textarea":
                            return "TextArea";
                        case "style":
                            return "CascadingStyleSheet";
                        case "a":
                            return "Anchor";
                        case "img":
                            return "Image";
                        case "frameset":
                            return "FrameSet";
                        case "iframe":
                            return "IFrame";
                        case "th":
                            return "TableHeader";
                        case "td":
                            return "TableCell";
                        case "col":
                            return "TableColumn";
                        case "tr":
                            return "TableRow";
                        case "li":
                            return "ListItem";
                        case "ol":
                            return "OrderedList";
                        case "ul":
                            return "UnorderedList";
                        case "testregion":
                            return "TestRegion";
                        default:
                            if (INPUT_ELEMENTS_NAMES.indexOf(tagName) > -1) {
                                return capitalizeFirstLetter(tagName);
                            }
                            return "Other";
                    }
                }
                function knownElementType(target) {
                    if (!target.tagName) {
                        return false;
                    }
                    let tagName = target.tagName.toLowerCase();
                    if (TAG_NAMES.indexOf(tagName) > -1) {
                        return true;
                    }
                    return false;
                }
                function trim(value) {
                    let startIndex = 0;
                    let endIndex = value.length - 1;
                    for (let i = 0; i < value.length; i++) {
                        startIndex = i;
                        if (value[i] !== " ") {
                            break;
                        }
                    }
                    for (let j = value.length - 1; j >= 0; j--) {
                        endIndex = j;
                        if (value[j] !== " ") {
                            break;
                        }
                    }
                    return value.substring(startIndex, endIndex + 1);
                }
                function containsLetter(value) {
                    return /^.*[A-Z].*/i.test(value);
                }
                function containsDigit(value) {
                    return /^.*[0-9].*/i.test(value);
                }
                function containsNonAsciiLetter(value) {
                    return /^.*[^\x00-\x80].*/i.test(value);
                }
                function sanitizeString(value) {
                    let newValue = trim(value);
                    let sb = "";
                    let nextCharShouldBeCaps = true;
                    let firstSpace = -1;
                    let count = newValue.length;
                    for (let idx = 0; idx < count; idx++) {
                        let charLetter = newValue[idx];
                        if (charLetter === " ") {
                            firstSpace = idx;
                        }
                        if (!containsDigit(charLetter) && !containsLetter(charLetter) && !containsNonAsciiLetter(charLetter)) {
                            nextCharShouldBeCaps = true;
                            continue;
                        }
                        else {
                            if (nextCharShouldBeCaps) {
                                sb += charLetter.toUpperCase();
                                nextCharShouldBeCaps = false;
                            }
                            else {
                                sb += charLetter;
                            }
                        }
                    }
                    if (sb.length > 0 && !isNaN(parseInt(sb[0], 10))) {
                        sb = "x" + sb;
                    }
                    return sb;
                }
                function isEmptyOrNull(item) {
                    return item == null || item === "" || item == undefined;
                }
                function buildFindExpression(target) {
                    let expr = null;
                    let isTagIndex = false;
                    let isXPath = false;
                    let idList;
                    let scheme = data.IdentificationSchemes.Html;
                    if (scheme.IdentificationsPerTag[target.tagName] != undefined) {
                        idList = scheme.IdentificationsPerTag[target.tagName];
                    }
                    else {
                        idList = scheme.IdentificationsPerTag["All Elements"];
                    }
                    for (let i = 0; i < idList.length; i++) {
                        let identificationTag = idList[i];
                        switch (identificationTag.SearchType) {
                            case 0:
                                if (identificationTag.AttributeName.toLowerCase() === "value" &&
                                    target.tagName.toLowerCase() === "input" &&
                                    target.type.toLowerCase() === "text") {
                                    break;
                                }
                                if (identificationTag.AttributeName.toLowerCase() === "xpath") {
                                    isXPath = true;
                                    expr = getExpression(new Recorder.Clauses(identificationTag.AttributeName, generateXPath(target), "xpath", 3));
                                    break;
                                }
                                if (identificationTag.AttributeName.toLowerCase() === "href" && target.hasAttribute("href")) {
                                    let href = target.getAttribute("href");
                                    href = replaceAmp(href);
                                    let attributeValue = href;
                                    if (attributeValue.toLowerCase().indexOf("javascript") === 0 ||
                                        isPotentialDynamicUrl(attributeValue) ||
                                        attributeValue.startsWith("#")) {
                                        break;
                                    }
                                    let attrName = identificationTag.AttributeName;
                                    expr = getExpression(new Recorder.Clauses(attrName, attributeValue, attrName, 0));
                                }
                                if (target.attributes != undefined && target.attributes[identificationTag.AttributeName]) {
                                    let value = target.attributes[identificationTag.AttributeName].value;
                                    if (identificationTag.AttributeName.toLowerCase() === "id"
                                        || identificationTag.AttributeName.toLowerCase() === "name") {
                                        value = replaceAmp(value);
                                    }
                                    expr = getExpression(new Recorder.Clauses(identificationTag.AttributeName, value, identificationTag.AttributeName, 0));
                                }
                                break;
                            case 1:
                                if (target.tagName.toLowerCase() === "textarea") {
                                    break;
                                }
                                if (target.contentEditable === "true") {
                                    break;
                                }
                                let contentToUse = getElementTextContent(target);
                                if (target.textContent && contentToUse !== "") {
                                    if (contentToUse.length > MAX_TEXTCONTENT_FIND) {
                                        contentToUse = STARTS_WITH + contentToUse.substr(0, MAX_TEXTCONTENT_FIND);
                                    }
                                    expr = getExpression(new Recorder.Clauses("TextContent", contentToUse, "textContent", 1));
                                }
                                break;
                            case 8:
                                expr = getExpression(new Recorder.Clauses("TagIndex", target.tagName.toLowerCase() + ":"
                                    + buildIndexAccordingToParentBasedTree(target.ownerDocument, target).toString(), "tagIndex", 2));
                                isTagIndex = true;
                                break;
                            default:
                                break;
                        }
                        if (scheme.CheckFindParamUniqueness && !isTagIndex && !isXPath) {
                            if (expr != null) {
                                expr.addClause(new Recorder.Clauses("tagname", target.tagName.toLowerCase(), "tagName", 4));
                                if (checkForUniqueness(expr, target.ownerDocument) === 1) {
                                    break;
                                }
                            }
                        }
                        else {
                            break;
                        }
                    }
                    if (isTagIndex && scheme.TryAttributeCombinations) {
                        let expr2 = null;
                        expr2 = buildChainedExpression(target, idList);
                        if (expr2 != null) {
                            expr = expr2;
                        }
                    }
                    return { clauses: expr.getClauses(), chainStop: expr.chainStop };
                }
                function getExpression(clause) {
                    let expr = new Recorder.FindExpression();
                    expr.addClause(clause);
                    return expr;
                }
                function buildChainedExpression(e, idList) {
                    let neighbor = getClosestNeighbourWithIdOrName(e, idList);
                    if (neighbor != null) {
                        let myEasyToFindParent = neighbor.first;
                        let attrType = neighbor.second;
                        let index = buildIndexAccordingToParentBasedTree(myEasyToFindParent, e);
                        if (index >= 0) {
                            let expr = new Recorder.FindExpression();
                            if (attrType === "name") {
                                expr.addClause(new Recorder.Clauses(attrType, myEasyToFindParent.attributes[attrType].value, attrType, 0));
                            }
                            else {
                                expr.addClause(new Recorder.Clauses(attrType, myEasyToFindParent[attrType], attrType, 0));
                            }
                            expr.addClause(new Recorder.Clauses("TagIndex", e.tagName.toLowerCase() + ":" + index.toString(), "tagIndex", 2));
                            expr.setChainStop(1);
                            return expr;
                        }
                    }
                    return null;
                }
                function isPotentialDynamicUrl(url) {
                    return url.indexOf(";") > -1 && url.indexOf("?") > -1 && url.indexOf("%") > -1 && url.indexOf("=") > -1;
                }
                function getClosestNeighbourWithIdOrName(target, idList) {
                    let temp = target.parentNode;
                    let attrName;
                    while (temp != null) {
                        for (let k = 0; k < idList.length; k++) {
                            if (idList[k].SearchType != 0) {
                                continue;
                            }
                            let expr = new Recorder.FindExpression();
                            if (idList[k].AttributeName.toLowerCase() === "id" && temp.id != undefined) {
                                expr.addClause(new Recorder.Clauses("id", temp.id, "id", 0));
                                if (checkForUniqueness(expr, temp.ownerDocument) === 1) {
                                    attrName = "id";
                                    return { first: temp, second: attrName };
                                }
                            }
                            if (idList[k].AttributeName.toLowerCase() === "name" && temp.attributes && temp.getAttribute("name")) {
                                expr.addClause(new Recorder.Clauses("name", temp.getAttribute("name").toString().toLowerCase(), "name", 0));
                                if (checkForUniqueness(expr, temp.ownerDocument) === 1) {
                                    attrName = "name";
                                    return { first: temp, second: attrName };
                                }
                            }
                        }
                        temp = temp.parentNode;
                    }
                    return null;
                }
                function checkForUniqueness(expr, node) {
                    let matchedElements = 0;
                    let nodesCount = node.childNodes.length;
                    for (let i = 0; i < nodesCount; i++) {
                        if (node.childNodes[i].nodeType !== 1) {
                            continue;
                        }
                        if (expr.matchElement(node.childNodes[i])) {
                            matchedElements = matchedElements + 1;
                        }
                        matchedElements = matchedElements + checkForUniqueness(expr, node.childNodes[i]);
                    }
                    return matchedElements;
                }
                function buildIndexAccordingToParent(target) {
                    if (target && target.parentNode) {
                        try {
                            let length = target.parentNode.children.length;
                            for (let i = 0; i < length; i++) {
                                if (target == target.parentNode.children[i]) {
                                    return i;
                                }
                            }
                        }
                        catch (err) {
                            return 0;
                        }
                    }
                    return -1;
                }
                function buildIndexAccordingToParentBasedTree(startTarget, target) {
                    let items = startTarget.getElementsByTagName(target.tagName);
                    for (let i = 0; i < items.length; i++) {
                        if (target == items[i]) {
                            return i;
                        }
                    }
                    return -1;
                }
                Findxs.buildIndexAccordingToParentBasedTree = buildIndexAccordingToParentBasedTree;
                function getAllElementsAccordingToClause(startTarget, clause, items) {
                    try {
                        let chlidrenCount = startTarget.children.length;
                        for (let i = 0; i < chlidrenCount; i++) {
                            if (clause.match(startTarget.children[i]) == true) {
                                items[items.length] = startTarget.children[i];
                            }
                            getAllElementsAccordingToClause(startTarget.children[i], clause, items);
                        }
                    }
                    catch (err) {
                        return;
                    }
                }
                function getElementTextContent(element) {
                    let retStr = "";
                    let appendVal = "";
                    if (element.nodeType === 3) {
                        retStr = element.textContent;
                    }
                    let count = element.childNodes.length;
                    for (let i = 0; i < count; i++) {
                        let child = element.childNodes[i];
                        if (child.nodeType === 3) {
                            appendVal += child.textContent.trim();
                        }
                    }
                    if (appendVal.length > 0) {
                        retStr = appendVal;
                    }
                    return retStr;
                }
                Findxs.getElementTextContent = getElementTextContent;
                function generateXPath(element) {
                    try {
                        let path = new Array();
                        let recurseFlag = true;
                        let currentIndex = 0;
                        while (recurseFlag) {
                            if (element == null) {
                                recurseFlag = false;
                                break;
                            }
                            path[currentIndex] = "/" + element.tagName + "[" + (buildIndexAccordingToParent(element) + 1).toString() + "]";
                            currentIndex++;
                            if (element.tagName === "HTML") {
                                break;
                            }
                            element = element.parentNode;
                        }
                        let sb = "";
                        for (let i = path.length - 1; i >= 0; i--) {
                            sb = sb + path[i];
                        }
                        return sb;
                    }
                    catch (ex) {
                        alert("error");
                        return "";
                    }
                }
                Findxs.generateXPath = generateXPath;
                function replaceAmp(val) {
                    let result = val.replace("&", "&amp;");
                    return result;
                }
                Findxs.replaceAmp = replaceAmp;
                function getData() {
                    return data;
                }
                function setData(d) {
                    data = d;
                }
                Findxs.setData = setData;
            })(Findxs = Recorder.Findxs || (Recorder.Findxs = {}));
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            var UiManager;
            (function (UiManager) {
                const MOUSE_MSG_DAMPING_INTERVAL = 500;
                const SCROLL_MSG_DAMPING_INTERVAL = 100;
                let tWin = null;
                let tDoc = null;
                let observer = null;
                let globalElementIndex = 0;
                let lastElement = null;
                let lastMouseMoveTime = new Date();
                let highlight = false;
                let pinScreen = false;
                let listenersAttached = false;
                let scrollTimeout = null;
                let lastX = 0;
                let lastY = 0;
                function init() {
                    tWin = parent.window;
                    tDoc = parent.window.document;
                    observer = new MutationObserver(refreshFrameListeners);
                    testStudioWsLogger.info("UiManager initialized.");
                }
                UiManager.init = init;
                function updateSettings(settings) {
                    enablePinScreen(settings.UseScreenshotCache);
                }
                UiManager.updateSettings = updateSettings;
                function adjustListeners() {
                    let shouldListen = highlight || pinScreen;
                    if (shouldListen && !listenersAttached) {
                        attachListeners();
                        listenersAttached = true;
                    }
                    else if (!shouldListen && listenersAttached) {
                        detachListeners();
                        listenersAttached = false;
                    }
                }
                function attachListeners() {
                    observer.observe(telerik_jsRecorder_teststudio.getTDoc().documentElement, { childList: true, subtree: true, characterData: true });
                    hookOverlayDocumentEvents(telerik_jsRecorder_teststudio.getTDoc());
                    telerik_jsRecorder_teststudio.enumFrames(tWin, (frame) => {
                        hookOverlayDocumentEvents(frame);
                    });
                }
                function detachListeners() {
                    unhookOverlayDocumentEvents(telerik_jsRecorder_teststudio.getTDoc());
                    observer.disconnect();
                    telerik_jsRecorder_teststudio.enumFrames(tWin, (frame) => {
                        unhookOverlayDocumentEvents(frame);
                    });
                }
                function hookOverlayDocumentEvents(doc) {
                    doc.addEventListener("mousemove", onMouseMove, true);
                    doc.addEventListener("mouseout", onMouseOut, true);
                    doc.addEventListener("scroll", onScroll, true);
                }
                function unhookOverlayDocumentEvents(doc) {
                    doc.removeEventListener("mousemove", onMouseMove, true);
                    doc.removeEventListener("mouseout", onMouseOut, true);
                    doc.removeEventListener("scroll", onScroll, true);
                }
                function refreshFrameListeners() {
                    telerik_jsRecorder_teststudio.enumFrames(tWin, (frame) => {
                        unhookOverlayDocumentEvents(frame);
                    });
                    telerik_jsRecorder_teststudio.enumFrames(tWin, (frame) => {
                        hookOverlayDocumentEvents(frame);
                    });
                }
                function enableHighlight(value) {
                    highlight = value;
                    adjustListeners();
                }
                UiManager.enableHighlight = enableHighlight;
                function enablePinScreen(value) {
                    pinScreen = value;
                    adjustListeners();
                }
                UiManager.enablePinScreen = enablePinScreen;
                function onScroll() {
                    clearTimeout(scrollTimeout);
                    scrollTimeout = setTimeout(onScrollTimer, SCROLL_MSG_DAMPING_INTERVAL);
                }
                function onScrollTimer() {
                    if (pinScreen) {
                        let msg = JSON.stringify({ tjsr_v_2_message: "sendInvalidatePinnedScreenshot" });
                        window.top.postMessage(msg, "*");
                    }
                    reportElementUnderMouse();
                }
                function onMouseOut(args) {
                }
                function getElementGlobalIndex(root, element) {
                    if (root == element) {
                        return true;
                    }
                    for (let i = 0; i < root.children.length; i++) {
                        if (root.children[i] == element) {
                            return true;
                        }
                        globalElementIndex++;
                        if (getElementGlobalIndex(root.children[i], element) == true) {
                            return true;
                        }
                    }
                    return false;
                }
                function onMouseMove(args) {
                    lastX = args.clientX;
                    lastY = args.clientY;
                    let currentMoment = new Date();
                    if (lastElement !== args.target ||
                        (currentMoment - lastMouseMoveTime) > MOUSE_MSG_DAMPING_INTERVAL) {
                        lastElement = args.target;
                        lastMouseMoveTime = currentMoment;
                        reportElementBounds(lastElement);
                    }
                }
                function reportElementUnderMouse() {
                    let element = document.elementFromPoint(lastX, lastY);
                    reportElementBounds(element);
                }
                function reportElementBounds(element) {
                    let elementDimensions = getElementDimensions(element);
                    let elementData = new Array();
                    elementData.push(elementDimensions);
                    if (pinScreen) {
                        let msg = JSON.stringify({ tjsr_v_2_message: "sendPinScreenshot", data: elementData });
                        window.top.postMessage(msg, "*");
                    }
                    if (highlight) {
                        appendElementParentDimensions(element, elementData);
                        let msg = JSON.stringify({ tjsr_v_2_message: "sendElementBounds", data: elementData });
                        window.top.postMessage(msg, "*");
                    }
                }
                function appendElementParentDimensions(element, elementData) {
                    let i = 0;
                    let parentEl = element.parentElement;
                    while (i < 15 && parentEl != null) {
                        i++;
                        let pElDimensions = getElementDimensions(parentEl);
                        elementData.push(pElDimensions);
                        parentEl = parentEl.parentElement;
                    }
                }
                function getElementDimensions(element) {
                    globalElementIndex = 0;
                    getElementGlobalIndex(element.ownerDocument, element);
                    let frameIndex = telerik_jsRecorder_teststudio.getElementFrameIndex(tWin, element);
                    let originalRect = getMainDocumentRalatedRect(element);
                    let elementDimensions = {
                        top: originalRect.top,
                        left: originalRect.left,
                        height: originalRect.height,
                        width: originalRect.width,
                        bottom: originalRect.bottom,
                        right: originalRect.right,
                        elementIndex: globalElementIndex,
                        elementTagName: element.tagName.toLocaleLowerCase(),
                        frameIndex: frameIndex
                    };
                    return elementDimensions;
                }
                function getElementDimensionsRectangle(element) {
                    globalElementIndex = 0;
                    getElementGlobalIndex(element.ownerDocument, element);
                    let originalRect = getMainDocumentRalatedRect(element);
                    return new TestStudio.Common.Rectangle(originalRect.left, originalRect.top, originalRect.width, originalRect.height, originalRect.right, originalRect.bottom);
                }
                UiManager.getElementDimensionsRectangle = getElementDimensionsRectangle;
                function getElementFrames(win, element, foundframes) {
                    if (win && win.frames && win.frames.length > 0) {
                        for (let ii = 0; ii < win.frames.length; ii++) {
                            let frame = win.frames[ii];
                            if (element.ownerDocument == frame.document) {
                                foundframes.push(frame);
                                return true;
                            }
                            if (getElementFrames(frame.window, element, foundframes) == true) {
                                foundframes.push(frame);
                                return true;
                            }
                        }
                    }
                    return false;
                }
                function getMainDocumentRalatedRect(element) {
                    let originalRect = element.getBoundingClientRect();
                    let rect = {
                        top: originalRect.top,
                        left: originalRect.left,
                        height: originalRect.height,
                        width: originalRect.width,
                        bottom: originalRect.bottom,
                        right: originalRect.right
                    };
                    if (element.ownerDocument != tDoc) {
                        let foundframes = [];
                        getElementFrames(tWin, element, foundframes);
                        let frameBorderWidth = 2;
                        for (let ii = 0; ii < foundframes.length; ii++) {
                            let frameElement = foundframes[ii].frameElement;
                            let framePadding = getFramePadding(frameElement);
                            let parentRect = frameElement.getBoundingClientRect();
                            rect.top += parentRect.top + frameBorderWidth + framePadding.tp;
                            rect.left += parentRect.left + frameBorderWidth + framePadding.lp;
                            rect.bottom += parentRect.top + frameBorderWidth;
                            rect.right += parentRect.left + frameBorderWidth;
                        }
                    }
                    return rect;
                }
                UiManager.getMainDocumentRalatedRect = getMainDocumentRalatedRect;
                function getFramePadding(targetFrameElement) {
                    let tp;
                    let lp;
                    try {
                        if (window.jQuery != null) {
                            lp = jQuery(targetFrameElement).css("padding-left") ? parseInt(jQuery(targetFrameElement).css("padding-left"), 10) : 0;
                            tp = jQuery(targetFrameElement).css("padding-top") ? parseInt(jQuery(targetFrameElement).css("padding-top"), 10) : 0;
                        }
                        else {
                            lp = targetFrameElement.style.paddingLeft ? parseInt(targetFrameElement.style.paddingLeft, 10) : 0;
                            tp = targetFrameElement.style.paddingTop ? parseInt(targetFrameElement.style.paddingTop, 10) : 0;
                        }
                    }
                    catch (ex) {
                        lp = targetFrameElement.style.paddingLeft ? parseInt(targetFrameElement.style.paddingLeft, 10) : 0;
                        tp = targetFrameElement.style.paddingTop ? parseInt(targetFrameElement.style.paddingTop, 10) : 0;
                    }
                    return { lp: lp, tp: tp };
                }
                function getTWin() {
                    return tWin;
                }
                UiManager.getTWin = getTWin;
                function setTWin(value) {
                    tWin = value;
                }
                UiManager.setTWin = setTWin;
            })(UiManager = Recorder.UiManager || (Recorder.UiManager = {}));
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            var Utils;
            (function (Utils) {
                let cachedBrowserName = null;
                function fromStorage(key, defvalue) {
                    let o = window.localStorage[key];
                    if (o == "undefined" || o == null) {
                        return defvalue;
                    }
                    return o;
                }
                Utils.fromStorage = fromStorage;
                function toStorage(key, value) {
                    window.localStorage[key] = value.toString();
                }
                Utils.toStorage = toStorage;
                function delStorage(key) {
                    window.localStorage.removeItem(key);
                }
                Utils.delStorage = delStorage;
                function isParentOf(child, parent) {
                    if (child == parent) {
                        return true;
                    }
                    if (child == null) {
                        return false;
                    }
                    let p = child.parentNode;
                    while (p != null) {
                        if (p == parent) {
                            return true;
                        }
                        else {
                            p = p.parentNode;
                        }
                    }
                    return false;
                }
                Utils.isParentOf = isParentOf;
                function sleep(millis) {
                    let start = (new Date()).getTime();
                    let curTime = null;
                    do {
                        curTime = (new Date()).getTime();
                    } while (curTime - start < millis);
                }
                Utils.sleep = sleep;
                function type(object) {
                    return !!object && Object.prototype.toString.call(object).match(/(\w+)\]/)[1];
                }
                Utils.type = type;
                function getCaret(target) {
                    try {
                        if (target.selectionStart) {
                            return target.selectionStart;
                        }
                    }
                    catch (ex) {
                    }
                }
                Utils.getCaret = getCaret;
                function getBrowserName() {
                    if (cachedBrowserName === null) {
                        let N = navigator.appName;
                        let ua = navigator.userAgent;
                        let tem = ua.match(/version\/([\.\d]+)/i);
                        let M = ua.match(/(opera|chrome|safari|firefox|msie)\/?\s*(\.?\d+(\.\d+)*)/i);
                        if ((M && tem) != null) {
                            M[2] = tem[1];
                        }
                        M = M ? [M[1], M[2]] : [N, navigator.appVersion, "-?"];
                        if (ua.indexOf("Edg") >= 0) {
                            cachedBrowserName = "edgechromium";
                        }
                        else {
                            cachedBrowserName = M[0];
                        }
                    }
                    return cachedBrowserName;
                }
                Utils.getBrowserName = getBrowserName;
            })(Utils = Recorder.Utils || (Recorder.Utils = {}));
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class TestStudioContext {
                constructor(port, mode, version) {
                    this.port = port;
                    this.mode = mode;
                    this.version = version;
                }
            }
            Common.TestStudioContext = TestStudioContext;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class UrlHelper {
                static getQueryParameterByName(url, paramName) {
                    paramName = paramName.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
                    let regex = new RegExp("[\\?&]" + paramName + "=([^&#]*)");
                    let results = regex.exec(url);
                    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
                }
                static getTestStudioContextFromUrl(url) {
                    if (url.indexOf(UrlHelper.startPageBaseUrl) === -1) {
                        return new Common.TestStudioContext(null, null, null);
                    }
                    return new Common.TestStudioContext(UrlHelper.getQueryParameterByName(url, "port"), UrlHelper.getQueryParameterByName(url, "mode"), UrlHelper.getQueryParameterByName(url, "version"));
                }
            }
            UrlHelper.startPageBaseUrl = "/WebUI/teststudio_start_page.html";
            Common.UrlHelper = UrlHelper;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            var Mediator;
            (function (Mediator) {
                let logger = null;
                let domModel;
                let globalIndex = 0;
                function init() {
                    logger = testStudioWsLogger;
                    if (window.constructor.prototype && window.constructor.prototype.addEventListener) {
                        window.constructor.prototype.addEventListener.call(window, "message", handleCommandMessage, false);
                    }
                    else {
                        window.addEventListener("message", handleCommandMessage);
                    }
                    sendRecorderCommand({ command: "getSettings", data: "" });
                    logger.info("Mediator: Initialized");
                }
                Mediator.init = init;
                function sendRecorderCommand(cmd) {
                    window.postMessage(JSON.stringify({ tjsr_v_2_message: "sendRecorderCommand", command: cmd }), "*");
                }
                Mediator.sendRecorderCommand = sendRecorderCommand;
                function findElementDomIndex(element) {
                    let index = -1;
                    for (let ii = 0; ii < domModel.elementMap.length; ii++) {
                        if (domModel.elementMap[ii] == element) {
                            index = ii;
                            break;
                        }
                    }
                    return index;
                }
                function findElementByIndex(root, index) {
                    if (globalIndex == index) {
                        return root;
                    }
                    for (let i = 0; i < root.children.length; i++) {
                        globalIndex++;
                        if (globalIndex == index) {
                            return root.children[i];
                        }
                        let el = findElementByIndex(root.children[i], index);
                        if (el != null) {
                            return el;
                        }
                    }
                    return null;
                }
                function showRecorder() {
                    sendRecorderCommand({ command: "showRecorder", data: telerik_jsRecorder_utils.getBrowserName().toLowerCase() });
                }
                function parseSettings(raw) {
                    try {
                        return JSON.parse(raw);
                    }
                    catch (ex) {
                        return {};
                    }
                }
                function handleCommandMessage(e) {
                    let jObj = null;
                    try {
                        jObj = JSON.parse(e.data);
                    }
                    catch (ex) {
                    }
                    if (!jObj || !jObj.tjsr_v_2_message) {
                        return;
                    }
                    if (TestStudio.Common.UrlHelper.getTestStudioContextFromUrl(window.location.href).mode === "1" &&
                        jObj.tjsr_v_2_message !== "navigateToUrl" &&
                        jObj.tjsr_v_2_message !== "showRecorder") {
                        return;
                    }
                    switch (jObj.tjsr_v_2_message) {
                        case "userSettings":
                            let settings = parseSettings(jObj.data);
                            telerik_jsRecorder_findxs.setData(settings);
                            telerik_jsRecorder_uiManager.updateSettings(settings);
                            break;
                        case "isResponsive":
                            if (jObj.browserType.toLowerCase() === telerik_jsRecorder_utils.getBrowserName().toLowerCase()) {
                                sendRecorderCommand({ command: "isResponsiveResponse", data: "" });
                            }
                            break;
                        case "enableRecording":
                            if (jObj.data) {
                                telerik_jsRecorder_teststudio.record();
                            }
                            else {
                                telerik_jsRecorder_teststudio.stop();
                            }
                            break;
                        case "enableHighlight":
                            telerik_jsRecorder_uiManager.enableHighlight(jObj.data);
                            break;
                        case "navigateForward":
                            history.go(1);
                            break;
                        case "navigateBackward":
                            history.go(-1);
                            break;
                        case "refreshBrowser":
                            window.location.reload();
                            break;
                        case "navigateToUrl":
                            window.location.href = jObj.data.url;
                            break;
                        case "showRecorder":
                            showRecorder();
                            break;
                        case "sendElementBounds":
                            sendRecorderCommand({ command: "elementBounds", data: jObj.data });
                            break;
                        case "sendPinScreenshot":
                            sendRecorderCommand({ command: "pinScreenshot", data: jObj.data });
                            break;
                        case "sendInvalidatePinnedScreenshot":
                            sendRecorderCommand({ command: "invalidatePinnedScreenshot", data: jObj.data });
                            break;
                        case "getElementBounds":
                            let frames = telerik_jsRecorder_teststudio.getAllFrames(telerik_jsRecorder_uiManager.getTWin());
                            let doc = document;
                            if (jObj.frameIndex != -1) {
                                doc = frames[jObj.frameIndex].document;
                            }
                            globalIndex = -1;
                            let element = findElementByIndex(doc, jObj.elementIndex);
                            if (!jObj.isMutation) {
                                element.scrollIntoView({ block: "center" });
                            }
                            let frameIndex = telerik_jsRecorder_teststudio.getElementFrameIndex(telerik_jsRecorder_uiManager.getTWin(), element);
                            let originalRect = telerik_jsRecorder_uiManager.getMainDocumentRalatedRect(element);
                            let elementDimensions = {
                                top: originalRect.top,
                                left: originalRect.left,
                                height: originalRect.height,
                                width: originalRect.width,
                                bottom: originalRect.bottom,
                                right: originalRect.right,
                                elementIndex: jObj.elementIndex,
                                frameIndex: jObj.frameIndex,
                                elementTagName: element.tagName.toLocaleLowerCase()
                            };
                            sendRecorderCommand({ command: "elementBounds", data: [elementDimensions] });
                            break;
                        default:
                            break;
                    }
                }
            })(Mediator = Recorder.Mediator || (Recorder.Mediator = {}));
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class DragDropWindowData {
                constructor(windowWidth, windowHeight, windowX, windowY, scrollLeft, scrollTop, windowDropPointX, windowDropPointY) {
                    this.windowWidth = windowWidth;
                    this.windowHeight = windowHeight;
                    this.windowX = windowX;
                    this.windowY = windowY;
                    this.scrollLeft = scrollLeft;
                    this.scrollTop = scrollTop;
                    this.windowDropPointX = windowDropPointX;
                    this.windowDropPointY = windowDropPointY;
                }
                getWindowWidth() {
                    return this.windowWidth;
                }
                setWindowWidth(value) {
                    this.windowWidth = value;
                }
                getWindowHeight() {
                    return this.windowHeight;
                }
                setWindowHeight(value) {
                    this.windowHeight = value;
                }
                getWindowX() {
                    return this.windowX;
                }
                setWindowX(value) {
                    this.windowX = value;
                }
                getWindowY() {
                    return this.windowY;
                }
                setWindowY(value) {
                    this.windowY = value;
                }
                getScrollLeft() {
                    return this.scrollLeft;
                }
                setScrollLeft(value) {
                    this.scrollLeft = value;
                }
                getScrollTop() {
                    return this.scrollTop;
                }
                setScrollTop(value) {
                    this.scrollTop = value;
                }
                getWindowDropPointX() {
                    return this.windowDropPointX;
                }
                setWindowDropPointX(value) {
                    this.windowDropPointX = value;
                }
                getWindowDropPointY() {
                    return this.windowDropPointY;
                }
                setWindowDropPointY(value) {
                    this.windowDropPointY = value;
                }
            }
            Recorder.DragDropWindowData = DragDropWindowData;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class TextTypingInfo {
                constructor() {
                    this.elementText = "";
                    this.caretPosition = 0;
                    this.typedText = "";
                    this.isTextArea = false;
                    this.isBackSpace = false;
                }
                createFromTarget(target) {
                    this.elementText = target.value;
                    if (target.contentEditable.toLowerCase() === "true") {
                        this.elementText = target.innerText;
                    }
                    if (!this.elementText) {
                        this.elementText = target.textContent;
                    }
                    this.caretPosition = telerik_jsRecorder_utils.getCaret(target);
                    this.isTextArea = target.tagName.toLowerCase() === "textarea";
                }
                getElementText() {
                    return this.elementText;
                }
                setElementText(value) {
                    this.elementText = value;
                }
                getCaretPosition() {
                    return this.caretPosition;
                }
                setCaretPosition(value) {
                    this.caretPosition = value;
                }
                getTypedText() {
                    return this.typedText;
                }
                setTypedText(value) {
                    this.typedText = value;
                }
                getIsTextArea() {
                    return this.isTextArea;
                }
                setIsTextArea(value) {
                    this.isTextArea = value;
                }
                getIsBackSpace() {
                    return this.isBackSpace;
                }
                setIsBackSpace(value) {
                    this.isBackSpace = value;
                }
            }
            Recorder.TextTypingInfo = TextTypingInfo;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class PageUri {
                constructor(url, title) {
                    this.url = url;
                    this.title = title;
                }
                getUrl() {
                    return this.url;
                }
                setUrl(value) {
                    this.url = value;
                }
                getTitle() {
                    return this.title;
                }
                setTitle(value) {
                    this.title = value;
                }
            }
            Recorder.PageUri = PageUri;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class SpecialKey {
                constructor(isSpecialKey, data) {
                    this.isSpecialKey = isSpecialKey;
                    this.data = data;
                }
            }
            Recorder.SpecialKey = SpecialKey;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            var Enums;
            (function (Enums) {
                let CapturedBrowserCommandType;
                (function (CapturedBrowserCommandType) {
                    CapturedBrowserCommandType[CapturedBrowserCommandType["Click"] = 0] = "Click";
                    CapturedBrowserCommandType[CapturedBrowserCommandType["SetText"] = 1] = "SetText";
                    CapturedBrowserCommandType[CapturedBrowserCommandType["Check"] = 2] = "Check";
                    CapturedBrowserCommandType[CapturedBrowserCommandType["SetDropDown"] = 3] = "SetDropDown";
                    CapturedBrowserCommandType[CapturedBrowserCommandType["ScrollIntoView"] = 4] = "ScrollIntoView";
                    CapturedBrowserCommandType[CapturedBrowserCommandType["InvokeEvent"] = 5] = "InvokeEvent";
                    CapturedBrowserCommandType[CapturedBrowserCommandType["InvokeScript"] = 6] = "InvokeScript";
                    CapturedBrowserCommandType[CapturedBrowserCommandType["DoubleClick"] = 7] = "DoubleClick";
                    CapturedBrowserCommandType[CapturedBrowserCommandType["RightClick"] = 8] = "RightClick";
                    CapturedBrowserCommandType[CapturedBrowserCommandType["ListBoxSelect"] = 9] = "ListBoxSelect";
                    CapturedBrowserCommandType[CapturedBrowserCommandType["NotSet"] = 10] = "NotSet";
                })(CapturedBrowserCommandType = Enums.CapturedBrowserCommandType || (Enums.CapturedBrowserCommandType = {}));
            })(Enums = Common.Enums || (Common.Enums = {}));
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            var Enums;
            (function (Enums) {
                let CapturedCommandCategoryType;
                (function (CapturedCommandCategoryType) {
                    CapturedCommandCategoryType[CapturedCommandCategoryType["BrowserCommand"] = 0] = "BrowserCommand";
                    CapturedCommandCategoryType[CapturedCommandCategoryType["DesktopCommand"] = 1] = "DesktopCommand";
                    CapturedCommandCategoryType[CapturedCommandCategoryType["UICue"] = 2] = "UICue";
                    CapturedCommandCategoryType[CapturedCommandCategoryType["Verification"] = 3] = "Verification";
                    CapturedCommandCategoryType[CapturedCommandCategoryType["SilverlightCommand"] = 4] = "SilverlightCommand";
                })(CapturedCommandCategoryType = Enums.CapturedCommandCategoryType || (Enums.CapturedCommandCategoryType = {}));
            })(Enums = Common.Enums || (Common.Enums = {}));
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            var Enums;
            (function (Enums) {
                let CapturedDesktopCommandType;
                (function (CapturedDesktopCommandType) {
                    CapturedDesktopCommandType[CapturedDesktopCommandType["LeftClick"] = 0] = "LeftClick";
                    CapturedDesktopCommandType[CapturedDesktopCommandType["LeftDoubleClick"] = 1] = "LeftDoubleClick";
                    CapturedDesktopCommandType[CapturedDesktopCommandType["LeftMouseDown"] = 2] = "LeftMouseDown";
                    CapturedDesktopCommandType[CapturedDesktopCommandType["LeftMouseUp"] = 3] = "LeftMouseUp";
                    CapturedDesktopCommandType[CapturedDesktopCommandType["RightClick"] = 4] = "RightClick";
                    CapturedDesktopCommandType[CapturedDesktopCommandType["RightMouseDown"] = 5] = "RightMouseDown";
                    CapturedDesktopCommandType[CapturedDesktopCommandType["RightMouseUp"] = 6] = "RightMouseUp";
                    CapturedDesktopCommandType[CapturedDesktopCommandType["DragStart"] = 7] = "DragStart";
                    CapturedDesktopCommandType[CapturedDesktopCommandType["DragStop"] = 8] = "DragStop";
                    CapturedDesktopCommandType[CapturedDesktopCommandType["DragDrop"] = 9] = "DragDrop";
                    CapturedDesktopCommandType[CapturedDesktopCommandType["Move"] = 10] = "Move";
                    CapturedDesktopCommandType[CapturedDesktopCommandType["HoverOver"] = 11] = "HoverOver";
                    CapturedDesktopCommandType[CapturedDesktopCommandType["Wheel"] = 12] = "Wheel";
                    CapturedDesktopCommandType[CapturedDesktopCommandType["KeyPress"] = 13] = "KeyPress";
                    CapturedDesktopCommandType[CapturedDesktopCommandType["KeyDown"] = 14] = "KeyDown";
                    CapturedDesktopCommandType[CapturedDesktopCommandType["KeyUp"] = 15] = "KeyUp";
                    CapturedDesktopCommandType[CapturedDesktopCommandType["NotSet"] = 16] = "NotSet";
                })(CapturedDesktopCommandType = Enums.CapturedDesktopCommandType || (Enums.CapturedDesktopCommandType = {}));
            })(Enums = Common.Enums || (Common.Enums = {}));
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class PaddingOffset {
                constructor(leftPadding, topPadding) {
                    this.leftPadding = leftPadding;
                    this.topPadding = topPadding;
                }
            }
            Common.PaddingOffset = PaddingOffset;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class Rectangle {
                constructor(left, top, width, height, right, bottom) {
                    this.left = left;
                    this.top = top;
                    this.width = width;
                    this.height = height;
                    this.right = right;
                    this.bottom = bottom;
                }
                static createFromClientRect(clientRect) {
                    return new Rectangle(clientRect.left, clientRect.top, clientRect.width, clientRect.height, clientRect.right, clientRect.bottom);
                }
                toString() {
                    return `${this.left},${this.top},${this.width},${this.height}`;
                }
            }
            Common.Rectangle = Rectangle;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class FramesUtils {
                static buildFlatFramesCollection(frame) {
                    let flatFramesColletion = [];
                    FramesUtils.buildFrames(frame, flatFramesColletion);
                    return flatFramesColletion;
                }
                static buildFramesInfo(framesCollection) {
                    let framesInfo = "";
                    for (let i = 0; i < framesCollection.length; ++i) {
                        let frameElement = framesCollection[i].frameElement;
                        if (frameElement != null) {
                            framesInfo += i;
                            framesInfo += "-@-";
                            framesInfo += frameElement.name;
                            framesInfo += "-@-";
                            framesInfo += frameElement.id;
                            framesInfo += "-@-";
                            framesInfo += frameElement.src;
                            framesInfo += "-@-";
                            let frameRect = FramesUtils.getFrameRectangle(frameElement);
                            framesInfo += frameRect.toString();
                            framesInfo += "-@-";
                            framesInfo += "-@-";
                            framesInfo += frameElement.tagName;
                            framesInfo += "-@-";
                            framesInfo += framesCollection[i].frameIndexRaw;
                            framesInfo += "-@-";
                            if (frameElement.hasAttribute("testStudioTag")) {
                                framesInfo += frameElement.getAttribute("testStudioTag");
                            }
                            framesInfo += "**;**";
                        }
                        else {
                            framesInfo += "**;**";
                        }
                    }
                    return framesInfo;
                }
                static getFrameRectangle(frameElement) {
                    let frameRect = frameElement.getBoundingClientRect();
                    let parentElement = frameElement.__webaii_parentWindow.frameElement;
                    let left = frameRect.left;
                    let top = frameRect.top;
                    while (parentElement != undefined) {
                        let parentRect = parentElement.getBoundingClientRect();
                        left += parentRect.left;
                        top += parentRect.top;
                        parentElement = parentElement.__webaii_parentWindow.frameElement;
                    }
                    return new Common.Rectangle(left, top, frameRect.width, frameRect.height, left + frameRect.width, top + frameRect.height);
                }
                static getFramePaddingOffset(targetFrameElement) {
                    let tp;
                    let lp;
                    try {
                        if (window.jQuery != undefined) {
                            lp = jQuery(targetFrameElement).css("padding-left") ? parseInt(jQuery(targetFrameElement).css("padding-left"), 10) : 0;
                            tp = jQuery(targetFrameElement).css("padding-top") ? parseInt(jQuery(targetFrameElement).css("padding-top"), 10) : 0;
                        }
                        else {
                            lp = targetFrameElement.style.paddingLeft ? parseInt(targetFrameElement.style.paddingLeft, 10) : 0;
                            tp = targetFrameElement.style.paddingTop ? parseInt(targetFrameElement.style.paddingTop, 10) : 0;
                        }
                    }
                    catch (ex) {
                        lp = targetFrameElement.style.paddingLeft ? parseInt(targetFrameElement.style.paddingLeft, 10) : 0;
                        tp = targetFrameElement.style.paddingTop ? parseInt(targetFrameElement.style.paddingTop, 10) : 0;
                    }
                    return new Common.PaddingOffset(lp, tp);
                }
                static buildFrames(parentWindow, flatFramesCollection) {
                    try {
                        if (parentWindow != undefined && parentWindow.frames != undefined && parentWindow.frames.length > 0) {
                            let count = parentWindow.frames.length;
                            for (let i = 0; i < count; ++i) {
                                let frame = parentWindow.frames[i];
                                if (frame == null || frame.frameElement == null) {
                                    continue;
                                }
                                let rect = frame.frameElement.getBoundingClientRect();
                                if (rect != null && rect.width > 0 && rect.height > 0) {
                                    frame.frameIndexRaw = i;
                                    flatFramesCollection[flatFramesCollection.length] = frame;
                                }
                                if (frame.frameElement != undefined) {
                                    frame.frameElement.__webaii_parentWindow = parentWindow;
                                    if (frame.frames.length > 0) {
                                        FramesUtils.buildFrames(frame, flatFramesCollection);
                                    }
                                }
                            }
                        }
                    }
                    catch (err) {
                        if (err.name !== "SecurityError") {
                            throw "BuildFrames().Error: " + err;
                        }
                    }
                }
            }
            Common.FramesUtils = FramesUtils;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio_1) {
        var Recorder;
        (function (Recorder) {
            var TestStudio;
            (function (TestStudio) {
                let initialized = false;
                let isRecording = false;
                let lastElementTarget = null;
                let isScrollAction = false;
                let isMouseButtonDown = false;
                let targetUnderMouse = null;
                let tWin = null;
                let tDoc = null;
                let framesInterval = 0;
                let isDragElement = false;
                let xMove = -1;
                let yMove = -1;
                let startDragPoint = null;
                let mouseDownInputValue;
                let observer = null;
                let logger = null;
                let lastKeyboardRecordCommandTimeout = null;
                let lastkeyboardRecordCommandTarget = null;
                let lastKeyboardRecordCommandTypedText = "";
                function init() {
                    if (initialized) {
                        return;
                    }
                    initialized = true;
                    logger = testStudioWsLogger;
                    tWin = parent.window;
                    tDoc = parent.window.document;
                    telerik_jsRecorder_mediator.sendRecorderCommand({ command: "refreshDom" });
                    observer = new MutationObserver(mutationRefresh);
                    observer.observe(tDoc.documentElement, { childList: true, subtree: true, characterData: true });
                    enumFrames(tWin, (frame) => {
                        observer.observe(frame.frameElement.contentDocument.documentElement, { childList: true, subtree: true, characterData: true });
                    });
                    logger.info("TestStudio Manager initialized.");
                }
                TestStudio.init = init;
                function enumFrames(win, callback) {
                    if (win && win.frames && win.frames.length > 0) {
                        for (let ii = 0; ii < win.frames.length; ii++) {
                            let frame = win.frames[ii];
                            try {
                                callback(frame);
                            }
                            catch (ex) {
                                continue;
                            }
                            if (frame && frame.frames && frame.frames.length > 0) {
                                enumFrames(frame, callback);
                            }
                        }
                    }
                }
                TestStudio.enumFrames = enumFrames;
                function getAllFrames(win) {
                    return TestStudio_1.Common.FramesUtils.buildFlatFramesCollection(win);
                }
                TestStudio.getAllFrames = getAllFrames;
                function getElementFrameIndex(win, element) {
                    let frameIndex = -1;
                    let frames = TestStudio_1.Common.FramesUtils.buildFlatFramesCollection(win);
                    for (let ii = 0; ii < frames.length; ii++) {
                        try {
                            if (element.ownerDocument == frames[ii].window.document) {
                                frameIndex = ii;
                                break;
                            }
                        }
                        catch (ex) {
                            continue;
                        }
                    }
                    return frameIndex;
                }
                TestStudio.getElementFrameIndex = getElementFrameIndex;
                function mutationRefresh() {
                    telerik_jsRecorder_mediator.sendRecorderCommand({ command: "mutationRefresh" });
                }
                function hookDocumentEvents(doc) {
                    doc.addEventListener("mousedown", captureMouseDownEvent, true);
                    doc.addEventListener("mouseup", captureMouseUpEvent, true);
                    doc.addEventListener("keyup", captureKeyUpEventDelayed, true);
                    doc.addEventListener("change", captureChangeEvent, true);
                    doc.addEventListener("mousemove", captureMouseMoveEvent, true);
                    doc.addEventListener("scroll", captureScrollEvent, true);
                }
                function unHookDocumentEvents(doc) {
                    doc.removeEventListener("mousedown", captureMouseDownEvent, true);
                    doc.removeEventListener("mouseup", captureMouseUpEvent, true);
                    doc.removeEventListener("keyup", captureKeyUpEventDelayed, true);
                    doc.removeEventListener("change", captureChangeEvent, true);
                    doc.removeEventListener("mousemove", captureMouseMoveEvent, true);
                    doc.removeEventListener("scroll", captureScrollEvent, true);
                }
                function record() {
                    if (isRecording) {
                        return;
                    }
                    if (telerik_jsRecorder_utils.getBrowserName() === "Firefox") {
                        tDoc.defaultView.addEventListener("beforeunload", beforeWindowUnload, true);
                    }
                    hookDocumentEvents(tDoc);
                    enumFrames(tWin, (frame) => {
                        hookDocumentEvents(frame.frameElement.contentDocument);
                    });
                    if (telerik_jsRecorder_utils.getBrowserName() === "Chrome" ||
                        telerik_jsRecorder_utils.getBrowserName() === "Firefox" ||
                        telerik_jsRecorder_utils.getBrowserName() === "edgechromium") {
                        framesInterval = setInterval(() => {
                            enumFrames(tWin, function (frame) {
                                hookDocumentEvents(frame.frameElement.contentDocument);
                            });
                        }, 2500);
                    }
                    isRecording = true;
                    logger.info("Recording started...");
                }
                TestStudio.record = record;
                function stop() {
                    if (!isRecording) {
                        return;
                    }
                    if (telerik_jsRecorder_utils.getBrowserName() === "Firefox") {
                        tDoc.defaultView.removeEventListener("beforeunload", beforeWindowUnload, true);
                    }
                    unHookDocumentEvents(tDoc);
                    enumFrames(tWin, function (frame) {
                        unHookDocumentEvents(frame.frameElement.contentDocument);
                    });
                    clearInterval(framesInterval);
                    isRecording = false;
                    logger.info("Recording stopped...");
                }
                TestStudio.stop = stop;
                function captureMouseMoveEvent(args) {
                    targetUnderMouse = args.target;
                    if (isMouseButtonDown) {
                        if (xMove === -1) {
                            xMove = args.screenX;
                        }
                        if (yMove === -1) {
                            yMove = args.screenY;
                        }
                        if (Math.abs(xMove - args.screenX) > 10 || Math.abs(yMove - args.screenY) > 10) {
                            isDragElement = true;
                        }
                    }
                    if (isDragElement && args.which === 0) {
                        captureMouseUpEvent(args);
                    }
                }
                function captureMouseDownEvent(args) {
                    if (args.target == null || args.which === 3) {
                        return;
                    }
                    let target = args.target;
                    if (target.tagName && target.tagName.toLowerCase() === "html") {
                        return;
                    }
                    lastElementTarget = target;
                    isScrollAction = false;
                    isMouseButtonDown = true;
                    if (telerik_jsRecorder_utils.getBrowserName() === "Firefox") {
                        startDragPoint = new Recorder.ActionPoint(args.layerX, args.layerY);
                    }
                    else {
                        startDragPoint = new Recorder.ActionPoint(args.offsetX, args.offsetY);
                    }
                    if (target.tagName.toLowerCase() === "input") {
                        let inputTarget = target;
                        if (inputTarget.type === "number" || inputTarget.type === "range") {
                            mouseDownInputValue = inputTarget.valueAsNumber;
                        }
                    }
                }
                function captureMouseUpEvent(args) {
                    if (args.target == null || args.which === 3) {
                        return;
                    }
                    let target = args.target;
                    if (target.tagName && target.tagName.toLowerCase() === "html") {
                        return;
                    }
                    let recordTarget = args.target;
                    let cmd = new Recorder.CapturedCommand();
                    let cmdData = {};
                    cmdData.modifierKeys = 0;
                    if (args.altKey) {
                        cmdData.modifierKeys |= 262144;
                    }
                    if (args.ctrlKey) {
                        cmdData.modifierKeys |= 131072;
                    }
                    if (args.shiftKey) {
                        cmdData.modifierKeys |= 65536;
                    }
                    if (isScrollAction) {
                        return;
                    }
                    if (isDragElement) {
                        let scrollTop = document.getElementsByTagName("html")[0].scrollTop;
                        let scrollLeft = document.getElementsByTagName("html")[0].scrollLeft;
                        cmdData.offset = telerik_jsRecorder_teststudio.getStartDragPoint();
                        cmdData.dragDropWindowData = new Recorder.DragDropWindowData(window.innerWidth, window.innerHeight, window.screenX, window.screenY, scrollLeft, scrollTop, args.screenX, args.screenY);
                        cmd.setCommandCategoryType(TestStudio_1.Common.Enums.CapturedCommandCategoryType.DesktopCommand);
                        cmd.setDesktopCommandType(TestStudio_1.Common.Enums.CapturedDesktopCommandType.DragDrop);
                        recordTarget = lastElementTarget;
                    }
                    else if (target.tagName.toLowerCase() === "textarea" ||
                        target.tagName.toLowerCase() === "select" ||
                        target.tagName.toLowerCase() === "option") {
                        cleanLastClickCommandState();
                        return;
                    }
                    else if (target.tagName.toLowerCase() === "input") {
                        let inputTarget = target;
                        if (inputTarget.type == null ||
                            inputTarget.type === "text" ||
                            inputTarget.type === "url" ||
                            inputTarget.type === "email" ||
                            inputTarget.type === "tel" ||
                            inputTarget.type === "password") {
                            cleanLastClickCommandState();
                            return;
                        }
                        if (inputTarget.type === "number") {
                            if (inputTarget.valueAsNumber > mouseDownInputValue) {
                                cmdData.inputNumberActionType = 0;
                            }
                            else if (inputTarget.valueAsNumber < mouseDownInputValue) {
                                cmdData.inputNumberActionType = 1;
                            }
                            else if (inputTarget.valueAsNumber !== mouseDownInputValue &&
                                !isNaN(inputTarget.valueAsNumber)) {
                                cmdData.inputNumberActionType = 0;
                            }
                            else {
                                cleanLastClickCommandState();
                                return;
                            }
                            let step = parseInt(inputTarget.step, 10);
                            if (isNaN(step) || step === 0) {
                                step = 1;
                            }
                            let stepsChange = Math.abs(inputTarget.valueAsNumber - mouseDownInputValue) / step;
                            cmdData.numberUpDownStep = stepsChange.toString();
                            cmd.setCommandCategoryType(TestStudio_1.Common.Enums.CapturedCommandCategoryType.BrowserCommand);
                            cmd.setBrowserCommandType(TestStudio_1.Common.Enums.CapturedBrowserCommandType.Click);
                        }
                        else if (inputTarget.type === "range") {
                            if (inputTarget.valueAsNumber === mouseDownInputValue ||
                                isNaN(inputTarget.valueAsNumber)) {
                                cleanLastClickCommandState();
                                return;
                            }
                            cmd.setCommandCategoryType(TestStudio_1.Common.Enums.CapturedCommandCategoryType.BrowserCommand);
                            cmd.setBrowserCommandType(TestStudio_1.Common.Enums.CapturedBrowserCommandType.Click);
                        }
                        else if (inputTarget.type === "search") {
                            let oldInputValue = inputTarget.value;
                            window.setTimeout(function () {
                                if (oldInputValue !== inputTarget.value) {
                                    let delayedCommand = new Recorder.CapturedCommand();
                                    delayedCommand.setCommandCategoryType(TestStudio_1.Common.Enums.CapturedCommandCategoryType.BrowserCommand);
                                    delayedCommand.setBrowserCommandType(TestStudio_1.Common.Enums.CapturedBrowserCommandType.SetText);
                                    delayedCommand.setTarget(args.target);
                                    let tpi = new Recorder.TextTypingInfo();
                                    tpi.createFromTarget(args.target);
                                    delayedCommand.setData(tpi);
                                    processRecordingCommand(delayedCommand);
                                }
                            }, 1);
                            cleanLastClickCommandState();
                            return;
                        }
                        else if (inputTarget.type === "checkbox" || (inputTarget.type === "radio" && !inputTarget.checked)) {
                            cmdData.checkedState = !inputTarget.checked;
                            cmd.setCommandCategoryType(TestStudio_1.Common.Enums.CapturedCommandCategoryType.BrowserCommand);
                            cmd.setBrowserCommandType(TestStudio_1.Common.Enums.CapturedBrowserCommandType.Check);
                        }
                        else {
                            cmd.setCommandCategoryType(TestStudio_1.Common.Enums.CapturedCommandCategoryType.BrowserCommand);
                            cmd.setBrowserCommandType(TestStudio_1.Common.Enums.CapturedBrowserCommandType.Click);
                        }
                    }
                    else if (target.tagName.toLowerCase() === "audio" || target.tagName.toLowerCase() === "video") {
                        cmdData.offset = telerik_jsRecorder_teststudio.getStartDragPoint();
                        cmd.setCommandCategoryType(TestStudio_1.Common.Enums.CapturedCommandCategoryType.BrowserCommand);
                        cmd.setBrowserCommandType(TestStudio_1.Common.Enums.CapturedBrowserCommandType.Click);
                    }
                    else {
                        cmd.setCommandCategoryType(TestStudio_1.Common.Enums.CapturedCommandCategoryType.BrowserCommand);
                        cmd.setBrowserCommandType(TestStudio_1.Common.Enums.CapturedBrowserCommandType.Click);
                    }
                    cleanLastClickCommandState();
                    cmd.setData(cmdData);
                    cmd.setTarget(recordTarget);
                    processRecordingCommand(cmd);
                }
                function cleanLastClickCommandState() {
                    isMouseButtonDown = false;
                    isDragElement = false;
                    xMove = -1;
                    yMove = -1;
                    lastElementTarget = null;
                }
                function getSpecialKeys(args, browser) {
                    let isSpecialKey = false;
                    let data = "";
                    if (browser === "Firefox" || ((browser === "Chrome" || browser === "edgechromium") && args.key)) {
                        switch (args.keyCode) {
                            case 13:
                                let target = args.target;
                                if (target.tagName.toLowerCase() === "textarea" || target.contentEditable === "true") {
                                    return new Recorder.SpecialKey(false, "Enter");
                                }
                                isSpecialKey = true;
                                data = "Enter";
                                break;
                            case 9:
                                data = "Tab";
                                isSpecialKey = true;
                                break;
                            case 27:
                                data = "Escape";
                                isSpecialKey = true;
                                break;
                            case 33:
                                data = "PgUp";
                                isSpecialKey = true;
                                break;
                            case 34:
                                data = "PgDown";
                                isSpecialKey = true;
                                break;
                            case 35:
                                data = "End";
                                isSpecialKey = true;
                                break;
                            case 36:
                                data = "Home";
                                isSpecialKey = true;
                                break;
                            case 37:
                                data = "Left";
                                isSpecialKey = true;
                                break;
                            case 38:
                                data = "Up";
                                isSpecialKey = true;
                                break;
                            case 39:
                                data = "Right";
                                isSpecialKey = true;
                                break;
                            case 40:
                                data = "Down";
                                isSpecialKey = true;
                                break;
                            case 45:
                                data = "Ins";
                                isSpecialKey = true;
                                break;
                            case 46:
                                data = "Del";
                                isSpecialKey = true;
                                break;
                            case 112:
                                data = "F1";
                                isSpecialKey = true;
                                break;
                            case 113:
                                data = "F2";
                                isSpecialKey = true;
                                break;
                            case 114:
                                data = "F3";
                                isSpecialKey = true;
                                break;
                            case 115:
                                data = "F4";
                                isSpecialKey = true;
                                break;
                            case 117:
                                data = "F6";
                                isSpecialKey = true;
                                break;
                            case 118:
                                data = "F7";
                                isSpecialKey = true;
                                break;
                            case 119:
                                data = "F8";
                                isSpecialKey = true;
                                break;
                            case 120:
                                data = "F9";
                                isSpecialKey = true;
                                break;
                            case 121:
                                data = "F10";
                                isSpecialKey = true;
                                break;
                            case 122:
                                data = "F11";
                                isSpecialKey = true;
                                break;
                            case 123:
                                data = "F12";
                                isSpecialKey = true;
                                break;
                            default:
                                break;
                        }
                        if (args.ctrlKey) {
                            switch (args.which) {
                                case 65:
                                    data = "A";
                                    isSpecialKey = true;
                                    break;
                                case 67:
                                    data = "C";
                                    isSpecialKey = true;
                                    break;
                                case 86:
                                    data = "V";
                                    isSpecialKey = true;
                                    break;
                                case 88:
                                    data = "X";
                                    isSpecialKey = true;
                                    break;
                                case 89:
                                    data = "Y";
                                    isSpecialKey = true;
                                    break;
                                case 90:
                                    data = "Z";
                                    isSpecialKey = true;
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                    return new Recorder.SpecialKey(isSpecialKey, data);
                }
                function captureKeyUpEventDelayed(args) {
                    if (args.target == null || isKeyExcludedFromRecording(args.keyCode)) {
                        return;
                    }
                    let specialKey = getSpecialKeys(args, telerik_jsRecorder_utils.getBrowserName());
                    if (specialKey.isSpecialKey) {
                        lastkeyboardRecordCommandTarget = null;
                        setTimeout(function () {
                            recordDesktopKeyboardAction(args, specialKey.data);
                        }, 500);
                    }
                    else {
                        let pressedKey = args.key;
                        if (pressedKey === "Enter") {
                            pressedKey = "\n";
                        }
                        if (lastkeyboardRecordCommandTarget === args.target &&
                            lastKeyboardRecordCommandTimeout != null) {
                            clearTimeout(lastKeyboardRecordCommandTimeout);
                            lastKeyboardRecordCommandTypedText += pressedKey;
                        }
                        else {
                            lastkeyboardRecordCommandTarget = args.target;
                            lastKeyboardRecordCommandTypedText = pressedKey;
                        }
                        lastKeyboardRecordCommandTimeout = setTimeout(function () {
                            recordKeyboardAction(args, lastKeyboardRecordCommandTypedText);
                        }, 500);
                    }
                }
                function isKeyExcludedFromRecording(keyCode) {
                    switch (keyCode) {
                        case 16:
                        case 17:
                        case 18:
                            return true;
                        default:
                            return false;
                    }
                }
                function recordDesktopKeyboardAction(args, data) {
                    let cmd = new Recorder.CapturedCommand();
                    cmd.setData(data);
                    if (args.shiftKey) {
                        cmd.setData("Shift+" + cmd.getData());
                    }
                    if (args.altKey) {
                        cmd.setData("Alt+" + cmd.getData());
                    }
                    if (args.ctrlKey) {
                        cmd.setData("Ctrl+" + cmd.getData());
                    }
                    cmd.setCommandCategoryType(TestStudio_1.Common.Enums.CapturedCommandCategoryType.DesktopCommand);
                    cmd.setDesktopCommandType(TestStudio_1.Common.Enums.CapturedDesktopCommandType.KeyPress);
                    cmd.setTarget(args.target);
                    processRecordingCommand(cmd);
                }
                function recordKeyboardAction(args, typedText) {
                    let target = args.target;
                    let cmd = new Recorder.CapturedCommand();
                    if (lastKeyboardRecordCommandTypedText === typedText &&
                        lastkeyboardRecordCommandTarget === args.target) {
                        lastKeyboardRecordCommandTypedText = "";
                    }
                    if (target.tagName.toLowerCase() !== "textarea" &&
                        target.tagName.toLowerCase() !== "input" &&
                        target.contentEditable.toLowerCase() !== "true") {
                        return;
                    }
                    let inputTarget = target;
                    if (inputTarget.type != null &&
                        (inputTarget.type !== "text" &&
                            inputTarget.type !== "textarea" &&
                            inputTarget.type !== "password" &&
                            inputTarget.type !== "file" &&
                            inputTarget.type !== "search" &&
                            inputTarget.type !== "email" &&
                            inputTarget.type !== "number" &&
                            inputTarget.type !== "tel" &&
                            inputTarget.type !== "url")) {
                        return;
                    }
                    cmd.setCommandCategoryType(TestStudio_1.Common.Enums.CapturedCommandCategoryType.BrowserCommand);
                    cmd.setBrowserCommandType(TestStudio_1.Common.Enums.CapturedBrowserCommandType.SetText);
                    let tpi = new Recorder.TextTypingInfo();
                    tpi.createFromTarget(target);
                    tpi.setTypedText(typedText);
                    cmd.setData(tpi);
                    cmd.setTarget(target);
                    processRecordingCommand(cmd);
                }
                function captureScrollEvent(args) {
                    if (args.type === "scroll") {
                        isScrollAction = true;
                    }
                }
                function captureChangeEvent(args) {
                    if (args.target.tagName.toLowerCase() !== "select") {
                        return;
                    }
                    let cmd = new Recorder.CapturedCommand();
                    cmd.setCommandCategoryType(TestStudio_1.Common.Enums.CapturedCommandCategoryType.BrowserCommand);
                    if (args.target["multiple"]) {
                        let selectedItems = new Array();
                        let selectCtrl = args.target;
                        for (let i = 0; i < selectCtrl.options.length; i++) {
                            let option = selectCtrl.options[i];
                            if (option.selected) {
                                selectedItems.push(new Recorder.SelectionValues(option.index, option.value, option.textContent));
                            }
                        }
                        let cmdData = selectedItems;
                        cmd.setData(cmdData);
                        cmd.setBrowserCommandType(TestStudio_1.Common.Enums.CapturedBrowserCommandType.ListBoxSelect);
                        cmd.setTarget(args.target);
                    }
                    else {
                        let cmdData = {};
                        let childrenCount = args.target.children.length;
                        for (let i = 0; i < childrenCount; i++) {
                            if (args.target.children[i].selected === true) {
                                cmdData = new Recorder.SelectionValues(i, args.target.children[i].value, args.target.children[i].text);
                                break;
                            }
                        }
                        cmd.setData(cmdData);
                        cmd.setTarget(args.target);
                        cmd.setBrowserCommandType(TestStudio_1.Common.Enums.CapturedBrowserCommandType.SetDropDown);
                    }
                    processRecordingCommand(cmd);
                }
                function beforeWindowUnload() {
                    if (isRecording && lastElementTarget) {
                        let target = lastElementTarget;
                        let cmd = new Recorder.CapturedCommand();
                        cmd.setCommandCategoryType(TestStudio_1.Common.Enums.CapturedCommandCategoryType.BrowserCommand);
                        cmd.setBrowserCommandType(TestStudio_1.Common.Enums.CapturedBrowserCommandType.Click);
                        cmd.setTarget(target);
                        processRecordingCommand(cmd);
                    }
                }
                function getTargetPage() {
                    return new Recorder.PageUri(tDoc.location.href, tDoc.title);
                }
                TestStudio.getTargetPage = getTargetPage;
                function processRecordingCommand(catpuredCommand) {
                    let target = catpuredCommand.getTarget();
                    catpuredCommand.setTimestamp(new Date());
                    catpuredCommand.setElementRect(TestStudio_1.Common.Rectangle.createFromClientRect(target.getBoundingClientRect()));
                    catpuredCommand.setElementDimensions(telerik_jsRecorder_uiManager.getElementDimensionsRectangle(target));
                    catpuredCommand.setTarget({});
                    catpuredCommand.setExpression(telerik_jsRecorder_findxs.buildExpression(target));
                    catpuredCommand.setFrameInfo(target.ownerDocument.defaultView && target.ownerDocument.defaultView.frameElement ? new Recorder.FrameInfo(target) : null);
                    catpuredCommand.setPage(getTargetPage());
                    telerik_jsRecorder_mediator.sendRecorderCommand({ command: "recordAction", data: catpuredCommand });
                }
                function createEvent(type, name) {
                    let evt = tDoc.createEvent(type);
                    if (type === "MouseEvent") {
                        evt.initMouseEvent(name, true, true, parent.window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
                    }
                    else {
                        if (type === "KeyboardEvents") {
                        }
                        else {
                            evt.initEvent(name, true, true);
                        }
                    }
                    return evt;
                }
                function decodeTarget(encodedTarget) {
                    let s = encodedTarget.split(":");
                    return parent.document.getElementsByTagName(s[0])[s[1]];
                }
                function getTDoc() {
                    return tDoc;
                }
                TestStudio.getTDoc = getTDoc;
                function setTDoc(value) {
                    tDoc = value;
                }
                function getStartDragPoint() {
                    return startDragPoint;
                }
                TestStudio.getStartDragPoint = getStartDragPoint;
                function setStartDragPoint(value) {
                    startDragPoint = value;
                }
                function getInitialized() {
                    return initialized;
                }
                TestStudio.getInitialized = getInitialized;
            })(TestStudio = Recorder.TestStudio || (Recorder.TestStudio = {}));
        })(Recorder = TestStudio_1.Recorder || (TestStudio_1.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            let LogSeverity;
            (function (LogSeverity) {
                LogSeverity[LogSeverity["INFO"] = 0] = "INFO";
                LogSeverity[LogSeverity["ERROR"] = 1] = "ERROR";
            })(LogSeverity = Common.LogSeverity || (Common.LogSeverity = {}));
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class Logger {
                static info(message) {
                    Logger.log(Common.LogSeverity[Common.LogSeverity.INFO], message);
                }
                static error(message) {
                    Logger.log(Common.LogSeverity[Common.LogSeverity.ERROR], message);
                }
                static log(level, message) {
                    let sb;
                    sb = `${Logger.getFormattedDate()} - `;
                    sb += `[${level}] `;
                    sb += message;
                    console.log(sb);
                }
                static getFormattedDate() {
                    let date = new Date();
                    let str = Logger.pad(date.getDate(), 2) + "/" + Logger.pad((date.getMonth() + 1), 2) + "/" + date.getFullYear()
                        + " " + Logger.pad(date.getHours(), 2) + ":" + Logger.pad(date.getMinutes(), 2) + ":"
                        + Logger.pad(date.getSeconds(), 2) + "." + Logger.pad(date.getMilliseconds(), 3);
                    return str;
                }
                static pad(num, size) {
                    let s = num + "";
                    while (s.length < size) {
                        s = "0" + s;
                    }
                    return s;
                }
            }
            Common.Logger = Logger;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class LoggerPageScript extends Common.Logger {
                static info(message) {
                    LoggerPageScript.log(Common.LogSeverity[Common.LogSeverity.INFO], message);
                }
                static error(message) {
                    LoggerPageScript.log(Common.LogSeverity[Common.LogSeverity.ERROR], message);
                }
                static log(level, message) {
                    let sb;
                    sb = `${Common.Logger.getFormattedDate()} - `;
                    sb += `[${level} - PAGE SCRIPT] `;
                    sb += message;
                    console.log(sb);
                    let logMsg = { message: "teststudio_v_2.log.message", data: sb };
                    window.postMessage(logMsg, "*");
                }
            }
            Common.LoggerPageScript = LoggerPageScript;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
let testStudioWsLogger = Telerik.TestStudio.Common.LoggerPageScript;
testStudioWsLogger.info("Loading recorder... ");
let telerik_jsRecorder_findxs = Telerik.TestStudio.Recorder.Findxs;
let telerik_jsRecorder_uiManager = Telerik.TestStudio.Recorder.UiManager;
telerik_jsRecorder_uiManager.init();
let telerik_jsRecorder_utils = Telerik.TestStudio.Recorder.Utils;
let telerik_jsRecorder_mediator = Telerik.TestStudio.Recorder.Mediator;
telerik_jsRecorder_mediator.init();
let telerik_jsRecorder_teststudio = Telerik.TestStudio.Recorder.TestStudio;
telerik_jsRecorder_teststudio.init();
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class Clauses {
                constructor(name, value, propertyName, type) {
                    this.compareType = 7;
                    this.trimChar = false;
                    this.value = value;
                    this.name = name;
                    this.propertyName = propertyName;
                    this.type = type;
                    if (value != undefined && value !== "") {
                        switch (value[0]) {
                            case "~":
                                this.trimChar = true;
                                this.compareType = 4;
                                break;
                            case "!":
                                this.trimChar = true;
                                this.compareType = 3;
                                break;
                            case "?":
                                this.trimChar = true;
                                this.compareType = 5;
                                break;
                            case "^":
                                this.trimChar = true;
                                this.compareType = 6;
                                break;
                            case "#":
                                this.trimChar = false;
                                this.compareType = 8;
                                break;
                            case "-":
                                this.trimChar = true;
                                this.compareType = 1;
                                break;
                            case "+":
                                this.trimChar = true;
                                this.compareType = 2;
                                break;
                            case "'":
                                this.trimChar = true;
                                break;
                            default:
                                break;
                        }
                        if (this.trimChar) {
                            this.value = value.substring(1);
                        }
                        if (this.compareType == 1 || this.compareType == 2) {
                            this.value = "";
                        }
                    }
                }
                stringCompare(a, b, compareType) {
                    switch (compareType) {
                        case 1:
                            return b == undefined || b === "";
                        case 2:
                            return !(b == undefined || b === "");
                        case 3:
                            return a.toLowerCase().indexOf(b.toLowerCase()) === -1;
                        case 4:
                            return a.toLowerCase().indexOf(b.toLowerCase()) !== -1;
                        case 5:
                            let lastIndex = a.toLowerCase().lastIndexOf(b.toLowerCase());
                            return lastIndex !== -1 && (lastIndex + b.length) === a.length;
                        case 6:
                            return a.toLowerCase().indexOf(b.toLowerCase()) === 0;
                        case 7:
                            return a.toLowerCase() == b.toLowerCase();
                        case 8:
                            let regex = new RegExp(b, "i");
                            return regex.test(a);
                        default:
                            break;
                    }
                    return false;
                }
                match(target) {
                    switch (this.type) {
                        case 0:
                            let actual = "";
                            if (target[this.propertyName]) {
                                actual = target[this.propertyName];
                            }
                            if (target.hasAttribute(this.propertyName)) {
                                actual = target.attributes[this.propertyName].nodeValue.toString();
                                if (this.propertyName === "id" || this.propertyName === "name" || this.propertyName === "href") {
                                    actual = telerik_jsRecorder_findxs.replaceAmp(actual);
                                }
                            }
                            if (actual === "") {
                                return false;
                            }
                            else {
                                return this.stringCompare(actual.toString(), this.value.toString(), this.compareType);
                            }
                        case 1:
                            if (!target.textContent || (target.textContent && target.textContent === "")) {
                                return false;
                            }
                            let contentToUse = telerik_jsRecorder_findxs.getElementTextContent(target);
                            if (contentToUse.length > telerik_jsRecorder_findxs.getMaxTextContentFind()) {
                                contentToUse = telerik_jsRecorder_findxs.getStartsWith + contentToUse.substr(0, telerik_jsRecorder_findxs.getMaxTextContentFind());
                            }
                            return this.stringCompare(contentToUse, this.value, this.compareType);
                        case 2:
                            let val = target.tagName.toLowerCase() + ":"
                                + telerik_jsRecorder_findxs.buildIndexAccordingToParentBasedTree(target.ownerDocument, target).toString();
                            return this.stringCompare(val, this.value, this.compareType);
                        case 3:
                            return this.stringCompare(telerik_jsRecorder_findxs.generateXPath(target), this.value, this.compareType);
                        case 4:
                            return this.stringCompare(target.tagName.toLowerCase(), this.value, this.compareType);
                        default:
                            break;
                    }
                    return false;
                }
                getValue() {
                    return this.value;
                }
                setValue(value) {
                    this.value = value;
                }
                getName() {
                    return this.name;
                }
                setName(value) {
                    this.name = value;
                }
                getType() {
                    return this.type;
                }
                setType(value) {
                    this.type = value;
                }
            }
            Recorder.Clauses = Clauses;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class FrameInfo {
                constructor(target) {
                    this.frameSrc = "";
                    this.frameId = "";
                    this.frameName = "";
                    this.frameIndex = -1;
                    if (target.ownerDocument.defaultView != undefined && target.ownerDocument.defaultView.frameElement != null) {
                        this.frameSrc = target.ownerDocument.defaultView.frameElement.src;
                        this.frameId = target.ownerDocument.defaultView.frameElement.id;
                        this.frameName = target.ownerDocument.defaultView.frameElement.name;
                        let thisRef = this;
                        let indexCounter = -1;
                        telerik_jsRecorder_teststudio.enumFrames(window.top, function (frame) {
                            indexCounter++;
                            if (target.ownerDocument.defaultView == frame) {
                                thisRef.frameIndex = indexCounter;
                            }
                        });
                        if (this.frameName == undefined || this.frameName == "") {
                            this.frameName = "Frame_" + this.frameIndex.toString();
                        }
                    }
                }
                getFrameSrc() {
                    return this.frameSrc;
                }
                setFrameSrc(value) {
                    this.frameSrc = value;
                }
                getFrameId() {
                    return this.frameId;
                }
                setFrameId(value) {
                    this.frameId = value;
                }
                getFrameName() {
                    return this.frameName;
                }
                setFrameName(value) {
                    this.frameName = value;
                }
                getFrameIndex() {
                    return this.frameIndex;
                }
                setFrameIndex(value) {
                    this.frameIndex = value;
                }
            }
            Recorder.FrameInfo = FrameInfo;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class Param {
                constructor(paramBuilder) {
                    this.canEdit = paramBuilder.getCanEdit();
                    this.select = paramBuilder.getSelect();
                    this.defaultValue = paramBuilder.getDefaultValue();
                    this.valueType = paramBuilder.getValueType();
                }
                getCanEdit() {
                    return this.canEdit;
                }
                setCanEdit(value) {
                    this.canEdit = value;
                }
                getSelect() {
                    return this.select;
                }
                setSelect(value) {
                    this.select = value;
                }
                getDefaultValue() {
                    return this.defaultValue;
                }
                setDefaultValue(value) {
                    this.defaultValue = value;
                }
                getValueType() {
                    return this.valueType;
                }
                setValueType(value) {
                    this.valueType = value;
                }
            }
            Recorder.Param = Param;
            class ParamBuilder {
                build() {
                    return new Param(this);
                }
                setCanEdit(value) {
                    this.canEdit = value;
                    return this;
                }
                setSelect(select) {
                    this.select = select;
                    return this;
                }
                setDefaultValue(defaultValue) {
                    this.defaultValue = defaultValue;
                    return this;
                }
                setValueType(value) {
                    this.valueType = value;
                    return this;
                }
                getCanEdit() {
                    return this.canEdit;
                }
                getSelect() {
                    return this.select;
                }
                getDefaultValue() {
                    return this.defaultValue;
                }
                getValueType() {
                    return this.valueType;
                }
            }
            Recorder.ParamBuilder = ParamBuilder;
            function BoolSelectParam(defaultValue) {
                return new ParamBuilder().setSelect([{ display: "True", value: true }, { display: "False", value: false }])
                    .setDefaultValue(defaultValue)
                    .setCanEdit(false)
                    .build();
            }
            function StringCompareSelectParam() {
                return new ParamBuilder().setSelect([{ display: "Exact", value: 0 },
                    { display: "Same", value: 1 },
                    { display: "Contains", value: 2 },
                    { display: "Does not contain", value: 3 },
                    { display: "Starts with", value: 4 },
                    { display: "Ends with", value: 5 },
                    { display: "RegEx", value: 6 }])
                    .setDefaultValue(0)
                    .setCanEdit(false)
                    .build();
            }
            function IntCompareSelectParam() {
                return new ParamBuilder().setSelect([{ display: "Equals", value: 0 },
                    { display: "Less Than", value: 1 },
                    { display: "Greater Than", value: 2 },
                    { display: "Less Than Or Equal", value: 3 },
                    { display: "Greater Than Or Equal", value: 4 },
                    { display: "Not Equal", value: 5 }])
                    .setDefaultValue(0)
                    .setCanEdit(false)
                    .build();
            }
            function SingleValueParam(defaultValue, valueType) {
                return new ParamBuilder().setDefaultValue(defaultValue)
                    .setValueType(valueType)
                    .setCanEdit(true)
                    .build();
            }
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class SelectionValues {
                constructor(index, value, text) {
                    this.index = index;
                    this.value = value;
                    this.text = text;
                }
                getIndex() {
                    return this.index;
                }
                setIndex(value) {
                    this.index = value;
                }
                getValue() {
                    return this.value;
                }
                setValue(value) {
                    this.value = value;
                }
                getText() {
                    return this.text;
                }
                setText(value) {
                    this.text = value;
                }
            }
            Recorder.SelectionValues = SelectionValues;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Recorder;
        (function (Recorder) {
            class Test {
                constructor(jsonObj) {
                    this.name = "(NewTest)";
                    this.steps = [];
                    this.name = jsonObj.name;
                    this.steps = jsonObj.steps;
                }
                addStep(step) {
                    this.steps.push(step);
                }
                numOfSteps() {
                    return this.steps.length;
                }
                getName() {
                    return this.name;
                }
                setName(value) {
                    this.name = value;
                }
                getSteps() {
                    return this.steps;
                }
                setSteps(value) {
                    this.steps = value;
                }
            }
            Recorder.Test = Test;
        })(Recorder = TestStudio.Recorder || (TestStudio.Recorder = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
