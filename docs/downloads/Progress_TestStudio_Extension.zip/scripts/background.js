var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class Windows {
                getCurrent(getInfo) {
                    if (getInfo) {
                        return new Promise((resolve, reject) => {
                            chrome.windows.getCurrent(getInfo, (result) => {
                                resolve(result);
                            });
                        });
                    }
                    else {
                        return new Promise((resolve, reject) => {
                            chrome.windows.getCurrent((result) => {
                                resolve(result);
                            });
                        });
                    }
                }
                onCreatedAddListener(callback) {
                    chrome.windows.onCreated.addListener(callback);
                }
            }
            class Tabs {
                executeScript(tabId, injectOptions) {
                    return new Promise((resolve, reject) => {
                        chrome.tabs.executeScript(tabId, injectOptions, (result) => {
                            resolve(result);
                        });
                    });
                }
                get(tabId) {
                    return new Promise((resolve, reject) => {
                        chrome.tabs.get(tabId, (tab) => {
                            chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(tab);
                        });
                    });
                }
                onActivatedAddListener(callback) {
                    chrome.tabs.onActivated.addListener(callback);
                }
                onCreatedAddListener(callback) {
                    chrome.tabs.onCreated.addListener(callback);
                }
                onRemovedAddListener(callback) {
                    chrome.tabs.onRemoved.addListener(callback);
                }
                onReplacedAddListener(callback) {
                    chrome.tabs.onReplaced.addListener(callback);
                }
                query(queryInfo) {
                    return new Promise((resolve, reject) => {
                        chrome.tabs.query(queryInfo, (result) => {
                            resolve(result);
                        });
                    });
                }
                sendMessage(tabId, args) {
                    return new Promise((resolve, reject) => {
                        chrome.tabs.sendMessage(tabId, args, (response) => {
                            chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
                        });
                    });
                }
            }
            class History {
                deleteAll() {
                    return new Promise((resolve, reject) => {
                        chrome.history.deleteAll(() => {
                            chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve();
                        });
                    });
                }
            }
            class Runtime {
                getURL(path) {
                    return chrome.runtime.getURL(path);
                }
                sendMessage(args) {
                    return new Promise((resolve, reject) => {
                        chrome.runtime.sendMessage(args, (response) => {
                            chrome.runtime.lastError ? reject(chrome.runtime.lastError) : resolve(response);
                        });
                    });
                }
                onMessageAddListener(callback) {
                    chrome.runtime.onMessage.addListener(callback);
                }
                id() {
                    return chrome.runtime.id;
                }
            }
            class BrowsingData {
                removeCache(options) {
                    return new Promise((resolve, reject) => {
                        chrome.browsingData.removeCache(options, () => {
                            resolve();
                        });
                    });
                }
                removeLocalStorage(options) {
                    return new Promise((resolve, reject) => {
                        chrome.browsingData.removeLocalStorage(options, () => {
                            resolve();
                        });
                    });
                }
            }
            class Cookies {
                getAll(details) {
                    return new Promise((resolve, reject) => {
                        chrome.cookies.getAll(details, (cookies) => {
                            resolve(cookies);
                        });
                    });
                }
                remove(details) {
                    return new Promise((resolve, reject) => {
                        chrome.cookies.remove(details, (result) => {
                            resolve(result);
                        });
                    });
                }
                set(details) {
                    return new Promise((resolve, reject) => {
                        chrome.cookies.set(details, (cookie) => {
                            resolve(cookie);
                        });
                    });
                }
            }
            class Storage {
                localSet(details) {
                    return new Promise((resolve, reject) => {
                        chrome.storage.sync.set(details, () => {
                            resolve();
                        });
                    });
                }
                localGet() {
                    return new Promise((resolve, reject) => {
                        chrome.storage.sync.get((items) => {
                            resolve(items);
                        });
                    });
                }
            }
            class Browser {
                static getBrowserName() {
                    if (navigator.userAgent.indexOf("Edg") >= 0) {
                        return "EdgeChromium";
                    }
                    return "Chrome";
                }
                static getBrowserVersion() {
                    if (navigator.userAgent.indexOf("Edg") >= 0) {
                        return window.navigator.appVersion.match(/Edg\/([^ ]*)/)[1];
                    }
                    return window.navigator.appVersion.match(/Chrome\/([^ ]*)/)[1];
                }
            }
            Browser.runtime = new Runtime();
            Browser.browsingData = new BrowsingData();
            Browser.cookies = new Cookies();
            Browser.history = new History();
            Browser.tabs = new Tabs();
            Browser.windows = new Windows();
            Browser.storage = new Storage();
            Common.Browser = Browser;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class Command {
                constructor(command) {
                    this.TargetFrameIndex = parseInt(command.TargetFrameIndex, 10);
                    this.TargetFrameId = command.TargetFrameId;
                    this.InError = command.InError;
                    this.Handled = command.Handled;
                    this.IsDialog = command.IsDialog;
                    this.HasFrames = command.HasFrames;
                    this.FramesInfo = command.FramesInfo;
                    this.Response = command.Response;
                    this.CommandType = command.CommandType;
                    this.InformationType = command.InformationType;
                    this.ActionType = command.ActionType;
                    this.Target = command.Target;
                    this.ClientId = command.ClientId;
                    this.RequestId = command.RequestId;
                    this.Cookies = command.Cookies;
                    this.Data = command.Data;
                }
            }
            Common.Command = Command;
            function cloneCommand(command) {
                return JSON.parse(JSON.stringify(command));
            }
            Common.cloneCommand = cloneCommand;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            var Enums;
            (function (Enums) {
                let BrowserActionType;
                (function (BrowserActionType) {
                    BrowserActionType[BrowserActionType["Click"] = 1] = "Click";
                    BrowserActionType[BrowserActionType["SetText"] = 2] = "SetText";
                    BrowserActionType[BrowserActionType["SelectDropDown"] = 3] = "SelectDropDown";
                    BrowserActionType[BrowserActionType["Check"] = 4] = "Check";
                    BrowserActionType[BrowserActionType["ScrollToVisible"] = 5] = "ScrollToVisible";
                    BrowserActionType[BrowserActionType["NavigateTo"] = 6] = "NavigateTo";
                    BrowserActionType[BrowserActionType["InvokeEvent"] = 7] = "InvokeEvent";
                    BrowserActionType[BrowserActionType["InvokeJsFunction"] = 8] = "InvokeJsFunction";
                    BrowserActionType[BrowserActionType["Refresh"] = 9] = "Refresh";
                    BrowserActionType[BrowserActionType["GoBack"] = 10] = "GoBack";
                    BrowserActionType[BrowserActionType["GoForward"] = 11] = "GoForward";
                    BrowserActionType[BrowserActionType["LoadString"] = 12] = "LoadString";
                    BrowserActionType[BrowserActionType["GetProperty"] = 13] = "GetProperty";
                    BrowserActionType[BrowserActionType["SetProperty"] = 14] = "SetProperty";
                    BrowserActionType[BrowserActionType["InvokeMethod"] = 15] = "InvokeMethod";
                    BrowserActionType[BrowserActionType["SetCookie"] = 16] = "SetCookie";
                    BrowserActionType[BrowserActionType["ScrollBy"] = 18] = "ScrollBy";
                    BrowserActionType[BrowserActionType["Stop"] = 19] = "Stop";
                    BrowserActionType[BrowserActionType["ClearHistory"] = 20] = "ClearHistory";
                    BrowserActionType[BrowserActionType["ClearFilesCache"] = 21] = "ClearFilesCache";
                    BrowserActionType[BrowserActionType["ClearCookies"] = 23] = "ClearCookies";
                    BrowserActionType[BrowserActionType["InvokeJsFunctionReturnJSON"] = 24] = "InvokeJsFunctionReturnJSON";
                    BrowserActionType[BrowserActionType["AttachEventHandler"] = 25] = "AttachEventHandler";
                    BrowserActionType[BrowserActionType["RemoveEventHandler"] = 26] = "RemoveEventHandler";
                    BrowserActionType[BrowserActionType["AddCustomSilverlightAssembly"] = 29] = "AddCustomSilverlightAssembly";
                    BrowserActionType[BrowserActionType["CloseWindow"] = 30] = "CloseWindow";
                    BrowserActionType[BrowserActionType["GetFramePadding"] = 31] = "GetFramePadding";
                    BrowserActionType[BrowserActionType["SwitchTab"] = 32] = "SwitchTab";
                    BrowserActionType[BrowserActionType["TagIndexFromClientRectangle"] = 33] = "TagIndexFromClientRectangle";
                    BrowserActionType[BrowserActionType["ViewPortAndScrollSize"] = 34] = "ViewPortAndScrollSize";
                    BrowserActionType[BrowserActionType["ScrollToDocumentCoordinates"] = 35] = "ScrollToDocumentCoordinates";
                })(BrowserActionType = Enums.BrowserActionType || (Enums.BrowserActionType = {}));
            })(Enums = Common.Enums || (Common.Enums = {}));
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            var Enums;
            (function (Enums) {
                let BrowserCommandType;
                (function (BrowserCommandType) {
                    BrowserCommandType[BrowserCommandType["Information"] = 1] = "Information";
                    BrowserCommandType[BrowserCommandType["Action"] = 2] = "Action";
                    BrowserCommandType[BrowserCommandType["Silverlight"] = 3] = "Silverlight";
                    BrowserCommandType[BrowserCommandType["Config"] = 4] = "Config";
                })(BrowserCommandType = Enums.BrowserCommandType || (Enums.BrowserCommandType = {}));
            })(Enums = Common.Enums || (Common.Enums = {}));
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            var Enums;
            (function (Enums) {
                let BrowserInformationType;
                (function (BrowserInformationType) {
                    BrowserInformationType[BrowserInformationType["ElementRectangle"] = 1] = "ElementRectangle";
                    BrowserInformationType[BrowserInformationType["FrameRectangle"] = 2] = "FrameRectangle";
                    BrowserInformationType[BrowserInformationType["DocumentMarkup"] = 4] = "DocumentMarkup";
                    BrowserInformationType[BrowserInformationType["IsReady"] = 5] = "IsReady";
                    BrowserInformationType[BrowserInformationType["Cookies"] = 6] = "Cookies";
                    BrowserInformationType[BrowserInformationType["ComputedStyle"] = 7] = "ComputedStyle";
                    BrowserInformationType[BrowserInformationType["InformationBar"] = 10] = "InformationBar";
                    BrowserInformationType[BrowserInformationType["QuerySelectorAll"] = 11] = "QuerySelectorAll";
                    BrowserInformationType[BrowserInformationType["QuerySelector"] = 12] = "QuerySelector";
                    BrowserInformationType[BrowserInformationType["JSConsoleErrors"] = 13] = "JSConsoleErrors";
                    BrowserInformationType[BrowserInformationType["GetScrollPosition"] = 14] = "GetScrollPosition";
                })(BrowserInformationType = Enums.BrowserInformationType || (Enums.BrowserInformationType = {}));
            })(Enums = Common.Enums || (Common.Enums = {}));
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Background;
        (function (Background) {
            class BackgroundCommandProcessor {
                processActionCommand(command) {
                    command.Handled = true;
                    switch (command.ActionType) {
                        case TestStudio.Common.Enums.BrowserActionType.SetCookie:
                            return this.processSetCookie(command);
                        case TestStudio.Common.Enums.BrowserActionType.ClearHistory:
                            return this.processClearHistory(command);
                        case TestStudio.Common.Enums.BrowserActionType.ClearFilesCache:
                            return this.processClearFilesCache(command);
                        case TestStudio.Common.Enums.BrowserActionType.ClearCookies:
                            return this.processClearCookie(command);
                        default:
                            command.Handled = false;
                            return Promise.resolve(command);
                    }
                }
                processInformationCommand(command, tabId) {
                    command.Handled = true;
                    switch (command.InformationType) {
                        case TestStudio.Common.Enums.BrowserInformationType.IsReady:
                            return this.processIsReady(command, tabId);
                        case TestStudio.Common.Enums.BrowserInformationType.Cookies:
                            return this.processGetCookies(command);
                        default:
                            command.Handled = false;
                            return Promise.resolve(command);
                    }
                }
                processIsReady(command, tabId) {
                    return new Promise((resolve, reject) => {
                        TestStudio.Common.Browser.tabs.get(tabId)
                            .then((tab) => {
                            command.Response = tab.status === "complete";
                            resolve(command);
                        }, (error) => {
                            command.Response = false;
                            resolve(command);
                        });
                    });
                }
                processClearCookie(command) {
                    return new Promise((resolve, reject) => {
                        let details;
                        if (command.Data) {
                            details = JSON.parse(command.Data);
                            delete details.expirationDate;
                            delete details.httpOnly;
                            delete details.value;
                            if (!details.name && typeof details.name !== "undefined") {
                                delete details.name;
                            }
                            if (!details.path && typeof details.path !== "undefined") {
                                delete details.path;
                            }
                            if (!details.secure && typeof details.secure !== "undefined") {
                                delete details.secure;
                            }
                        }
                        else {
                            details = {};
                            TestStudio.Common.Browser.browsingData.removeLocalStorage({ "since": 0 });
                        }
                        TestStudio.Common.Browser.cookies.getAll(details)
                            .then((cookies) => {
                            if (cookies) {
                                for (let i = 0; i < cookies.length; i++) {
                                    let filterDetailsForCookieToDelete = { name: cookies[i].name, storeId: cookies[i].storeId, url: "" };
                                    let domain = cookies[i].domain;
                                    if (domain[0] === ".") {
                                        domain = domain.slice(1);
                                    }
                                    let prefix = cookies[i].secure ? "https://" : "http://";
                                    filterDetailsForCookieToDelete.url = prefix + domain + cookies[i].path;
                                    TestStudio.Common.Browser.cookies.remove(filterDetailsForCookieToDelete);
                                }
                            }
                            resolve(command);
                        });
                    });
                }
                processGetCookies(command) {
                    return new Promise((resolve, reject) => {
                        let details = { url: command.Data };
                        TestStudio.Common.Browser.cookies.getAll(details)
                            .then((cookies) => {
                            let response = "";
                            for (let i = 0; i < cookies.length; i++) {
                                response += cookies[i].name + "=" + cookies[i].value + ";";
                            }
                            command.Response = response;
                            resolve(command);
                        });
                    });
                }
                processSetCookie(command) {
                    return new Promise((resolve, reject) => {
                        if (command.Data) {
                            let details = JSON.parse(command.Data);
                            TestStudio.Common.Browser.cookies.set(details)
                                .then((cookies) => {
                                command.Response = true;
                                resolve(command);
                            });
                        }
                    });
                }
                processClearHistory(command) {
                    return new Promise((resolve, reject) => {
                        TestStudio.Common.Browser.history.deleteAll()
                            .then(() => resolve(command));
                    });
                }
                processClearFilesCache(command) {
                    return new Promise((resolve, reject) => {
                        TestStudio.Common.Browser.browsingData.removeCache({ "since": 0 })
                            .then(() => resolve(command));
                    });
                }
            }
            Background.BackgroundCommandProcessor = BackgroundCommandProcessor;
        })(Background = TestStudio.Background || (TestStudio.Background = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class TestStudioContext {
                constructor(port, mode, version) {
                    this.port = port;
                    this.mode = mode;
                    this.version = version;
                }
            }
            Common.TestStudioContext = TestStudioContext;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class UrlHelper {
                static getQueryParameterByName(url, paramName) {
                    paramName = paramName.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
                    let regex = new RegExp("[\\?&]" + paramName + "=([^&#]*)");
                    let results = regex.exec(url);
                    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
                }
                static getTestStudioContextFromUrl(url) {
                    if (url.indexOf(UrlHelper.startPageBaseUrl) === -1) {
                        return new Common.TestStudioContext(null, null, null);
                    }
                    return new Common.TestStudioContext(UrlHelper.getQueryParameterByName(url, "port"), UrlHelper.getQueryParameterByName(url, "mode"), UrlHelper.getQueryParameterByName(url, "version"));
                }
            }
            UrlHelper.startPageBaseUrl = "/WebUI/teststudio_start_page.html";
            Common.UrlHelper = UrlHelper;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            let LogSeverity;
            (function (LogSeverity) {
                LogSeverity[LogSeverity["INFO"] = 0] = "INFO";
                LogSeverity[LogSeverity["ERROR"] = 1] = "ERROR";
            })(LogSeverity = Common.LogSeverity || (Common.LogSeverity = {}));
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class Logger {
                static info(message) {
                    Logger.log(Common.LogSeverity[Common.LogSeverity.INFO], message);
                }
                static error(message) {
                    Logger.log(Common.LogSeverity[Common.LogSeverity.ERROR], message);
                }
                static log(level, message) {
                    let sb;
                    sb = `${Logger.getFormattedDate()} - `;
                    sb += `[${level}] `;
                    sb += message;
                    console.log(sb);
                }
                static getFormattedDate() {
                    let date = new Date();
                    let str = Logger.pad(date.getDate(), 2) + "/" + Logger.pad((date.getMonth() + 1), 2) + "/" + date.getFullYear()
                        + " " + Logger.pad(date.getHours(), 2) + ":" + Logger.pad(date.getMinutes(), 2) + ":"
                        + Logger.pad(date.getSeconds(), 2) + "." + Logger.pad(date.getMilliseconds(), 3);
                    return str;
                }
                static pad(num, size) {
                    let s = num + "";
                    while (s.length < size) {
                        s = "0" + s;
                    }
                    return s;
                }
            }
            Common.Logger = Logger;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Common;
        (function (Common) {
            class LoggerBackground extends Common.Logger {
                static setBackgroundManager(bg) {
                    LoggerBackground.backgroundManager = bg;
                }
                static info(message) {
                    LoggerBackground.log(Telerik.TestStudio.Common.LogSeverity[Telerik.TestStudio.Common.LogSeverity.INFO], message);
                }
                static error(message) {
                    LoggerBackground.log(Telerik.TestStudio.Common.LogSeverity[Telerik.TestStudio.Common.LogSeverity.ERROR], message);
                }
                static log(level, message) {
                    let sb;
                    sb = `${LoggerBackground.getFormattedDate()} - `;
                    sb += `[${level} - BACKGROUND] `;
                    sb += message;
                    console.log(sb);
                    let logMsg = { message: "logger.logMessage", data: sb };
                    LoggerBackground.backgroundManager.sendLogMessage(logMsg);
                }
            }
            Common.LoggerBackground = LoggerBackground;
        })(Common = TestStudio.Common || (TestStudio.Common = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Background;
        (function (Background) {
            var BackgroundManager;
            (function (BackgroundManager) {
                let logger = null;
                let initialTabIdToOpenSocket = 0;
                let automatedTabs = {};
                let wSocket = null;
                let trackNewBrowsers = false;
                let commandMessageQueue = [];
                let browserType;
                let bgrCmdProcessor;
                let initialTabId = null;
                let tabUrls = {};
                let updateUrlInterval;
                let changeTabTimeoutCounters = [];
                let changeTabTimers = [];
                let executionTabId = null;
                let glSocketPort = "";
                let lastCommandSenderWindowTabId = {};
                let lastCommandSenderTabId = 0;
                let countSocketTryToConnect = 0;
                let lastRespondedCommandRequestId;
                let version;
                function getErrorText(error) {
                    return typeof error.message !== "undefined" ? error.message : JSON.stringify(error);
                }
                function createUUID() {
                    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx"
                        .replace(/[xy]/g, function (c) { let r = Math.random() * 16 | 0, v = c === "x" ? r : r & 0x3 | 0x8; return v.toString(16); });
                }
                function findTabIdByUiid(uuid) {
                    for (let tabId in automatedTabs) {
                        if (automatedTabs[tabId] === uuid) {
                            return parseInt(tabId, 10);
                        }
                    }
                    return null;
                }
                function sendLogMessage(logMessage) {
                    if (wSocket != null && wSocket.readyState === 1) {
                        sendSocketMessage(JSON.stringify(logMessage));
                    }
                }
                BackgroundManager.sendLogMessage = sendLogMessage;
                function sendMessageToTab(tabId, message, command, callback) {
                    TestStudio.Common.Browser.tabs.get(tabId).then((tab) => {
                        if (tab.status === "complete") {
                            let tabMsg = JSON.stringify({ message: message, data: command });
                            if (callback) {
                                TestStudio.Common.Browser.tabs.sendMessage(tabId, { message: message, data: command })
                                    .then((response) => {
                                    callback(response);
                                });
                            }
                            else {
                                TestStudio.Common.Browser.tabs.sendMessage(tabId, { message: message, data: command });
                            }
                        }
                        else {
                            setTimeout(() => {
                                sendMessageToTab(tabId, message, command, callback);
                            }, 100);
                        }
                    }).catch((error) => {
                        sendCommandErrorMessageToSocket(command, "The targeted tab " + tabId + " was already closed.");
                        if (callback) {
                            callback(command.Response);
                        }
                    });
                }
                function notifyNewBrowserConnected(tabId) {
                    setTimeout(() => {
                        TestStudio.Common.Browser.tabs.get(tabId)
                            .then((tab) => {
                            if (tab.url.indexOf("chrome://") !== -1) {
                                return;
                            }
                            sendMessageToTab(tabId, "teststudio_v_2.exec.getPageInfo", null, (response) => {
                                let connectParams = {
                                    clientId: automatedTabs[tabId],
                                    pageTitle: response.title,
                                    version: response.version,
                                    browserType: browserType,
                                    tabId: tabId,
                                    windowId: tab.windowId
                                };
                                let message = { message: "execution.connect", data: connectParams };
                                sendSocketMessage(JSON.stringify(message));
                            });
                        })
                            .catch((error) => logger.error(`notifyNewBrowserConnected: ${error}`));
                    }, 100);
                }
                function notifyBrowserClosed(clientId) {
                    if (wSocket) {
                        let message = { message: "execution.disconnect", data: clientId };
                        sendSocketMessage(JSON.stringify(message));
                    }
                }
                function handleSocketExecutionCommand(command) {
                    let cmd = TestStudio.Common.cloneCommand(command);
                    let clientTabId = findTabIdByUiid(cmd.ClientId);
                    switch (cmd.CommandType) {
                        case TestStudio.Common.Enums.BrowserCommandType.Config:
                            let data = JSON.parse(cmd.Data);
                            trackNewBrowsers = data.TrackNewBrowsers;
                            break;
                        case TestStudio.Common.Enums.BrowserCommandType.Information:
                            bgrCmdProcessor.processInformationCommand(cmd, clientTabId).then((resultCmd) => {
                                if (resultCmd.Handled) {
                                    let response = { message: "execution.setCommandResponse", data: resultCmd };
                                    sendSocketMessage(JSON.stringify(response));
                                }
                                else {
                                    let sendMsgInterval = setInterval(() => {
                                        sendMessageToTab(clientTabId, "teststudio_v_2.exec.processCommand", cmd, (response) => {
                                            if (response) {
                                                clearInterval(sendMsgInterval);
                                            }
                                        });
                                    }, 100);
                                }
                            }).catch((error) => sendCommandErrorMessageToSocket(cmd, getErrorText(error)));
                            break;
                        case TestStudio.Common.Enums.BrowserCommandType.Action:
                            bgrCmdProcessor.processActionCommand(cmd).then((resultCmd) => {
                                if (resultCmd.Handled) {
                                    let response = { message: "execution.setCommandResponse", data: resultCmd };
                                    sendSocketMessage(JSON.stringify(response));
                                }
                                else {
                                    sendMessageToTab(clientTabId, "teststudio_v_2.exec.processCommand", cmd, null);
                                }
                            }).catch((error) => sendCommandErrorMessageToSocket(cmd, getErrorText(error)));
                            break;
                        default:
                            sendCommandErrorMessageToSocket(cmd, "Command type " + cmd.CommandType + " not supported.");
                            logger.error(`Command type ${cmd.CommandType} not supported.`);
                    }
                }
                function initialize(tabId, port) {
                    if (automatedTabs[tabId] != null) {
                        return;
                    }
                    automatedTabs[tabId] = createUUID();
                    initialTabIdToOpenSocket = tabId;
                    logger.info(`Initialaizing: tab ID '${tabId}'; WS port '${port}'`);
                    if (wSocket === null) {
                        OpenSocket(port);
                    }
                    else {
                        notifyNewBrowserConnected(tabId);
                    }
                }
                function sendCommandErrorMessageToSocket(command, errorMessage) {
                    command.InError = true;
                    command.Response = errorMessage;
                    let response = { message: "execution.setCommandResponse", data: command };
                    sendSocketMessage(JSON.stringify(response));
                }
                function sendSocketMessage(msg) {
                    if (wSocket == null) {
                        commandMessageQueue.push(msg);
                        return;
                    }
                    switch (wSocket.readyState) {
                        case 1:
                            wSocket.send(msg);
                            break;
                        case 0:
                            commandMessageQueue.push(msg);
                            break;
                        default:
                            console.log("Cannot send the message. Socket is closed or closing");
                            break;
                    }
                }
                function initializeExecutionStartingTab(tab) {
                    if (tab != null) {
                        const context = TestStudio.Common.UrlHelper.getTestStudioContextFromUrl(tab.url);
                        if (context.mode !== "0") {
                            return;
                        }
                        if (context.port == null) {
                            console.log("Error retrieving web socket port from start page.");
                            return;
                        }
                        if (context.version !== null) {
                            version = context.version;
                        }
                        sendMessageToTab(tab.id, "teststudio_v_2.exec.started", null, null);
                        initialize(tab.id, context.port);
                    }
                }
                function start() {
                    logger = TestStudio.Common.LoggerBackground;
                    logger.setBackgroundManager(backgroundManager);
                    browserType = TestStudio.Common.Browser.getBrowserName();
                    bgrCmdProcessor = new Background.BackgroundCommandProcessor();
                    TestStudio.Common.Browser.runtime.onMessageAddListener((request, sender, sendResponse) => HandleForegroundMessage(request, sender, sendResponse));
                    TestStudio.Common.Browser.tabs.onCreatedAddListener((tab) => HandleTabCreated(tab));
                    TestStudio.Common.Browser.tabs.onActivatedAddListener((activeInfo) => HandleTabActivated(activeInfo));
                    TestStudio.Common.Browser.tabs.onRemovedAddListener((tabId, removeInfo) => HandleTabRemoved(tabId, removeInfo));
                    TestStudio.Common.Browser.tabs.onReplacedAddListener((addedTabId, removedTabId) => HandleTabReplaced(addedTabId, removedTabId));
                    TestStudio.Common.Browser.tabs.query({ currentWindow: true, active: true })
                        .then((tabs) => {
                        if (tabs.length > 0) {
                            initializeExecutionStartingTab(tabs[0]);
                        }
                    });
                }
                BackgroundManager.start = start;
                function UpdatePopUrls() {
                    for (let idStr in tabUrls) {
                        let id = parseInt(idStr, 10);
                        TestStudio.Common.Browser.tabs.get(id)
                            .then((instectedTab) => {
                            tabUrls[instectedTab.id] = instectedTab.url;
                        }, (error) => {
                            logger.error(`UpdatePopUrls: ${error}`);
                        });
                    }
                }
                function IsEmpty(obj) {
                    return Object.getOwnPropertyNames(obj).length === 0;
                }
                function OnWebSocketOpened(evt) {
                    if (commandMessageQueue) {
                        for (let ii = 0; ii < commandMessageQueue.length; ii++) {
                            wSocket.send(commandMessageQueue[ii]);
                        }
                        commandMessageQueue = [];
                    }
                    TestStudio.Common.Browser.windows.getCurrent().then((win) => {
                        wSocket.send(JSON.stringify({ command: "recorderSocketOpened", data: { browser: browserType }, windowId: win.id }));
                    });
                    if (initialTabId != null) {
                        let enableExecutionMsg = { message: "teststudio_v_2.exec.enableExecution", data: { port: glSocketPort } };
                        TestStudio.Common.Browser.tabs.sendMessage(initialTabId, { webSocketMsg: enableExecutionMsg });
                    }
                    notifyNewBrowserConnected(initialTabIdToOpenSocket);
                }
                function OnWebSocketMessage(message) {
                    let messageObj = JSON.parse(message.data);
                    if (messageObj.message === "execution.executeCommand") {
                        if (messageObj.data) {
                            handleSocketExecutionCommand(messageObj.data);
                        }
                    }
                    else {
                        switch (messageObj.tjsr_v_2_message) {
                            case "getElementBounds":
                                TestStudio.Common.Browser.tabs.sendMessage(lastCommandSenderWindowTabId[messageObj.windowId], { webSocketMsg: message.data });
                                break;
                            case "showRecorder":
                                setTimeout(function () {
                                    TestStudio.Common.Browser.windows.getCurrent().then((win) => {
                                        TestStudio.Common.Browser.tabs.query({ windowId: win.id, active: true }).then((tabs) => {
                                            let tabId = -1;
                                            if (tabs && tabs.length > 0) {
                                                tabId = tabs[0].id;
                                            }
                                            sendSocketMessage(JSON.stringify({ command: "showRecorder", data: browserType, windowId: win.id, tabId: tabId }));
                                        });
                                    });
                                }, 2000);
                                break;
                            case "enableRecording":
                            case "enableHighlight":
                                if (messageObj.windowId) {
                                    TestStudio.Common.Browser.tabs.sendMessage(lastCommandSenderWindowTabId[messageObj.windowId], { webSocketMsg: message.data });
                                }
                                else {
                                    TestStudio.Common.Browser.tabs.sendMessage(lastCommandSenderTabId, { webSocketMsg: message.data });
                                }
                                break;
                            default:
                                TestStudio.Common.Browser.tabs.sendMessage(lastCommandSenderTabId, { webSocketMsg: message.data });
                                break;
                        }
                    }
                }
                function OnWebSocketClose() {
                    console.log("Web socket closed.");
                }
                function OpenSocket(port) {
                    if (port == null) {
                        return;
                    }
                    if (wSocket == null) {
                        wSocket = new WebSocket("ws://localhost:" + port);
                        wSocket.onopen = OnWebSocketOpened;
                        wSocket.onmessage = OnWebSocketMessage;
                        wSocket.onclose = OnWebSocketClose;
                        wSocket.onerror = OnWebSocketError;
                    }
                }
                function OnWebSocketError() {
                    if (countSocketTryToConnect < 10) {
                        setTimeout(function () {
                            OpenSocket(glSocketPort);
                            countSocketTryToConnect++;
                        }, 1000);
                    }
                    else {
                        console.log("Web socket broke.");
                        countSocketTryToConnect = 0;
                    }
                }
                function CheckTabReadyState(tab) {
                    return tab && tab.status === "complete";
                }
                function SendChangeTabMessage(tab) {
                    if (!tab || typeof changeTabTimeoutCounters[tab.id] === typeof undefined) {
                        return;
                    }
                    changeTabTimeoutCounters[tab.id]--;
                    if (CheckTabReadyState(tab) || changeTabTimeoutCounters[tab.id] <= 0) {
                        TestStudio.Common.Browser.tabs.get(tab.id)
                            .then(() => {
                            sendSocketMessage(JSON.stringify({ command: "changeTab", data: "", windowId: tab.windowId, tabId: tab.id }));
                        }, (error) => {
                            logger.info(error);
                        });
                        delete changeTabTimeoutCounters[tab.id];
                        clearInterval(changeTabTimers[tab.id]);
                        delete changeTabTimers[tab.id];
                    }
                }
                function HandleTabActivated(activeInfo) {
                    lastCommandSenderTabId = activeInfo.tabId;
                    lastCommandSenderWindowTabId[activeInfo.windowId] = activeInfo.tabId;
                    TestStudio.Common.Browser.tabs.get(activeInfo.tabId)
                        .then((tab) => {
                        if (typeof changeTabTimeoutCounters[tab.id] === typeof undefined) {
                            changeTabTimeoutCounters[tab.id] = 6;
                            changeTabTimers[tab.id] = setInterval(() => { SendChangeTabMessage(tab); }, 500);
                        }
                    }, (error) => {
                        logger.error(`Tab onActivated: ${error}`);
                    });
                }
                function HandleTabCreated(tab) {
                    initializeExecutionStartingTab(tab);
                    logger.info(`Tab onCreated: added tab id '${tab.id}'; url: '${tab.url}'`);
                    if (automatedTabs[tab.id] == null) {
                        automatedTabs[tab.id] = createUUID();
                        notifyNewBrowserConnected(tab.id);
                    }
                    if (executionTabId != null) {
                        initialTabId = executionTabId;
                    }
                    if (initialTabId == null) {
                        return;
                    }
                    let id = tab.id;
                    setTimeout(() => {
                        TestStudio.Common.Browser.tabs.get(id)
                            .then((instectedTab) => {
                            let url = instectedTab.url;
                            if (url == null) {
                                return;
                            }
                            if (url.indexOf("chrome://") !== -1 || url.indexOf("chrome-devtools://") !== -1) {
                                return;
                            }
                            tabUrls[instectedTab.id] = url;
                            if (executionTabId != null) {
                                return;
                            }
                            let message = {
                                command: "browserState",
                                data: { browser: browserType, action: "popupOpened", url: url },
                                windowId: instectedTab.windowId,
                                tabId: instectedTab.id
                            };
                            sendSocketMessage(JSON.stringify(message));
                            let enableExecutionMsg = { message: "teststudio_v_2.exec.enableExecution", data: { port: glSocketPort } };
                            TestStudio.Common.Browser.tabs.sendMessage(id, { webSocketMsg: enableExecutionMsg });
                            clearInterval(updateUrlInterval);
                            updateUrlInterval = setInterval(UpdatePopUrls, 100);
                        }, (error) => {
                            logger.info(`Tab onCreated: ${error}`);
                        });
                    }, 1000);
                }
                function HandleTabRemoved(tabId, removeInfo) {
                    logger.info(`Tab onRemoved: removed tab id '${tabId}'`);
                    if (automatedTabs[tabId]) {
                        notifyBrowserClosed(automatedTabs[tabId]);
                        delete automatedTabs[tabId];
                    }
                    if (initialTabId == tabId) {
                        initialTabId = null;
                        tabUrls = {};
                        automatedTabs = {};
                        clearInterval(updateUrlInterval);
                        glSocketPort = null;
                        sendSocketMessage(JSON.stringify({ command: "browserState", data: { browser: browserType, action: "mainClosed" } }));
                        wSocket.close();
                    }
                    else if (tabUrls[tabId] != undefined) {
                        let message = {
                            command: "browserState",
                            data: { browser: browserType, action: "popupClosed", url: tabUrls[tabId] },
                            windowId: removeInfo.windowId
                        };
                        sendSocketMessage(JSON.stringify(message));
                        delete tabUrls[tabId];
                        TestStudio.Common.Browser.tabs.query({ active: true }).then((tabs) => {
                            if (tabs && tabs.length > 0 && tabs[0].windowId !== removeInfo.windowId) {
                                let tab = tabs[0];
                                lastCommandSenderTabId = tab.id;
                                lastCommandSenderWindowTabId[tab.windowId] = tab.id;
                                if (typeof changeTabTimeoutCounters[tab.id] === typeof undefined) {
                                    changeTabTimeoutCounters[tab.id] = 6;
                                    changeTabTimers[tab.id] = setInterval(function () { SendChangeTabMessage(tab); }, 500);
                                }
                            }
                        });
                        if (IsEmpty(tabUrls)) {
                            clearInterval(updateUrlInterval);
                        }
                    }
                    else if (executionTabId == tabId) {
                        executionTabId = null;
                    }
                }
                function HandleTabReplaced(addedTabId, removedTabId) {
                    if (automatedTabs[removedTabId]) {
                        automatedTabs[addedTabId] = automatedTabs[removedTabId];
                        delete automatedTabs[removedTabId];
                    }
                    if (initialTabId == removedTabId) {
                        initialTabId = addedTabId;
                    }
                    else if (tabUrls[removedTabId] != undefined) {
                        tabUrls[addedTabId] = tabUrls[removedTabId];
                        delete tabUrls[removedTabId];
                    }
                    else if (executionTabId == removedTabId) {
                        executionTabId = addedTabId;
                    }
                }
                function HandleForegroundMessage(request, sender, sendResponse) {
                    if (!sender.tab || !request.message) {
                        return;
                    }
                    let response;
                    switch (request.message) {
                        case "teststudio_v_2.exec.isAutomated":
                            let isAutomated = automatedTabs[sender.tab.id] != null;
                            sendResponse({ state: isAutomated });
                            break;
                        case "teststudio_v_2.exec.processCommandResponse":
                            if (request.data != null && request.data.RequestId != null && request.data.RequestId === lastRespondedCommandRequestId) {
                                sendResponse(true);
                                break;
                            }
                            lastRespondedCommandRequestId = request.data.RequestId;
                            response = { message: "execution.setCommandResponse", data: request.data };
                            sendSocketMessage(JSON.stringify(response));
                            sendResponse(true);
                            break;
                        case "teststudio_v_2.exec.dispatchJsEvent":
                            response = { message: "execution.dispatchJsEvent", data: request.data };
                            wSocket.send(JSON.stringify(response));
                            sendResponse(true);
                            break;
                        case "teststudio_v_2.exec.enableExecution":
                            if (request.data.port) {
                                initialize(sender.tab.id, request.data.port);
                            }
                            sendResponse(true);
                            break;
                        case "teststudio_v_2.exec.tabLoaded":
                            TestStudio.Common.Browser.tabs.query({ currentWindow: true, active: true })
                                .then((tabs) => {
                                if (tabs.length > 0) {
                                    initializeExecutionStartingTab(tabs[0]);
                                }
                            });
                            sendResponse(true);
                            break;
                        case "teststudio_v_2.exec.windowClose":
                            response = { message: request.message };
                            sendSocketMessage(JSON.stringify(response));
                            sendResponse(true);
                            break;
                        case "teststudio_v_2.log.message":
                            let logMessage = { message: "logger.logMessage", data: request.data };
                            sendLogMessage(logMessage);
                            sendResponse(true);
                            break;
                        case "isAvailable":
                            sendResponse(true);
                            break;
                        case "executionStarted":
                            executionTabId = sender.tab.id;
                            sendResponse(true);
                            break;
                        case "clearExecutionTab":
                            executionTabId = null;
                            sendResponse(true);
                            break;
                        case "setRecorderData_v_2":
                            glSocketPort = request.context.port;
                            initialTabId = sender.tab.id;
                            if (request.context.version != null) {
                                version = request.context.version;
                            }
                            OpenSocket(glSocketPort);
                            logger.info(`Obtained recorder tab id: '${sender.tab.id}'; port: '${glSocketPort}'`);
                            sendResponse(true);
                            break;
                        case "getRecorderData_v_2":
                            if ((sender.tab.id === initialTabId || tabUrls[sender.tab.id] != undefined)) {
                                sendResponse({ socket: glSocketPort });
                            }
                            else {
                                sendResponse({ tabNotLoaded: true });
                            }
                            break;
                        case "sendRecorderCommand":
                            lastCommandSenderTabId = sender.tab.id;
                            let tempCommand = request.command;
                            sendResponse(true);
                            TestStudio.Common.Browser.windows.getCurrent().then((win) => {
                                lastCommandSenderWindowTabId[win.id] = sender.tab.id;
                                tempCommand.windowId = win.id;
                                tempCommand.tabId = sender.tab.id;
                                sendSocketMessage(JSON.stringify(tempCommand));
                            });
                            break;
                        case "getVersion":
                            sendResponse({ version: version });
                            break;
                        default:
                            break;
                    }
                }
            })(BackgroundManager = Background.BackgroundManager || (Background.BackgroundManager = {}));
        })(Background = TestStudio.Background || (TestStudio.Background = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
let backgroundManager = Telerik.TestStudio.Background.BackgroundManager;
backgroundManager.start();
