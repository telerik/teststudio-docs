var Telerik;
(function (Telerik) {
    var TestStudio;
    (function (TestStudio) {
        var Foreground;
        (function (Foreground) {
            var Injector;
            (function (Injector) {
                function injectPageScript(scriptUrl) {
                    const pageScript = document.createElement("script");
                    pageScript.type = "text/javascript";
                    pageScript.src = chrome.runtime.getURL(scriptUrl);
                    document.documentElement.appendChild(pageScript);
                    document.documentElement.removeChild(pageScript);
                }
                Injector.injectPageScript = injectPageScript;
            })(Injector = Foreground.Injector || (Foreground.Injector = {}));
        })(Foreground = TestStudio.Foreground || (TestStudio.Foreground = {}));
    })(TestStudio = Telerik.TestStudio || (Telerik.TestStudio = {}));
})(Telerik || (Telerik = {}));
Telerik.TestStudio.Foreground.Injector.injectPageScript("/scripts/teststudio-interceptors.js");
